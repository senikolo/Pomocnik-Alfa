package com.ispina.lokalnie.deals;
import org.json.JSONObject;
import java.util.Locale;
public final class Deal {
 public String id="",name="",store="",source="Ding.pl",url="",image="",description="",unit="",start="",end="";
 public double price,unitPrice;public long from,to;public int minimum=1;public boolean card,details,currentPrice;public boolean promotion=true;public long checked;
 public String money(double n){return String.format(new Locale("pl","PL"),"%.2f zł",n);}
 public String priceLabel(){return money(price);}
 public String unitLabel(){return unit.isEmpty()?"Wielkość opakowania niepotwierdzona":money(unitPrice)+" / "+unit;}
 private String checkedLabel(){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("dd.MM.yyyy HH:mm",new Locale("pl","PL"));f.setTimeZone(java.util.TimeZone.getTimeZone("Europe/Warsaw"));return f.format(new java.util.Date(checked));}
 public String validity(){return currentPrice?(source.equals("Action.com")?"Cena z katalogu · odczyt: ":"Cena online · odczyt: ")+checkedLabel():"Promocja: "+start+" – "+end;}
 public String terms(){if(currentPrice)return source.equals("Action.com")?"Cena z katalogu Action · dostępność w sklepie wymaga sprawdzenia.":source.equals("zakupy.biedronka.pl")?"Biedronka online · cena w sklepie stacjonarnym może być inna. Sprawdź dostawę i dostępność dla swojego adresu.":"Cena online · bez potwierdzonego terminu promocji. Sprawdź dostępność przed zakupem.";if(!details)return "Warunki niepotwierdzone · otwórz gazetkę";return (card?"Karta lub aplikacja sklepu · ":"")+(minimum>1?"Zakup min. "+minimum+" szt. · ":"")+"Sprawdź limit i warunki w źródle";}
 public JSONObject json(){JSONObject o=new JSONObject();try{o.put("id",id).put("name",name).put("store",store).put("source",source).put("url",url).put("image",image).put("description",description).put("unit",unit).put("start",start).put("end",end).put("price",price).put("unitPrice",unitPrice).put("from",from).put("to",to).put("minimum",minimum).put("card",card).put("details",details).put("currentPrice",currentPrice).put("promotion",promotion).put("checked",checked);}catch(Exception ignored){}return o;}
 public static Deal read(JSONObject o){Deal d=new Deal();d.id=o.optString("id");d.name=o.optString("name");d.store=o.optString("store");d.source=o.optString("source","Ding.pl");d.url=o.optString("url");d.image=o.optString("image");d.description=o.optString("description");d.unit=o.optString("unit");d.start=o.optString("start");d.end=o.optString("end");d.price=o.optDouble("price");d.unitPrice=o.optDouble("unitPrice");d.from=o.optLong("from");d.to=o.optLong("to");d.minimum=o.optInt("minimum",1);d.card=o.optBoolean("card");d.details=o.optBoolean("details");d.currentPrice=o.optBoolean("currentPrice");d.promotion=o.optBoolean("promotion",true);d.checked=o.optLong("checked");return d;}
}
