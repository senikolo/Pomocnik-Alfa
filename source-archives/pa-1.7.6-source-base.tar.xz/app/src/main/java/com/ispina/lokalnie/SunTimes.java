package com.ispina.lokalnie;
import java.util.Calendar;
import java.util.TimeZone;
/** Standard sunrise definition: solar centre 0.833 degrees below horizon. Approximate, offline. */
public final class SunTimes {
    public static final TimeZone ZONE=TimeZone.getTimeZone("Europe/Warsaw");
    public final long rise, set;
    private SunTimes(long r,long s){rise=r;set=s;}
    public static SunTimes today(long now, boolean warsaw){
        Calendar day=Calendar.getInstance(ZONE);day.setTimeInMillis(now);
        double lat=warsaw?52.323876:50.11522,lon=warsaw?21.061994:20.39069;
        return new SunTimes(event(day,lat,lon,true),event(day,lat,lon,false));
    }
    private static double norm(double x,double range){return (x%range+range)%range;}
    private static double sin(double x){return Math.sin(Math.toRadians(x));}
    private static double cos(double x){return Math.cos(Math.toRadians(x));}
    private static long event(Calendar day,double lat,double lon,boolean morning){
        double lng=lon/15, t=day.get(Calendar.DAY_OF_YEAR)+((morning?6:18)-lng)/24;
        double m=.9856*t-3.289,l=norm(m+1.916*sin(m)+.020*sin(2*m)+282.634,360);
        double ra=norm(Math.toDegrees(Math.atan(.91764*Math.tan(Math.toRadians(l)))),360);
        ra+=(Math.floor(l/90)*90-Math.floor(ra/90)*90);ra/=15;
        double sd=.39782*sin(l),cd=Math.cos(Math.asin(sd));
        double ch=(cos(90.833)-sd*sin(lat))/(cd*cos(lat));
        if(ch>1 || ch< -1)return -1;
        double h=Math.toDegrees(Math.acos(ch));if(morning)h=360-h;h/=15;
        double utc=norm(h+ra-.06571*t-6.622-lng,24);
        Calendar base=Calendar.getInstance(TimeZone.getTimeZone("UTC"));base.clear();
        base.set(day.get(Calendar.YEAR),day.get(Calendar.MONTH),day.get(Calendar.DAY_OF_MONTH));
        return base.getTimeInMillis()+Math.round(utc*3600000);
    }
    public String greeting(long now){
        Calendar c=Calendar.getInstance(ZONE);c.setTimeInMillis(now);
        if(now<rise || c.get(Calendar.HOUR_OF_DAY)>=22)return "Spokojnej nocy";
        if(now>=set)return "Dobry wieczór";
        return c.get(Calendar.HOUR_OF_DAY)<12?"Dzień dobry":"Miłego popołudnia";
    }
    public static String time(long millis){java.text.SimpleDateFormat f=new java.text.SimpleDateFormat("HH:mm",new java.util.Locale("pl","PL"));f.setTimeZone(ZONE);return f.format(new java.util.Date(millis));}
}
