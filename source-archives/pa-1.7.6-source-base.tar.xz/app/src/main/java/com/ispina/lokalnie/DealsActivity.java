package com.ispina.lokalnie;

import android.Manifest;
import android.app.Activity;
import android.content.*;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.view.inputmethod.InputMethodManager;
import android.widget.*;
import androidx.core.app.NotificationManagerCompat;
import com.ispina.lokalnie.deals.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

public class DealsActivity extends ThemedActivity {
 private EditText query;
 private TextView status, alertStatus;
 private LinearLayout results, watchList;
 private Button search;
 private ProgressBar progress;
 private final List<Button> filters=new ArrayList<>();
 private final ExecutorService executor=Executors.newSingleThreadExecutor();
 private final Handler ui=new Handler(Looper.getMainLooper());
 private int generation;
 private boolean destroyed;
 private String active="", store="Wszystkie";
 private DealsRepository.Result current;
 private SharedPreferences alertsPrefs;
 private final SharedPreferences.OnSharedPreferenceChangeListener alertListener=(prefs,key)->ui.post(()->{if(!destroyed)refreshWatch();});

 @Override protected void onCreate(Bundle b){
  super.onCreate(b);
  getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN|WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
  build();
  alertsPrefs=getSharedPreferences("deal_alerts",0);alertsPrefs.registerOnSharedPreferenceChangeListener(alertListener);
  String q=b!=null?b.getString("query",""):getIntent().getStringExtra("query");
  if(b!=null)store=b.getString("store","Wszystkie");else if(getIntent().hasExtra("store"))store=getIntent().getStringExtra("store");if(!java.util.Arrays.asList(DealsParser.filters()).contains(store))store="Wszystkie";
  if(q!=null && !q.isEmpty()){query.setText(q);runSearch(true);}
  else{String last=getSharedPreferences("deals_ui",0).getString("last_query","");query.setText(last);DealsRepository.Result saved=DealsRepository.cached(this,last);if(saved!=null){active=last;saved.stale=true;show(saved);}}
  refreshFilters();DealAlerts.schedule(this);
 }
 private int dp(int n){return NativeUi.dp(this,n);}
 private String time(long millis){SimpleDateFormat f=new SimpleDateFormat("dd.MM, HH:mm",new Locale("pl","PL"));f.setTimeZone(SunTimes.ZONE);return f.format(new Date(millis));}
 private void build(){
  getWindow().setStatusBarColor(NativeUi.bg(this));
  if(Build.VERSION.SDK_INT>=23)getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(NativeUi.bg(this));
  LinearLayout root=new LinearLayout(this);root.setFocusableInTouchMode(true);root.requestFocus();root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(16),dp(16),dp(28));scroll.addView(root);setContentView(scroll);
  LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
  Button back=NativeUi.button(this,"‹",true);back.setContentDescription("Wróć");back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));
  TextView title=NativeUi.text(this,"Łowca promocji",24,true);title.setPadding(dp(12),0,0,0);head.addView(title,new LinearLayout.LayoutParams(0,-2,1));root.addView(head);NativeUi.addSpacer(root,this,18);
  LinearLayout hero=NativeUi.card(this);hero.setBackground(NativeUi.roundedStroke(NativeUi.softStrong(this),NativeUi.line(this),24,this));hero.addView(NativeUi.text(this,"Małe zakupy, dobre ceny",22,true));NativeUi.addSpacer(hero,this,6);hero.addView(NativeUi.muted(this,"Porównaj znalezione ceny w sklepach i obserwuj ulubione produkty.",14));NativeUi.addSpacer(hero,this,16);
  query=NativeUi.input(this,"Np. pasta do zębów lub Elmex, Sensodyne");query.setSingleLine(true);query.setInputType(android.text.InputType.TYPE_CLASS_TEXT);query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
  query.setOnEditorActionListener((v,a,event)->{if(a==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){runSearch(false);return true;}return false;});hero.addView(query,new LinearLayout.LayoutParams(-1,-2));hero.addView(NativeUi.muted(this,"Do 3 nazw, oddzielonych przecinkiem, np. Elmex, Sensodyne, Colgate.",12));NativeUi.addSpacer(hero,this,10);
  search=NativeUi.button(this,"Znajdź aktualne oferty",false);search.setOnClickListener(v->runSearch(false));hero.addView(search,new LinearLayout.LayoutParams(-1,-2));Button allegro=NativeUi.button(this,"🛒 Allegro · oferty w aplikacji",true);allegro.setOnClickListener(v->{String q=DealsRepository.clean(query.getText().toString());if(valid(q))openAllegro(q);});hero.addView(allegro,new LinearLayout.LayoutParams(-1,-2));NativeUi.addSpacer(hero,this,10);
  LinearLayout chips=new LinearLayout(this);for(String s:new String[]{"Mleko","Pasta do zębów","Kawa"}){Button chip=NativeUi.button(this,s,true);chip.setOnClickListener(v->{query.setText(s);runSearch(false);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);if(chips.getChildCount()>0)p.leftMargin=dp(6);chips.addView(chip,p);}hero.addView(chips);root.addView(hero);
  HorizontalScrollView filterScroll=new HorizontalScrollView(this);filterScroll.setHorizontalScrollBarEnabled(false);LinearLayout filterRow=new LinearLayout(this);
  for(String label:DealsParser.filters()){Button filter=NativeUi.button(this,label,true);filters.add(filter);filter.setOnClickListener(v->{store=label;refreshFilters();if(current!=null)show(current);else if(store.equals("Allegro"))showAllegro();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.rightMargin=dp(6);filterRow.addView(filter,p);}filterScroll.addView(filterRow);root.addView(filterScroll);root.addView(NativeUi.muted(this,"Przesuń listę sklepów w bok, aby wybrać sieć.",12));NativeUi.addSpacer(root,this,12);
  progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));
  status=NativeUi.muted(this,"Wpisz produkt. Pokażę znalezione ceny, terminy i warunki zakupu.",14);status.setPadding(dp(4),dp(8),dp(4),dp(12));status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);root.addView(status);
  results=new LinearLayout(this);results.setOrientation(LinearLayout.VERTICAL);root.addView(results);
  LinearLayout alerts=NativeUi.card(this);alerts.addView(NativeUi.text(this,"Moje alerty",21,true));NativeUi.addSpacer(alerts,this,5);alerts.addView(NativeUi.muted(this,"Nowe lub zmienione promocje na obserwowany produkt otrzymasz w powiadomieniu. Automatyczne sprawdzanie: około co 12 godzin. Alerty dotyczą potwierdzonych ofert z ceną.",14));NativeUi.addSpacer(alerts,this,12);
  Button watch=NativeUi.button(this,"Obserwuj wpisany produkt",false);watch.setOnClickListener(v->addWatch());alerts.addView(watch,new LinearLayout.LayoutParams(-1,-2));NativeUi.addSpacer(alerts,this,8);
  Button now=NativeUi.button(this,"Sprawdź alerty teraz",true);now.setOnClickListener(v->{if(DealAlerts.list(this).isEmpty()){Toast.makeText(this,"Najpierw dodaj produkt do obserwowanych.",Toast.LENGTH_SHORT).show();return;}DealAlerts.check(this);alertStatus.setText("Sprawdzenie zlecone. Gdy będzie internet, pobiorę aktualne oferty.");});alerts.addView(now,new LinearLayout.LayoutParams(-1,-2));
  alertStatus=NativeUi.muted(this,"",13);alertStatus.setPadding(0,dp(10),0,dp(10));alertStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);alerts.addView(alertStatus);
  watchList=new LinearLayout(this);watchList.setOrientation(LinearLayout.VERTICAL);alerts.addView(watchList);root.addView(alerts);refreshWatch();
  LinearLayout info=NativeUi.card(this);info.addView(NativeUi.text(this,"Cena z warunkami",18,true));NativeUi.addSpacer(info,this,6);info.addView(NativeUi.muted(this,"Porównanie dotyczy znalezionych ofert. Sprawdź cenę za litr lub kilogram, kartę klienta i minimalny zakup. Marki i warianty mogą się różnić. Dostępność na półce i oferty lokalne sprawdzisz w sklepie. Android może opóźnić alert przy oszczędzaniu baterii.",13));root.addView(info);
 }
 private void refreshFilters(){if(search!=null&&search.isEnabled())search.setText(store.equals("Allegro")?"Szukaj na Allegro":"Znajdź aktualne oferty");for(Button b:filters){boolean selected=store.equals(b.getText().toString());b.setSelected(selected);b.setTextColor(selected?Color.WHITE:NativeUi.ink(this));b.setBackground(NativeUi.roundedStroke(selected?NativeUi.green(this):NativeUi.soft(this),selected?NativeUi.green(this):NativeUi.line(this),16,this));b.setContentDescription(b.getText()+(selected?", wybrany sklep":""));}}
 private boolean valid(String q){if(q.length()<2 || q.length()>80 || DealsParser.normalize(q).isEmpty()){query.setError("Wpisz nazwę produktu, od 2 do 80 znaków.");return false;}return true;}
 private void runSearch(boolean cache){
  if(!search.isEnabled())return;String q=DealsRepository.clean(query.getText().toString());if(!valid(q))return;query.setText(q);active=q;if(store.equals("Allegro")){getSharedPreferences("deals_ui",0).edit().putString("last_query",q).apply();openAllegro(q);return;}getSharedPreferences("deals_ui",0).edit().putString("last_query",q).apply();
  InputMethodManager keyboard=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(keyboard!=null)keyboard.hideSoftInputFromWindow(query.getWindowToken(),0);query.clearFocus();
  int token=++generation;if(cache){DealsRepository.Result saved=DealsRepository.cached(this,q);if(saved!=null && System.currentTimeMillis()-saved.checked<600000){show(saved);return;}}
  status.setText("Sprawdzam ceny i terminy: "+q+"…");results.removeAllViews();current=null;search.setEnabled(false);search.setAlpha(.55f);progress.setVisibility(View.VISIBLE);
  executor.execute(()->{DealsRepository.Result r=DealsRepository.search(getApplicationContext(),q);ui.post(()->{if(destroyed || token!=generation)return;search.setEnabled(true);search.setAlpha(1);progress.setVisibility(View.GONE);show(r);});});
 }
 private void show(DealsRepository.Result r){
  current=r;results.removeAllViews();if(store.equals("Allegro")){showAllegro();return;}status.setText(active+" · "+(r.stale?"zapisane wyniki: ":"sprawdzono: ")+time(r.checked)+"\n"+r.note);
  if(!r.offers.isEmpty() && "Wszystkie".equals(store)){LinearLayout win=NativeUi.card(this);win.setBackground(NativeUi.roundedStroke(Color.rgb(252,244,220),Color.rgb(236,218,167),22,this));win.addView(NativeUi.text(this,r.stale?"Zapisane oferty · odśwież przed zakupem":DealsRepository.summary(r.offers),18,true));if(r.partial)win.addView(NativeUi.muted(this,"Porównanie częściowe: nie wszystkie źródła odpowiedziały.",13));results.addView(win);}
  if(r.offers.isEmpty()&&"Wszystkie".equals(store)){LinearLayout empty=NativeUi.card(this);empty.addView(NativeUi.muted(this,r.partial?"Nie znaleziono ofert w pobranych danych. Część źródeł jest niedostępna.":"Nie znaleziono pasujących ofert z potwierdzoną ceną.",14));results.addView(empty);}
  for(String shop:DealsParser.STORES){if(!"Wszystkie".equals(store) && !shop.equals(store))continue;List<Deal> list=new ArrayList<>();for(Deal d:r.offers)if(shop.equals(d.store))list.add(d);if("Wszystkie".equals(store)&&list.isEmpty())continue;
   TextView label=NativeUi.text(this,shop+" · oferty: "+list.size(),18,true);label.setPadding(dp(4),dp(8),0,dp(9));results.addView(label);
   if(list.isEmpty()){LinearLayout empty=NativeUi.card(this);empty.addView(NativeUi.muted(this,DealsParser.emptyStore(shop)+(r.partial?"\nCzęść źródeł jest niedostępna.":""),14));results.addView(empty);}else for(Deal d:list)offer(d);
  }
 }
 private void openAllegro(String q){startActivity(new Intent(this,AllegroActivity.class).putExtra("query",q));}
 private void showAllegro(){results.removeAllViews();status.setText("Allegro · wyniki w aplikacji");LinearLayout c=NativeUi.card(this);c.addView(NativeUi.text(this,"Allegro",21,true));c.addView(NativeUi.muted(this,DealsParser.ALLEGRO_STATUS,14));Button b=NativeUi.button(this,"Pokaż oferty Allegro",false);b.setOnClickListener(v->{String q=DealsRepository.clean(query.getText().toString());if(valid(q))openAllegro(q);});c.addView(b,new LinearLayout.LayoutParams(-1,-2));results.addView(c);}
 private void offer(Deal d){
  LinearLayout card=NativeUi.card(this);card.addView(NativeUi.text(this,d.name,18,true));NativeUi.addSpacer(card,this,10);
  TextView price=NativeUi.text(this,d.priceLabel(),27,true);price.setTextColor(NativeUi.green(this));card.addView(price);card.addView(NativeUi.text(this,d.unitLabel(),14,true));NativeUi.addSpacer(card,this,8);
  TextView dates=NativeUi.muted(this,d.validity(),13);card.addView(dates);
  LinearLayout terms=new LinearLayout(this);terms.setOrientation(LinearLayout.VERTICAL);terms.setPadding(dp(12),dp(10),dp(12),dp(10));terms.setBackground(NativeUi.rounded(NativeUi.soft(this),12,this));terms.addView(NativeUi.text(this,d.terms(),14,false));
  if(d.minimum>1 && d.details)terms.addView(NativeUi.text(this,"Minimalny zakup: "+d.money(d.minimum*d.price),14,true));NativeUi.addSpacer(card,this,10);card.addView(terms,new LinearLayout.LayoutParams(-1,-2));
  NativeUi.addSpacer(card,this,10);TextView description=NativeUi.muted(this,d.description.isEmpty()?"Opis niedostępny. Sprawdź warunki w gazetce.":d.description,14);description.setVisibility(View.GONE);card.addView(description);
  Button detail=NativeUi.button(this,"Szczegóły",true);detail.setOnClickListener(v->new android.app.AlertDialog.Builder(this).setTitle(d.store+" · "+d.name).setMessage(d.priceLabel()+"\n"+d.validity()+"\n"+d.terms()+"\n\n"+(d.description.isEmpty()?"Dodatkowy opis niedostępny.":d.description)+"\n\nŹródło: "+d.source).setNegativeButton("Zamknij",null).setPositiveButton("Otwórz źródło",(dialog,which)->open(d.url)).show());card.addView(detail,new LinearLayout.LayoutParams(-1,-2));results.addView(card);
 }
 private void addWatch(){String q=DealsRepository.clean(query.getText().toString());if(!valid(q))return;
  if(!DealAlerts.add(this,q)){Toast.makeText(this,"Możesz obserwować maksymalnie 10 produktów.",Toast.LENGTH_SHORT).show();return;}
  if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);
  refreshWatch();Toast.makeText(this,"Obserwujesz: "+q,Toast.LENGTH_SHORT).show();
 }
 private void refreshWatch(){
  if(watchList==null)return;watchList.removeAllViews();List<String> all=DealAlerts.list(this);SharedPreferences prefs=getSharedPreferences("deal_alerts",0);long last=prefs.getLong("last_finished",0);
  if(alertStatus!=null)alertStatus.setText(all.isEmpty()?"Dodaj pierwszy produkt, np. kawę.":"Obserwujesz "+all.size()+" z 10 produktów."+(last>0?"\nOstatnie sprawdzenie: "+time(last):"\nPierwsze sprawdzenie czeka na dostęp do internetu."));
  if(!NotificationManagerCompat.from(this).areNotificationsEnabled()){watchList.addView(NativeUi.muted(this,"Powiadomienia są wyłączone. Włącz je, aby otrzymywać alerty.",14));Button permission=NativeUi.button(this,"Włącz powiadomienia",true);permission.setOnClickListener(v->{if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},44);else openSettings();});watchList.addView(permission);NativeUi.addSpacer(watchList,this,10);}
  for(String q:all){LinearLayout item=new LinearLayout(this);item.setOrientation(LinearLayout.VERTICAL);item.setPadding(dp(12),dp(10),dp(12),dp(10));item.setBackground(NativeUi.rounded(NativeUi.soft(this),16,this));
   LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);Button show=NativeUi.button(this,q,true);show.setOnClickListener(v->{query.setText(q);runSearch(false);});row.addView(show,new LinearLayout.LayoutParams(0,-2,1));Button remove=NativeUi.button(this,"Usuń",true);remove.setContentDescription("Usuń alert: "+q);remove.setOnClickListener(v->{DealAlerts.remove(this,q);refreshWatch();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(-2,-2);p.leftMargin=dp(6);row.addView(remove,p);item.addView(row);
   String key=DealsRepository.key(q);long checked=prefs.getLong("checked:"+key,0);String outcome=prefs.getString("status:"+key,"");TextView state=NativeUi.muted(this,checked>0?time(checked)+" · "+outcome:"Czeka na pierwsze sprawdzenie",12);state.setPadding(dp(3),dp(6),dp(3),0);item.addView(state);watchList.addView(item,new LinearLayout.LayoutParams(-1,-2));NativeUi.addSpacer(watchList,this,8);
  }
 }
 private void open(String url){try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Nie znaleziono przeglądarki.",Toast.LENGTH_SHORT).show();}}
 private void openSettings(){try{Intent intent=Build.VERSION.SDK_INT>=26?new Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(android.provider.Settings.EXTRA_APP_PACKAGE,getPackageName()):new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:"+getPackageName()));startActivity(intent);}catch(Exception ignored){}}
 @Override public void onRequestPermissionsResult(int requestCode,String[] permissions,int[] results){super.onRequestPermissionsResult(requestCode,permissions,results);refreshWatch();if(requestCode==44 && results.length>0 && results[0]==PackageManager.PERMISSION_GRANTED)DealAlerts.check(this);}
 @Override protected void onSaveInstanceState(Bundle b){b.putString("query",query.getText().toString());b.putString("store",store);super.onSaveInstanceState(b);}
 @Override protected void onResume(){super.onResume();refreshWatch();}
 @Override protected void onDestroy(){destroyed=true;generation++;if(alertsPrefs!=null)alertsPrefs.unregisterOnSharedPreferenceChangeListener(alertListener);ui.removeCallbacksAndMessages(null);executor.shutdownNow();super.onDestroy();}
}
