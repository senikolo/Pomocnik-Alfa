package com.ispina.lokalnie;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.LayerDrawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.TextView;
import java.util.ArrayList;
import java.util.List;

/** Animate actual view colors, retaining the existing layout, focus and scroll. */
final class ThemeTransition {
    private interface Binding { void apply(int[] palette); }
    private final List<Binding> bindings=new ArrayList<>();
    private final ValueAnimator animator=ValueAnimator.ofFloat(0f,1f);
    private boolean canceled;

    ThemeTransition(Activity activity,View root,int family,int tone){
        final int[] from=NativeUi.palette(activity).clone();
        collect(root,from);
        int status=role(activity.getWindow().getStatusBarColor(),from);
        int navigation=role(activity.getWindow().getNavigationBarColor(),from);
        if(status>=0)bindings.add(p->activity.getWindow().setStatusBarColor(p[status]));
        if(navigation>=0)bindings.add(p->activity.getWindow().setNavigationBarColor(p[navigation]));
        NativeUi.setTheme(activity,family,tone);
        final int[] to=NativeUi.savedPalette(activity);
        animator.setDuration(1000);
        animator.setInterpolator(new AccelerateDecelerateInterpolator());
        animator.addUpdateListener(value->{
            float fraction=(float)value.getAnimatedValue();int[] frame=new int[from.length];
            for(int i=0;i<frame.length;i++)frame[i]=NativeUi.blend(from[i],to[i],fraction);
            NativeUi.transitionPalette(activity,frame);
            for(Binding binding:bindings)binding.apply(frame);
        });
        animator.addListener(new AnimatorListenerAdapter(){
            @Override public void onAnimationCancel(Animator animation){canceled=true;}
            @Override public void onAnimationEnd(Animator animation){if(!canceled)NativeUi.transitionPalette(activity,null);}
        });
    }
    void start(){animator.start();}
    void cancel(){animator.cancel();}
    private static int role(int color,int[] palette){for(int i=0;i<palette.length;i++)if(color==palette[i])return i;return -1;}
    private static int resolve(int original,int index,int[] palette){return index<0?original:palette[index];}
    private void collect(View view,int[] palette){
        drawable(view.getBackground(),palette);
        if(view instanceof TextView){
            TextView text=(TextView)view;int foreground=role(text.getCurrentTextColor(),palette),hint=role(text.getCurrentHintTextColor(),palette);
            if(foreground>=0)bindings.add(p->text.setTextColor(p[foreground]));
            if(hint>=0)bindings.add(p->text.setHintTextColor(p[hint]));
        }
        if(view instanceof ViewGroup){ViewGroup group=(ViewGroup)view;for(int i=0;i<group.getChildCount();i++)collect(group.getChildAt(i),palette);}
    }
    private void drawable(Drawable drawable,int[] palette){
        if(drawable instanceof NativeUi.PaletteDrawable){
            NativeUi.PaletteDrawable d=(NativeUi.PaletteDrawable)drawable;
            final int fill=d.fill,stroke=d.stroke,width=d.width;
            final int fillRole=role(fill,palette),strokeRole=role(stroke,palette);
            if(d.gradient!=null){
                final int[] original=d.gradient.clone(),roles=new int[original.length];
                for(int i=0;i<roles.length;i++)roles[i]=role(original[i],palette);
                bindings.add(p->{int[] colors=new int[original.length];for(int i=0;i<colors.length;i++)colors[i]=resolve(original[i],roles[i],p);d.setColors(colors);});
            }else if(fillRole>=0)bindings.add(p->d.setColor(p[fillRole]));
            if(width>0 && strokeRole>=0)bindings.add(p->d.setStroke(width,p[strokeRole]));
        }else if(drawable instanceof ColorDrawable){
            ColorDrawable d=(ColorDrawable)drawable;int index=role(d.getColor(),palette);
            if(index>=0)bindings.add(p->d.setColor(p[index]));
        }else if(drawable instanceof LayerDrawable){
            LayerDrawable layers=(LayerDrawable)drawable;for(int i=0;i<layers.getNumberOfLayers();i++)drawable(layers.getDrawable(i),palette);
        }
    }
}
