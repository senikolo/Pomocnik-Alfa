package com.ispina.lokalnie.weather;

import android.content.Context;
import org.json.*;
import java.io.*;
import java.net.*;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.*;

public final class WeatherRepository {
 public static final ZoneId ZONE=ZoneId.of("Europe/Warsaw");
 public static final String[] NAMES={"Ispina","Warszawa · Berensona"};
 public static final double[] LAT={50.11522,52.323876},LON={20.39069,21.061994};
 public static final String CURRENT="temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,cloud_cover,pressure_msl,wind_speed_10m,wind_direction_10m,wind_gusts_10m,is_day";
 public static final String HOURLY="is_day,temperature_2m,apparent_temperature,relative_humidity_2m,precipitation_probability,precipitation,weather_code,cloud_cover,wind_speed_10m,wind_direction_10m,wind_gusts_10m,pressure_msl,uv_index,visibility";
 public static final String DAILY="weather_code,temperature_2m_max,temperature_2m_min,apparent_temperature_max,apparent_temperature_min,sunrise,sunset,precipitation_sum,precipitation_probability_max,wind_speed_10m_max,wind_gusts_10m_max,wind_direction_10m_dominant,uv_index_max";
 public static final class Place {
  public final String name,region;public final double latitude,longitude;
  public Place(String name,String region,double latitude,double longitude){this.name=name;this.region=region;this.latitude=latitude;this.longitude=longitude;}
  public String key(){return "location:"+latitude+","+longitude;}
  public JSONObject json()throws JSONException{return new JSONObject().put("name",name).put("region",region).put("latitude",latitude).put("longitude",longitude);}
 }
 public static Place custom(Context c){try{JSONObject j=new JSONObject(c.getSharedPreferences("weather_ui",0).getString("custom",""));double lat=j.getDouble("latitude"),lon=j.getDouble("longitude");if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)return null;return new Place(j.getString("name"),j.optString("region"),lat,lon);}catch(Exception e){return null;}}
 public static Place place(Context c,int index){if(index==2){Place p=custom(c);if(p!=null)return p;}int i=index==1?1:0;return new Place(NAMES[i],"Polska",LAT[i],LON[i]);}
 public static void saveCustom(Context c,Place p)throws JSONException{c.getSharedPreferences("weather_ui",0).edit().putString("custom",p.json().toString()).apply();}
 public static List<Place> find(String query)throws Exception{
  String q=query.trim();if(q.length()<2 || q.length()>80)throw new IOException("Wpisz nazwę miejscowości");
  HttpURLConnection connection=(HttpURLConnection)new URL("https://geocoding-api.open-meteo.com/v1/search?name="+URLEncoder.encode(q,"UTF-8")+"&count=10&language=pl&format=json").openConnection();connection.setConnectTimeout(12000);connection.setReadTimeout(18000);
  try{if(connection.getResponseCode()!=200)throw new IOException();ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=connection.getInputStream()){byte[] b=new byte[4096];int n;while((n=in.read(b))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();out.write(b,0,n);if(out.size()>500000)throw new IOException();}}
   return locations(new JSONObject(out.toString("UTF-8")));
  }finally{connection.disconnect();}
 }
 public static List<Place> locations(JSONObject data){List<Place> found=new ArrayList<>();JSONArray a=data.optJSONArray("results");if(a==null)return found;for(int i=0;i<a.length();i++){JSONObject j=a.optJSONObject(i);if(j==null)continue;double lat=j.optDouble("latitude",Double.NaN),lon=j.optDouble("longitude",Double.NaN);if(!Double.isFinite(lat)||!Double.isFinite(lon)||Math.abs(lat)>90||Math.abs(lon)>180)continue;String name=j.optString("name","");if(name.isEmpty())continue;String region=j.optString("admin1","");String district=j.optString("admin2","");if(!district.isEmpty() && !district.equals(region))region=district+(region.isEmpty()?"":", "+region);String country=j.optString("country","");if(!country.isEmpty())region+=(region.isEmpty()?"":", ")+country;Place p=new Place(name,region,lat,lon);if("PL".equals(j.optString("country_code")))found.add(0,p);else found.add(p);}return found;}
 public static final class Forecast {
  public final JSONObject data; public final long fetched; public final int place; public final Place location; public boolean offline;
  public Forecast(JSONObject data,long fetched,int place,Place location){this.data=data;this.fetched=fetched;this.place=place;this.location=location;}
  public JSONObject current(){return data.optJSONObject("current");}
  public JSONObject hourly(){return data.optJSONObject("hourly");}
  public JSONObject daily(){return data.optJSONObject("daily");}
 }
 public static String url(int place){int i=place==1?1:0;return url(new Place(NAMES[i],"Polska",LAT[i],LON[i]));}
 public static String url(Place p){return "https://api.open-meteo.com/v1/forecast?latitude="+p.latitude+"&longitude="+p.longitude+"&current="+CURRENT+"&hourly="+HOURLY+"&daily="+DAILY+"&forecast_days=7&timezone=Europe%2FWarsaw&wind_speed_unit=kmh";}
 public static void validate(JSONObject j)throws Exception{
  JSONObject c=j.getJSONObject("current"),h=j.getJSONObject("hourly"),d=j.getJSONObject("daily");
  for(String field:HOURLY.split(","))if(h.getJSONArray(field).length()!=h.getJSONArray("time").length())throw new IOException("Niepełne dane godzinowe");
  for(String field:DAILY.split(","))if(d.getJSONArray(field).length()!=d.getJSONArray("time").length())throw new IOException("Niepełne dane dzienne");
  if(!Double.isFinite(c.optDouble("temperature_2m",Double.NaN)) || h.getJSONArray("time").length()<24 || d.getJSONArray("time").length()<7)throw new IOException("Niepełna prognoza");
 }
 public static Forecast fetch(Context c,int place)throws Exception{
  Place point=place(c,place);HttpURLConnection connection=(HttpURLConnection)new URL(url(point)).openConnection();connection.setConnectTimeout(12000);connection.setReadTimeout(18000);connection.setRequestProperty("User-Agent","Pomocnik/1.5.6");
  try{
   if(connection.getResponseCode()!=200)throw new IOException("Prognoza chwilowo niedostępna");
   ByteArrayOutputStream out=new ByteArrayOutputStream();try(InputStream in=connection.getInputStream()){byte[] block=new byte[8192];int n;while((n=in.read(block))!=-1){if(Thread.currentThread().isInterrupted())throw new InterruptedIOException();out.write(block,0,n);if(out.size()>1_000_000)throw new IOException("Niepoprawna odpowiedź");}}
   JSONObject data=new JSONObject(out.toString("UTF-8"));validate(data);long now=System.currentTimeMillis();JSONObject saved=new JSONObject().put("fetched",now).put("data",data);c.getSharedPreferences("weather_cache",0).edit().putString(point.key(),saved.toString()).apply();return new Forecast(data,now,place,point);
  }finally{connection.disconnect();}
 }
 public static Forecast cached(Context c,int place){try{Place point=place(c,place);JSONObject j=new JSONObject(c.getSharedPreferences("weather_cache",0).getString(point.key(),""));JSONObject data=j.getJSONObject("data");validate(data);return new Forecast(data,j.getLong("fetched"),place,point);}catch(Exception ignored){return null;}}
 public static double value(JSONObject j,String key,int index){if(j==null)return Double.NaN;if(index<0)return j.optDouble(key,Double.NaN);JSONArray a=j.optJSONArray(key);return a==null || a.isNull(index)?Double.NaN:a.optDouble(index,Double.NaN);}
 public static int code(JSONObject j,String key,int index){double n=value(j,key,index);return Double.isFinite(n)?(int)n:-1;}
 public static String number(double n,String unit){if(!Double.isFinite(n))return "—";return String.format(new Locale("pl","PL"),unit.equals(" mm")?"%.1f%s":"%.0f%s",n,unit);}
 public static String num(JSONObject j,String key,int index,String unit){return number(value(j,key,index),unit);}
 public static long millis(String local){try{return LocalDateTime.parse(local).atZone(ZONE).toInstant().toEpochMilli();}catch(Exception e){return 0;}}
 public static String date(String iso){try{return LocalDate.parse(iso).format(DateTimeFormatter.ofPattern("EEEE, d MMMM",new Locale("pl","PL")));}catch(Exception e){return iso;}}
 public static String clock(String iso){return iso!=null && iso.length()>=16?iso.substring(11,16):"—";}
 public static String direction(double degrees){if(!Double.isFinite(degrees))return "—";String[] labels={"N","NE","E","SE","S","SW","W","NW"};return labels[(int)Math.round(((degrees%360+360)%360)/45)%8];}
 public static String description(int code){switch(code){case 0:return "Bezchmurnie";case 1:return "Pogodnie";case 2:return "Częściowe zachmurzenie";case 3:return "Pochmurno";case 45:case 48:return "Mgła";case 51:case 53:case 55:return "Mżawka";case 56:case 57:return "Marznąca mżawka";case 61:return "Lekki deszcz";case 63:return "Deszcz";case 65:return "Silny deszcz";case 66:case 67:return "Marznący deszcz";case 71:return "Lekki śnieg";case 73:case 75:return "Śnieg";case 77:return "Śnieg ziarnisty";case 80:case 81:case 82:return "Przelotny deszcz";case 85:case 86:return "Przelotny śnieg";case 95:return "Burza";case 96:case 99:return "Burza z gradem";default:return "Opis pogody niedostępny";}}
 public static String symbol(int code,boolean day){if(code==0)return day?"☀️":"🌙";if(code==1)return day?"🌤️":"🌙";if(code==2)return day?"⛅":"☁️";if(code==3)return "☁️";if(code==45 || code==48)return "🌫️";if(code>=95)return "⛈️";if(code>=71 && code<=77 || code==85 || code==86)return "🌨️";if(code==56 || code==57 || code==66 || code==67)return "🌧️❄️";if(code>=51 && code<=82)return "🌧️";return "🌡️";}
 private WeatherRepository(){}
}
