package com.ispina.lokalnie.tube;
import java.util.*;
public interface VideoProvider {
 String name(); boolean accepts(String url); Video resolve(String url)throws Exception;
 Page search(String query,Object cursor)throws Exception;
 final class Page {public List<Video> items=new ArrayList<>();public Object cursor;}
}
