package com.ispina.lokalnie;

import org.json.JSONObject;
import java.net.URL;

final class RussianTvStream {
    static String parse(JSONObject response) {
        if (!"OK".equals(response.optString("status"))) return null;
        JSONObject auth = response.optJSONObject("auth");
        if (auth != null && auth.optInt("code", 0) != 0) return null;
        JSONObject data = response.optJSONObject("data");
        JSONObject streams = data == null ? null : data.optJSONObject("streams");
        String url = streams == null ? "" : streams.optString("m3u8", "");
        return validHls(url);

    }

    static String parseNtv(JSONObject response, String channelCode) {
        JSONObject data = response.optJSONObject("data");
        org.json.JSONArray channels = data == null ? null : data.optJSONArray("channels");
        if (channels == null) return null;
        for (int i = 0; i < channels.length(); i++) {
            JSONObject channel = channels.optJSONObject(i);
            if (channel == null || !channelCode.equals(channel.optString("code"))) continue;
            if (channel.has("allowed") && !channel.optBoolean("allowed", false)) return null;
            return validHls(channel.optString("src", ""));
        }
        return null;
    }

    static String parseVitrina(JSONObject response, String channelCode) {
        JSONObject data = response.optJSONObject("data");
        org.json.JSONArray channels = data == null ? null : data.optJSONArray("channels");
        if (channels == null) return null;
        for (int i = 0; i < channels.length(); i++) {
            JSONObject channel = channels.optJSONObject(i);
            if (channel == null || !channelCode.equals(channel.optString("code"))) continue;
            if (channel.has("allowed") && !channel.optBoolean("allowed", false)) return null;
            return validHls(channel.optString("video_preview_url", ""));
        }
        return null;
    }

    private static String validHls(String url) {
        try {
            URL parsed = new URL(url);
            return "https".equals(parsed.getProtocol()) && !parsed.getHost().isEmpty()
                    && parsed.getPath().endsWith(".m3u8") ? url : null;
        } catch (Exception e) { return null; }
    }

}
