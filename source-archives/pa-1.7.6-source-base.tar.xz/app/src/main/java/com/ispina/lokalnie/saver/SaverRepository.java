package com.ispina.lokalnie.saver;
import android.content.Context;
import com.ispina.lokalnie.deals.DealsRepository;
import org.json.JSONObject;

public final class SaverRepository {
 public static final class Result {public String price="",refund="",note="";public long checked;public boolean stale;}
 public static Result check(Context c,SaverLogic.Topic topic){
  Result r=new Result();boolean fetched=false,refundFetched=false;
  if(!topic.url.isEmpty())try{r.price=SaverLogic.price(topic,DealsRepository.get(topic.url));fetched=true;}catch(Exception ignored){}
  if((topic.kind.equals("plus")||topic.kind.equals("openai"))&&!Thread.currentThread().isInterrupted())try{r.refund=SaverLogic.refund(DealsRepository.get(SaverLogic.REFUND));refundFetched=true;}catch(Exception ignored){}
  if(!fetched&&!refundFetched){Result cache=cached(c,topic);if(cache!=null){cache.stale=true;cache.note="Nie udało się odświeżyć. Zapisane informacje mogą być nieaktualne.";return cache;}r.note="Nie udało się potwierdzić aktualnych cen ani zasad online. Otwórz oficjalne źródło.";return r;}
  r.checked=System.currentTimeMillis();r.note=r.price.isEmpty()?"Cena niepotwierdzona. Otwórz oficjalny cennik i wybierz Polskę oraz swój plan.":"Odczyt ceny z oficjalnego źródła. Ostateczną kwotę sprawdź przed płatnością.";
  if(topic.kind.equals("plus")||topic.kind.equals("openai"))if(r.refund.isEmpty())r.note+=" Nie potwierdzono szczegółowych zasad zwrotu; sprawdź link poniżej.";
  try{JSONObject j=new JSONObject().put("price",r.price).put("refund",r.refund).put("checked",r.checked).put("note",r.note);c.getSharedPreferences("saver_cache",0).edit().putString(topic.kind+":"+SaverLogic.normalize(topic.name),j.toString()).apply();}catch(Exception ignored){}return r;
 }
 public static Result cached(Context c,SaverLogic.Topic t){try{JSONObject j=new JSONObject(c.getSharedPreferences("saver_cache",0).getString(t.kind+":"+SaverLogic.normalize(t.name),""));Result r=new Result();r.price=j.getString("price");r.refund=j.getString("refund");r.note=j.getString("note");r.checked=j.getLong("checked");r.stale=true;return r;}catch(Exception ignored){return null;}}
 private SaverRepository(){}
}
