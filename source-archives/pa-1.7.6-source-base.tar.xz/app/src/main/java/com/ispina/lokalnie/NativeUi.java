package com.ispina.lokalnie;

import android.content.Context;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.RippleDrawable;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public final class NativeUi {
    private NativeUi() {}

    public static final String[] THEME_NAMES={"Fioletowy", "Niebieski", "Błękitny", "Zielony"};
    // Background, ink, muted, border, soft, strong, accent, gradient end.
    private static final int[][] PALETTES={
        {0xFFF8F5FC,0xFF302640,0xFF6B5A7E,0xFFE6DCEE,0xFFF0E8F8,0xFFE8DCF4,0xFF7144A0,0xFF8155A6},
        {0xFFF4F7FD,0xFF21324D,0xFF566784,0xFFDCE5F3,0xFFEAF0FB,0xFFDEE8FA,0xFF365DA7,0xFF4775B6},
        {0xFFF2F9FC,0xFF213C49,0xFF506D7B,0xFFD4E8EF,0xFFE4F3F8,0xFFD4ECF4,0xFF246B8A,0xFF317B99},
        {0xFFF7F8F4,0xFF1F312B,0xFF526961,0xFFDFE7E2,0xFFEDF4F0,0xFFE1EEE8,0xFF2C705B,0xFF427B65}
    };
    public static int theme(Context c){int n=c.getSharedPreferences("appearance",0).getInt("theme",0);return n>=0 && n<PALETTES.length?n:0;}
    public static void setTheme(Context c,int n){if(n>=0 && n<PALETTES.length)c.getSharedPreferences("appearance",0).edit().putInt("theme",n).apply();}
    public static final String[] SHADE_NAMES={"Klasyczny", "Delikatny", "Głęboki"};
    private static final int[][] SHADE_ACCENTS={
        {0xFF8051A7,0xFF875AAE,0xFF5A3675,0xFF674284},
        {0xFF4867A8,0xFF4D75B0,0xFF254980,0xFF365D91},
        {0xFF33758E,0xFF3C7B92,0xFF205569,0xFF28677C},
        {0xFF4A7357,0xFF4C795D,0xFF245440,0xFF32654E}
    };
    private static final java.util.WeakHashMap<Context,int[]> transitions=new java.util.WeakHashMap<>();
    public static int shade(Context c){int n=c.getSharedPreferences("appearance",0).getInt("shade",0);return n>=0 && n<3?n:0;}
    public static int themeKey(Context c){return theme(c)*3+shade(c);}
    public static void setTheme(Context c,int n,int shade){if(n>=0 && n<4 && shade>=0 && shade<3)c.getSharedPreferences("appearance",0).edit().putInt("theme",n).putInt("shade",shade).apply();}
    private static final android.animation.ArgbEvaluator evaluator=new android.animation.ArgbEvaluator();
    public static int blend(int from,int to,float amount){return (Integer)evaluator.evaluate(amount,from,to);}
    static int[] savedPalette(Context c){
        int family=theme(c),tone=shade(c);int[] colors=PALETTES[family].clone();
        if(tone>0){int index=tone==1?0:2;colors[6]=SHADE_ACCENTS[family][index];colors[7]=SHADE_ACCENTS[family][index+1];
            colors[0]=blend(Color.WHITE,colors[5],tone==1?.20f:.40f);
            colors[4]=blend(Color.WHITE,colors[5],tone==1?.40f:.85f);
        }return colors;
    }
    static int[] palette(Context c){int[] frame=transitions.get(c);return frame==null?savedPalette(c):frame;}
    static void transitionPalette(Context c,int[] colors){if(colors==null)transitions.remove(c);else transitions.put(c,colors);}
    private static int color(Context c,int index){return palette(c)[index];}
    public static boolean dark(Context c){return false;}
    public static int bg(Context c){return color(c,0);}
    public static int cardColor(Context c){return Color.WHITE;}
    public static int ink(Context c){return color(c,1);}
    public static int muted(Context c){return color(c,2);}
    public static int line(Context c){return color(c,3);}
    public static int soft(Context c){return color(c,4);}
    public static int softStrong(Context c){return color(c,5);}
    public static int green(Context c){return color(c,6);}
    public static int green(){return Color.rgb(44,112,91);}
    public static int blue(){return Color.rgb(45,127,156);}
    public static int warning(){ return Color.rgb(151,94,25); }
    public static int dp(Context c,float v){ return Math.round(v*c.getResources().getDisplayMetrics().density); }

    public static GradientDrawable rounded(int color,float radiusDp, Context c){
        GradientDrawable d=new PaletteDrawable(); d.setColor(color); d.setCornerRadius(dp(c,radiusDp)); return d;
    }
    public static GradientDrawable roundedStroke(int color,int stroke,float radiusDp, Context c){
        GradientDrawable d=rounded(color,radiusDp,c); d.setStroke(dp(c,1),stroke); return d;
    }
    public static GradientDrawable header(Context c){
        GradientDrawable d=new PaletteDrawable();d.setOrientation(GradientDrawable.Orientation.TL_BR);d.setColors(new int[]{green(c),color(c,7)});
        d.setCornerRadius(dp(c,26));
        return d;
    }
    static final class PaletteDrawable extends GradientDrawable {
        int fill,stroke,width;int[] gradient;
        @Override public void setColor(int color){super.setColor(color);fill=color;gradient=null;}
        @Override public void setStroke(int width,int color){super.setStroke(width,color);this.width=width;stroke=color;}
        @Override public void setColors(int[] colors){super.setColors(colors);gradient=colors.clone();}
    }
    public static TextView text(Context c,String s,float sp,boolean bold){
        TextView v=new TextView(c); v.setText(s); v.setTextColor(ink(c)); v.setTextSize(sp);
        if(bold)v.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL),Typeface.NORMAL);
        v.setIncludeFontPadding(true); v.setLineSpacing(0,1.12f);
        return v;
    }
    public static TextView muted(Context c,String s,float sp){
        TextView v=text(c,s,sp,false); v.setTextColor(muted(c)); return v;
    }
    public static LinearLayout card(Context c){
        LinearLayout l=new LinearLayout(c); l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(c,17),dp(c,16),dp(c,17),dp(c,16));
        l.setBackground(roundedStroke(cardColor(c),line(c),22,c));
        LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(0,0,0,dp(c,12)); l.setLayoutParams(p); l.setElevation(dp(c,1)); return l;
    }
    public static Button button(Context c,String label,boolean secondary){
        Button b=new FeedbackButton(c); b.setText(label); b.setAllCaps(false); b.setTextSize(14);
        b.setTypeface(Typeface.create("sans-serif-medium",Typeface.NORMAL),Typeface.NORMAL); b.setGravity(Gravity.CENTER);
        b.setTextColor(ColorStateList.valueOf(secondary?ink(c):Color.WHITE));
        b.setPadding(dp(c,12),dp(c,8),dp(c,12),dp(c,8));
        int fill=secondary?soft(c):green(c);
        int stroke=secondary?line(c):green(c);
        b.setBackground(new RippleDrawable(ColorStateList.valueOf(secondary?Color.argb(28,46,119,93):Color.argb(45,255,255,255)),roundedStroke(fill,stroke,16,c),null));
        b.setMinHeight(dp(c,48)); b.setMinWidth(0); b.setSingleLine(false); b.setStateListAnimator(null); softTouch(b); return b;
    }
    public static final class FeedbackButton extends Button {
        public FeedbackButton(Context c){ super(c); setHapticFeedbackEnabled(false); }
        @Override public boolean performClick(){
            if(isEnabled() && hasOnClickListeners() && !"no_haptic".equals(getTag())) Haptics.click(getContext());
            return super.performClick();
        }
    }
    public static void onClick(View v, View.OnClickListener listener){
        v.setHapticFeedbackEnabled(false);
        v.setOnClickListener(view->{ Haptics.click(view.getContext()); listener.onClick(view); });
    }
    public static void softTouch(View v){
        v.setOnTouchListener((view,event)->{
            int action=event.getActionMasked();
            if(action==android.view.MotionEvent.ACTION_DOWN)
                view.animate().scaleX(.98f).scaleY(.98f).alpha(.94f).setDuration(120).start();
            else if(action==android.view.MotionEvent.ACTION_UP || action==android.view.MotionEvent.ACTION_CANCEL)
                view.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(155).start();
            return false;
        });
    }
    public static android.widget.EditText input(Context c,String hint){
        android.widget.EditText e=new android.widget.EditText(c);e.setHint(hint);e.setTextColor(ink(c));e.setHintTextColor(muted(c));e.setTextSize(16);e.setPadding(dp(c,14),dp(c,12),dp(c,14),dp(c,12));e.setMinHeight(dp(c,48));e.setBackground(roundedStroke(cardColor(c),line(c),14,c));return e;
    }
    public static void addSpacer(LinearLayout l, Context c, int dp){
        View v=new View(c); l.addView(v,new LinearLayout.LayoutParams(1,NativeUi.dp(c,dp)));
    }
}
