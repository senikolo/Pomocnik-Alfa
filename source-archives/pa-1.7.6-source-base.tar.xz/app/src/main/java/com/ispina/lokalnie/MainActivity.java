package com.ispina.lokalnie;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import com.ispina.lokalnie.reminders.ReminderScheduler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Locale;

public class MainActivity extends ThemedActivity {
    public static final String ISPINA_PACKAGE="com.ispina.mldcheck";
    public static final String ISPINA_VERSION="1.82.35";
    private LinearLayout content;
    private HomeWeatherCard homeWeather;
    private TextView reminderSummary, subscriptionSummary, radioSummary, ispinaStatus, greeting, sunInfo, headerDate;
    private final android.os.Handler clock=new android.os.Handler(android.os.Looper.getMainLooper());
    private final Runnable tick=new Runnable(){public void run(){refreshSun();clock.postDelayed(this,60000);}};

    @Override protected void onCreate(Bundle state){
        super.onCreate(state);
        buildUi();
    }

    private void buildUi(){
        getWindow().setStatusBarColor(NativeUi.green(this));
        getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN|android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
        LinearLayout root=new LinearLayout(this); root.setFocusableInTouchMode(true); root.requestFocus(); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(NativeUi.bg(this));
        
        ScrollView scroll=new ScrollView(this); scroll.setFillViewport(true); content=new LinearLayout(this); content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(NativeUi.dp(this,16),NativeUi.dp(this,12),NativeUi.dp(this,16),NativeUi.dp(this,24)); scroll.addView(content);
        root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1)); setContentView(root);
        content.addView(buildHeader()); NativeUi.addSpacer(content,this,16); buildContent();
    }

    private View buildHeader(){
        LinearLayout h=new LinearLayout(this); h.setOrientation(LinearLayout.VERTICAL); h.setPadding(NativeUi.dp(this,18),NativeUi.dp(this,16),NativeUi.dp(this,18),NativeUi.dp(this,16)); h.setBackground(NativeUi.header(this));
        LinearLayout brand=new LinearLayout(this); brand.setGravity(Gravity.CENTER_VERTICAL);
        ImageView cat=new ImageView(this); cat.setImageResource(com.ispina.lokalnie.R.drawable.ic_launcher_cat_legacy); cat.setScaleType(ImageView.ScaleType.CENTER_CROP); cat.setBackground(NativeUi.rounded(Color.WHITE,17,this)); cat.setClipToOutline(true);
        brand.addView(cat,new LinearLayout.LayoutParams(NativeUi.dp(this,46),NativeUi.dp(this,46)));
        LinearLayout titleBox=new LinearLayout(this); titleBox.setOrientation(LinearLayout.VERTICAL); titleBox.setPadding(NativeUi.dp(this,12),0,0,0);
        TextView small=NativeUi.text(this,"POMOCNIK ALFA 1.7.0",11,true); small.setTextColor(Color.argb(210,255,255,255)); titleBox.addView(small);
        TextView title=NativeUi.text(this,"Dzień dobry",23,true); greeting=title; title.setTextColor(Color.WHITE); titleBox.addView(title);
        TextView date=NativeUi.text(this,new SimpleDateFormat("EEEE, d MMMM",new Locale("pl","PL")).format(new Date()),13,false); headerDate=date; date.setTextColor(Color.argb(225,255,255,255)); titleBox.addView(date);
        brand.addView(titleBox,new LinearLayout.LayoutParams(0,-2,1)); h.addView(brand);

        LinearLayout switcher=new LinearLayout(this); switcher.setPadding(NativeUi.dp(this,4),NativeUi.dp(this,4),NativeUi.dp(this,4),NativeUi.dp(this,4)); switcher.setBackground(NativeUi.rounded(Color.argb(42,255,255,255),16,this));
        LinearLayout.LayoutParams swp=new LinearLayout.LayoutParams(-1,NativeUi.dp(this,42)); swp.topMargin=NativeUi.dp(this,14); h.addView(switcher,swp);
        TextView mine=segment("Pomocnik Alfa",true); TextView il=segment("Ispina Lokalnie",false); switcher.addView(mine,new LinearLayout.LayoutParams(0,-1,1)); switcher.addView(il,new LinearLayout.LayoutParams(0,-1,1));
        NativeUi.softTouch(il); NativeUi.onClick(il,v->openIspinaOrInstall());
        return h;
    }

    private TextView segment(String label, boolean active){
        TextView v=NativeUi.text(this,label,13,true); v.setGravity(Gravity.CENTER); v.setTextColor(active?NativeUi.ink(this):Color.WHITE);
        v.setBackground(active?NativeUi.rounded(Color.WHITE,13,this):NativeUi.rounded(Color.TRANSPARENT,13,this)); return v;
    }

    private void buildContent(){
        homeWeather=new HomeWeatherCard(this);content.addView(homeWeather.view());
        LinearLayout today=NativeUi.card(this); today.addView(NativeUi.text(this,"📅 Dzisiaj",21,true));
        TextView nativeBadge=NativeUi.muted(this,"Spokojnie, wszystko w jednym miejscu",12); LinearLayout.LayoutParams bp=new LinearLayout.LayoutParams(-2,-2); bp.topMargin=NativeUi.dp(this,3); today.addView(nativeBadge,bp);
        reminderSummary=NativeUi.text(this,"Brak aktywnych przypomnień",14,true); subscriptionSummary=NativeUi.text(this,"Brak zapisanych subskrypcji",14,true); radioSummary=NativeUi.muted(this,"Radio: —",13);
        NativeUi.addSpacer(today,this,12); today.addView(reminderSummary); NativeUi.addSpacer(today,this,6); today.addView(subscriptionSummary); NativeUi.addSpacer(today,this,6); today.addView(radioSummary); content.addView(today);
        LinearLayout solar=NativeUi.card(this);solar.addView(NativeUi.text(this,"🌅 Rytm dnia",18,true));
        sunInfo=NativeUi.muted(this,"",14);solar.addView(sunInfo);
        android.widget.Button location=NativeUi.button(this,"Miejsce: Ispina / Warszawa",true);
        location.setOnClickListener(v->{boolean w=getSharedPreferences("home",0).getBoolean("warsaw",false);getSharedPreferences("home",0).edit().putBoolean("warsaw",!w).apply();refreshSun();});
        NativeUi.addSpacer(solar,this,8);solar.addView(location);content.addView(solar);refreshSun();

        LinearLayout ilCard=NativeUi.card(this); LinearLayout row=new LinearLayout(this); row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout info=new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL); info.addView(NativeUi.text(this,"Ispina Lokalnie",18,true)); ispinaStatus=NativeUi.muted(this,"Sprawdzam…",12); info.addView(ispinaStatus); row.addView(info,new LinearLayout.LayoutParams(0,-2,1));
        android.widget.Button go=NativeUi.button(this,"Przełącz",false); go.setOnClickListener(v->openIspinaOrInstall()); row.addView(go,new LinearLayout.LayoutParams(NativeUi.dp(this,110),NativeUi.dp(this,46))); ilCard.addView(row); content.addView(ilCard);

        LinearLayout shopping=NativeUi.card(this);
        shopping.setBackground(NativeUi.roundedStroke(NativeUi.softStrong(this),NativeUi.line(this),24,this));
        shopping.addView(NativeUi.text(this,"🛒 Co kupujemy taniej?",21,true));
        NativeUi.addSpacer(shopping,this,5);
        shopping.addView(NativeUi.muted(this,"Biedronka · Lidl · Aldi · Netto",13));
        NativeUi.addSpacer(shopping,this,12);
        android.widget.EditText product=NativeUi.input(this,"Wpisz produkt, np. mleko");
        product.setSingleLine(true);product.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        Runnable find=()->{String q=product.getText().toString().trim();if(q.length()<2){product.setError("Wpisz nazwę produktu");return;}startActivity(new Intent(this,DealsActivity.class).putExtra("query",q));};
        product.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){find.run();return true;}return false;});
        shopping.addView(product,new LinearLayout.LayoutParams(-1,-2));
        NativeUi.addSpacer(shopping,this,8);
        android.widget.Button findButton=NativeUi.button(this,"Znajdź promocje",false);findButton.setOnClickListener(v->find.run());shopping.addView(findButton,new LinearLayout.LayoutParams(-1,-2));
        NativeUi.addSpacer(shopping,this,8);
        android.widget.Button watches=NativeUi.button(this,"Moje alerty i wszystkie oferty",true);watches.setOnClickListener(v->startActivity(new Intent(this,DealsActivity.class)));shopping.addView(watches,new LinearLayout.LayoutParams(-1,-2));content.addView(shopping);
        addSectionLabel("MEDIA I ODPOCZYNEK");
        addActionCard("Alfa Tube","Filmy, audio w tle i Twoja lokalna biblioteka.",v->startActivity(new Intent(this,TubeActivity.class)));
        addActionCard("Radio","Polskie i niemieckie stacje. Odtwarzanie w tle.",v->startActivity(new Intent(this,RadioActivity.class)));
        addActionCard("Telewizja","TVP3 Kraków, ARD, Rosja 24 i inne kanały z zapasowymi źródłami.",v->startActivity(new Intent(this,TvActivity.class)));
        addActionCard("Lotnictwo · Kraków","EPKK Tower / Approach przez oficjalny odsłuch LiveATC.",v->startActivity(new Intent(this,AviationActivity.class)));
        addActionCard("Chwila spokoju","Mruczenie kota, ptaki, deszcz, szumy i fale. Dźwięki offline z timerem.",v->startActivity(new Intent(this,RainActivity.class)));

        addSectionLabel("TERMINY I PIENIĄDZE");
        addActionCard("Przypomnienia","Bilet 30 lub 90 dni, własne terminy i kontrola powiadomień.",v->startActivity(new Intent(this,RemindersActivity.class)));
        addActionCard("Subskrypcje","Koszty, odnowienia i przypomnienie przed anulowaniem.",v->startActivity(new Intent(this,SubscriptionsActivity.class)));
        addActionCard("Smart Saver","Wpisz usługę lub produkt. Sprawdź koszt, porady i promocje.",v->startActivity(new Intent(this,SmartSaverActivity.class)));
        addActionCard("Oszczędzacz","Porada dnia, cel oszczędzania i przydatne okazje.",v->startActivity(new Intent(this,SavingsActivity.class)));

        addSectionLabel("NARZĘDZIA");
        addActionCard("Ustawienia","12 odcieni motywów, płynna zmiana kolorów i regulacja wibracji dotyku.",v->startActivity(new Intent(this,AppearanceActivity.class)));
        addActionCard("Notatki","Szybka lokalna notatka bez konta i chmury.",v->startActivity(new Intent(this,NotesActivity.class)));
    }

    private void addSectionLabel(String label){
        TextView v=NativeUi.text(this,label,11,true);
        v.setTextColor(NativeUi.muted(this));
        v.setLetterSpacing(.08f);
        v.setPadding(NativeUi.dp(this,4),NativeUi.dp(this,10),0,NativeUi.dp(this,8));
        content.addView(v,new LinearLayout.LayoutParams(-1,-2));
    }

    private void addActionCard(String title,String desc,View.OnClickListener click){
        LinearLayout c=NativeUi.card(this); c.setMinimumHeight(NativeUi.dp(this,82)); c.setClickable(true); c.setFocusable(true); NativeUi.onClick(c,click); NativeUi.softTouch(c);
        LinearLayout r=new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); LinearLayout t=new LinearLayout(this); t.setOrientation(LinearLayout.VERTICAL);
        t.addView(NativeUi.text(this,title,18,true)); TextView d=NativeUi.muted(this,desc,13); d.setLineSpacing(0,1.08f); LinearLayout.LayoutParams dp=new LinearLayout.LayoutParams(-1,-2); dp.topMargin=NativeUi.dp(this,5); t.addView(d,dp);
        String mark = title.equals("Pogoda")?"🌤️":title.equals("Radio")?"📻":title.equals("Telewizja")?"📺":title.startsWith("Lotnictwo")?"✈️":title.equals("Chwila spokoju")?"🌿":title.equals("Łowca promocji")?"🛒":title.equals("Przypomnienia")?"🔔":title.equals("Subskrypcje")?"🔄":title.equals("Smart Saver")?"💡":title.equals("Oszczędzacz")?"💰":title.equals("Notatki")?"📝":"⚙️";
        TextView icon=NativeUi.text(this,mark,22,true); icon.setGravity(Gravity.CENTER); icon.setTextColor(NativeUi.green(this)); icon.setBackground(NativeUi.rounded(NativeUi.soft(this),16,this)); icon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        LinearLayout.LayoutParams ip=new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,48)); ip.rightMargin=NativeUi.dp(this,14); if(title.equals("Alfa Tube")){
            android.widget.ImageView tubeIcon=new android.widget.ImageView(this);
            tubeIcon.setImageResource(R.drawable.ic_alfa_tube);
            tubeIcon.setPadding(NativeUi.dp(this,9),NativeUi.dp(this,9),NativeUi.dp(this,9),NativeUi.dp(this,9));
            tubeIcon.setBackground(NativeUi.header(this));
            tubeIcon.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
            r.addView(tubeIcon,ip);
        }else r.addView(icon,ip);
        r.addView(t,new LinearLayout.LayoutParams(0,-2,1)); TextView arrow=NativeUi.text(this,"›",28,false); arrow.setTextColor(NativeUi.green(this)); arrow.setPadding(NativeUi.dp(this,10),0,NativeUi.dp(this,2),0); arrow.setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO); r.addView(arrow); c.addView(r); content.addView(c);
    }

    @Override protected void onResume(){ super.onResume(); refresh(); if(homeWeather!=null)homeWeather.load(); clock.removeCallbacks(tick);clock.post(tick); }
    @Override protected void onPause(){if(homeWeather!=null)homeWeather.pause();clock.removeCallbacks(tick);super.onPause();}
    @Override protected void onDestroy(){if(homeWeather!=null)homeWeather.close();super.onDestroy();}
    private void refreshSun(){
        long now=System.currentTimeMillis();boolean w=getSharedPreferences("home",0).getBoolean("warsaw",false);SunTimes sun=SunTimes.today(now,w);
        if(greeting!=null)greeting.setText(sun.greeting(now));
        if(headerDate!=null)headerDate.setText(new SimpleDateFormat("EEEE, d MMMM",new Locale("pl","PL")).format(new Date(now)));
        if(sunInfo!=null){long mins=(sun.set-sun.rise)/60000;sunInfo.setText((w?"Warszawa · Berensona":"Ispina")+"\nWschód "+SunTimes.time(sun.rise)+"   Zachód "+SunTimes.time(sun.set)+"\nDzień trwa "+(mins/60)+" godz. "+(mins%60)+" min\nGodziny przybliżone · czas polski");}
    }

    private void refresh(){
        boolean installed=getPackageManager().getLaunchIntentForPackage(ISPINA_PACKAGE)!=null;
        if(ispinaStatus!=null) ispinaStatus.setText(installed?"Zainstalowana • dotknij, aby przejść":"Dołączona wersja "+ISPINA_VERSION+" • gotowa do instalacji");
        String nearest=nearestReminder(); if(reminderSummary!=null) reminderSummary.setText("Przypomnienia: "+nearest);
        String subs=subscriptionSummary(); if(subscriptionSummary!=null) subscriptionSummary.setText("Subskrypcje: "+subs);
        SharedPreferences p=getSharedPreferences("radio_state",0); String rn=p.getString("name",""); boolean playing=p.getBoolean("playing",false);
        if(radioSummary!=null) radioSummary.setText(rn.isEmpty()?"Radio: nic nie gra":"Radio: "+rn+(playing?" • gra":" • zatrzymane"));
        updateDashboardState(this);
    }

    private String nearestReminder(){
        try{
            JSONArray a=new JSONArray(ReminderScheduler.status(this)); long now=System.currentTimeMillis(),best=Long.MAX_VALUE; String title="Brak aktywnych";
            for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i); if(o==null)continue; long at=o.optLong("at",0); if(at>=now&&at<best){best=at;title=o.optString("title","Przypomnienie")+" • "+new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date(at));}}
            return title;
        }catch(Exception e){return "Brak aktywnych";}
    }

    private String subscriptionSummary(){
        SharedPreferences p=getSharedPreferences("native_subscriptions",0); int n=0; double total=0;
        for(Object val:p.getAll().values()) try{JSONObject o=new JSONObject(String.valueOf(val)); n++; double price=o.optDouble("price",0);String cycle=o.optString("cycle","monthly");if("monthly".equals(cycle))total+=price;else if("yearly".equals(cycle))total+=price/12.0;}catch(Exception ignored){}
        if(n==0)return "Brak zapisanych"; NumberFormat nf=NumberFormat.getCurrencyInstance(new Locale("pl","PL")); return n+" • "+nf.format(total)+" / mies.";
    }

    public static void updateDashboardState(android.content.Context c){
        String rem="Brak przypomnień"; try{JSONArray a=new JSONArray(ReminderScheduler.status(c)); long now=System.currentTimeMillis(),best=Long.MAX_VALUE; for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o==null)continue;long at=o.optLong("at",0);if(at>=now&&at<best){best=at;rem=o.optString("title","Przypomnienie")+" • "+new SimpleDateFormat("dd.MM HH:mm",Locale.getDefault()).format(new Date(at));}}}catch(Exception ignored){}
        SharedPreferences sp=c.getSharedPreferences("native_subscriptions",0); int count=0;double total=0;for(Object v:sp.getAll().values())try{JSONObject o=new JSONObject(String.valueOf(v));count++;double price=o.optDouble("price",0);String cycle=o.optString("cycle","monthly");if("monthly".equals(cycle))total+=price;else if("yearly".equals(cycle))total+=price/12.0;}catch(Exception ignored){}
        String subs=count==0?"Brak subskrypcji":count+" subskrypcji • "+NumberFormat.getCurrencyInstance(new Locale("pl","PL")).format(total);
        c.getSharedPreferences("dashboard_state",0).edit().putString("task","Pomocnik Alfa gotowy").putString("reminder",rem).putString("subscriptions",subs).apply();
        TodayWidget.updateAll(c);
    }

    private void openIspinaOrInstall(){
        Intent launch=getPackageManager().getLaunchIntentForPackage(ISPINA_PACKAGE);
        if(launch!=null){ launch.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT); startActivity(launch); return; }
        new AlertDialog.Builder(this).setTitle("Ispina Lokalnie "+ISPINA_VERSION)
                .setMessage("Aplikacja nie jest jeszcze zainstalowana. Pomocnik Alfa ma dołączony APK wersji "+ISPINA_VERSION+" i może otworzyć systemowy instalator.")
                .setNegativeButton("Anuluj",null).setPositiveButton("Instaluj",(d,w)->installBundledIspina()).show();
    }

    private void installBundledIspina(){
        if(Build.VERSION.SDK_INT>=26 && !getPackageManager().canRequestPackageInstalls()){
            try{startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,Uri.parse("package:"+getPackageName())));Toast.makeText(this,"Zezwól Pomocnikowi Alfa instalować aplikacje, a potem wybierz Ispina Lokalnie ponownie.",Toast.LENGTH_LONG).show();}catch(Exception e){Toast.makeText(this,"Włącz instalowanie z nieznanych źródeł dla Pomocnika Alfa.",Toast.LENGTH_LONG).show();} return;
        }
        try{
            File dir=new File(getCacheDir(),"ispina"); if(!dir.exists()&&!dir.mkdirs())throw new Exception("cache");
            File apk=new File(dir,"Ispina-Lokalnie-Live-1.82.35.apk");
            try(InputStream in=getResources().openRawResource(R.raw.ispina_lokalnie_1_82_35); FileOutputStream out=new FileOutputStream(apk)){byte[] b=new byte[64*1024];int n;while((n=in.read(b))>0)out.write(b,0,n);}
            Uri uri=FileProvider.getUriForFile(this,getPackageName()+".fileprovider",apk);
            Intent i=new Intent(Intent.ACTION_VIEW).setDataAndType(uri,"application/vnd.android.package-archive").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(i);
        }catch(ActivityNotFoundException e){Toast.makeText(this,"Nie znaleziono systemowego instalatora APK.",Toast.LENGTH_LONG).show();}
        catch(Exception e){Toast.makeText(this,"Nie udało się przygotować instalacji Ispina Lokalnie.",Toast.LENGTH_LONG).show();}
    }

}
