package com.ispina.lokalnie;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class AviationActivity extends ThemedActivity {
    private static final String EPKK_LIVEATC = "https://m.liveatc.net/feeds/?icao=epkk";
    private static final String EPKK_INFO = "https://www.liveatc.net/search/?icao=krk";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(NativeUi.bg(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(NativeUi.dp(this,14), NativeUi.dp(this,14), NativeUi.dp(this,14), NativeUi.dp(this,28));
        scroll.addView(root);

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back = NativeUi.button(this,"‹",true);
        back.setTextSize(24);
        back.setOnClickListener(v -> finish());
        head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,46)));
        TextView title = NativeUi.text(this,"Lotnictwo · Kraków",24,true);
        title.setPadding(NativeUi.dp(this,12),0,0,0);
        head.addView(title,new LinearLayout.LayoutParams(0,-2,1));
        root.addView(head);

        LinearLayout live = NativeUi.card(this);
        live.addView(NativeUi.text(this,"Kraków Airport / EPKK",19,true));
        TextView d = NativeUi.muted(this,"Rozmowy kontrolerów i pilotów z Kraków-Balice. Odsłuch otwiera się w oficjalnym odtwarzaczu LiveATC.",13);
        NativeUi.addSpacer(live,this,5);
        live.addView(d);
        NativeUi.addSpacer(live,this,12);
        Button listen = NativeUi.button(this,"Słuchaj EPKK Tower / Approach",false);
        listen.setOnClickListener(v -> open(EPKK_LIVEATC));
        live.addView(listen,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,50)));
        root.addView(live);

        LinearLayout freq = NativeUi.card(this);
        freq.addView(NativeUi.text(this,"Częstotliwości EPKK",18,true));
        TextView f = NativeUi.text(this,
                "Tower / Ground: 118.105 MHz\n" +
                "Tower: 123.255 MHz\n" +
                "Approach: 121.075 MHz\n" +
                "Approach: 135.405 MHz\n" +
                "Director: 126.530 MHz\n" +
                "Delivery: 121.980 MHz\n" +
                "ATIS: 126.130 MHz",14,false);
        f.setLineSpacing(0,1.18f);
        NativeUi.addSpacer(freq,this,7);
        freq.addView(f);
        NativeUi.addSpacer(freq,this,10);
        Button details = NativeUi.button(this,"Status feedu i szczegóły",true);
        details.setOnClickListener(v -> open(EPKK_INFO));
        freq.addView(details,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,48)));
        root.addView(freq);

        LinearLayout note = NativeUi.card(this);
        note.addView(NativeUi.text(this,"Ważne",17,true));
        TextView n = NativeUi.muted(this,
                "Pomocnik Alfa nie kopiuje ani nie retransmituje audio LiveATC. Otwiera oficjalny odsłuch dostawcy. Dostępność zależy od aktualnego statusu feedu EPKK.",12);
        NativeUi.addSpacer(note,this,4);
        note.addView(n);
        root.addView(note);

        setContentView(scroll);
    }

    private void open(String url) {
        try {
            startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Throwable e) {
            Toast.makeText(this,"Nie udało się otworzyć odsłuchu.",Toast.LENGTH_LONG).show();
        }
    }
}
