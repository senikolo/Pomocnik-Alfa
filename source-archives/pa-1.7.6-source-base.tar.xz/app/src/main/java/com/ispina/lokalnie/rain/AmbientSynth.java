package com.ispina.lokalnie.rain;
import java.util.Random;
/** Continuous PCM generator with smooth transitions, no network or loops. */
public final class AmbientSynth {
 public static final String[] IDS={"white","pink","brown","rain","storm","ocean","summer","purr"};
 public static final String[] NAMES={"Biały szum","Różowy szum","Brązowy szum","Deszcz","Burza","Fale morza","Lato","Mruczenie kota"};
 private final Random random; private final SummerSound summer; private final CatPurr purr=new CatPurr(); private double low,deep,b0,b1,b2,b3,b4,b5,b6,phase,rumble; private long ticks,thunderAt; private int thunderLeft; private double gain;
 public AmbientSynth(long seed){random=new Random(seed);summer=new SummerSound(seed ^ 0x51a7L);thunderAt=22050L*(12+random.nextInt(16));}
 public static String valid(String mode){for(String x:IDS)if(x.equals(mode))return x;return "rain";}
 public static String name(String mode){for(int i=0;i<IDS.length;i++)if(IDS[i].equals(mode))return NAMES[i];return "Deszcz";}
 public void fill(short[] buffer,String mode,int volume){
  mode=valid(mode);double target=Math.max(0,Math.min(100,volume))/100.0;
  for(int i=0;i<buffer.length;i++){
   double white=random.nextDouble()*2-1;low=.88*low+.12*white;deep=.997*deep+.003*white;
   b0=.99886*b0+white*.0555179;b1=.99332*b1+white*.0750759;b2=.969*b2+white*.153852;b3=.8665*b3+white*.3104856;b4=.55*b4+white*.5329522;b5=-.7616*b5-white*.016898;
   double pink=(b0+b1+b2+b3+b4+b5+b6+white*.5362)*.06;b6=white*.115926;
   phase+=2*Math.PI/(22050*9);if(phase>Math.PI*2)phase-=Math.PI*2;
   ticks++;double sound;
   switch(mode){
    case "purr":sound=purr.sample(white,ticks)*1.8;break;
    case "summer":sound=summer.sample(white,ticks)*2.8;break;
    case "white":sound=white*.22;break;
    case "pink":sound=pink;break;
    case "brown":sound=deep*3.5;break;
    case "ocean":sound=(low*.9+white*.09+deep*1.7)*(.22+.78*(1-Math.cos(phase))/2);break;
    case "storm":
     if(ticks>=thunderAt){thunderLeft=22050*7;thunderAt=ticks+22050L*(20+random.nextInt(24));}
     rumble=.994*rumble+.006*white;
     double envelope=thunderLeft>0?Math.sin(Math.PI*(1-thunderLeft/(22050.0*7))):0;
     if(thunderLeft>0)thunderLeft--;
     sound=low*.65+white*.09+deep*.6+rumble*3*envelope;break;
    default:sound=low*.9+white*.09+deep*.8;
   }
   gain+=(target-gain)*.0008;
   double value=Math.tanh(sound*gain)*26000;buffer[i]=(short)Math.round(value);
  }
 }
}
