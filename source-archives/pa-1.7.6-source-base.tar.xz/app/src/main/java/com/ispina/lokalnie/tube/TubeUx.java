package com.ispina.lokalnie.tube;
/** Small rules shared by the player and its presentation. */
public final class TubeUx {
 private TubeUx(){}
 public static boolean matchesDuration(long seconds,int filter){return filter==0||(seconds>0&&(filter==1?seconds<20*60:seconds>=20*60));}
 public static long resumePosition(long saved,long durationMs){
  if(saved<5000)return 0;
  if(durationMs>0&&(saved>=durationMs||durationMs-saved<=Math.min(10000,durationMs/10)))return 0;
  return saved;
 }
 public static long seekPosition(long position,long delta,long durationMs){long next=Math.max(0,position+delta);return durationMs>0?Math.min(next,durationMs):next;}
}
