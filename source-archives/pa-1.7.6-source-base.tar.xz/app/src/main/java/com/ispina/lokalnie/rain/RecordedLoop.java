package com.ispina.lokalnie.rain;
import java.io.*;
/** Actual recording with a one-second overlapping join. */
public final class RecordedLoop {
 private final short[] samples;private final int overlap;private int position;
 public RecordedLoop(InputStream source,long byteCount)throws IOException{
  if(byteCount<22050*2*5 || byteCount>22050L*2*600 || byteCount%2!=0)throw new IOException("Nieprawidłowe nagranie");samples=new short[(int)(byteCount/2)];overlap=Math.min(22050,samples.length/4);
  try(InputStream in=new BufferedInputStream(source)){byte[] bytes=new byte[8192];int offset=0;while(offset<samples.length){int wanted=Math.min(bytes.length,(samples.length-offset)*2),read=0;while(read<wanted){int n=in.read(bytes,read,wanted-read);if(n<0)throw new EOFException("Niepełne nagranie");read+=n;}for(int i=0;i<wanted;i+=2)samples[offset++]=(short)((bytes[i]&255)|(bytes[i+1]<<8));}}
 }
 public double sample(){double v=samples[position];int join=samples.length-overlap;if(position>=join){double fraction=(position-join)/(double)overlap;v=v*(1-fraction)+samples[position-join]*fraction;}if(++position==samples.length)position=overlap;return v;}
}
