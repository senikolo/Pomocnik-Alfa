package com.ispina.lokalnie.rain;
import java.util.Random;
/** Procedural summer ambience: separate birds, insect choruses and soft foliage. */
final class SummerSound {
 private static final double RATE=22050,TAU=2*Math.PI;
 private final Random random;private final Bird[] birds=new Bird[3];private double wind,slow,cricketPhase,buzzPhase,clock;
 SummerSound(long seed){random=new Random(seed);for(int i=0;i<birds.length;i++)birds[i]=new Bird(i);}
 double sample(double white,long tick){
  clock=tick/RATE;wind=.96*wind+.04*white;slow=.9997*slow+.0003*white;
  double breeze=wind*(.09+.04*Math.sin(clock*.37))+slow*.15;
  cricketPhase=(cricketPhase+TAU*4200/RATE)%TAU;buzzPhase=(buzzPhase+TAU*5700/RATE)%TAU;
  double pulse=Math.pow(Math.max(0,Math.sin(clock*TAU*3.7)),5);
  double chorus=(.35+.65*Math.pow(Math.sin(clock*.23+1),2));
  double insects=(Math.sin(cricketPhase)*pulse*.025+Math.sin(buzzPhase)*.006)*chorus;
  double song=0;for(Bird bird:birds)song+=bird.sample(tick);
  return breeze+insects+song;
 }
 private final class Bird {
  private final int voice;private long next,start;private int duration,count;private double base,phase,shape;
  Bird(int voice){this.voice=voice;next=(long)(RATE*(.4+voice*1.6+random.nextDouble()));}
  double sample(long now){
   if(now>=next){start=now;duration=(int)(RATE*(.13+random.nextDouble()*.22));count=2+random.nextInt(4);base=1800+voice*750+random.nextDouble()*900;shape=random.nextDouble()*TAU;next=now+(long)(RATE*(3+random.nextDouble()*6));}
   long elapsed=now-start;if(start==0)return 0;int gap=(int)(duration*1.45);int syllable=(int)(elapsed/gap);if(syllable>=count)return 0;int pos=(int)(elapsed%gap);if(pos>=duration)return 0;
   double p=pos/(double)duration;double envelope=Math.pow(Math.sin(Math.PI*p),1.8);
   double frequency=base+850*Math.sin(Math.PI*p+shape*.2)+250*Math.sin(p*TAU*3+shape)+syllable*80;
   phase=(phase+TAU*frequency/RATE)%TAU;
   return (Math.sin(phase)+.16*Math.sin(phase*2))*envelope*(.045-voice*.008);
  }
 }
}
