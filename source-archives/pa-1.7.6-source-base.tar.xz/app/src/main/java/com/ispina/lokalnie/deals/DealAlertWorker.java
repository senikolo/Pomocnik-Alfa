package com.ispina.lokalnie.deals;
import android.app.*;
import android.content.*;
import android.os.Build;
import androidx.annotation.NonNull;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.work.*;
import com.ispina.lokalnie.DealsActivity;
import java.util.*;
public class DealAlertWorker extends Worker {
 public DealAlertWorker(@NonNull Context c,@NonNull WorkerParameters p){super(c,p);}
 @NonNull @Override public Result doWork(){
  Context c=getApplicationContext();boolean failed=false;
  NotificationManager nm=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);
  if(Build.VERSION.SDK_INT>=26 && nm!=null)nm.createNotificationChannel(new NotificationChannel("promotion_alerts","Promocje na obserwowane produkty",NotificationManager.IMPORTANCE_DEFAULT));
  for(String q:DealAlerts.list(c)){
   if(isStopped())break;DealsRepository.Result r=DealsRepository.search(c,q);if(r.stale || (r.partial && r.offers.isEmpty())){failed=true;c.getSharedPreferences("deal_alerts",0).edit().putLong("checked:"+DealsRepository.key(q),System.currentTimeMillis()).putString("status:"+DealsRepository.key(q),"Źródła niedostępne · spróbuję ponownie").apply();continue;}
   r.offers.removeIf(d->!d.promotion || d.currentPrice);
   // Re-check membership to avoid delivering an alert removed during the download.
   boolean subscribed=false;for(String x:DealAlerts.list(c))if(DealsRepository.key(x).equals(DealsRepository.key(q)))subscribed=true;if(!subscribed)continue;
   c.getSharedPreferences("deal_alerts",0).edit().putLong("checked:"+DealsRepository.key(q),r.checked).putString("status:"+DealsRepository.key(q),r.offers.isEmpty()?"Brak znalezionej promocji":"Znalezione oferty: "+r.offers.size()+(r.partial?" · niepełne źródła":"")).apply();
   if(r.offers.isEmpty()){c.getSharedPreferences("deal_alerts",0).edit().remove("seen:"+DealsRepository.key(q)).apply();continue;}
   List<String> fingerprints=new ArrayList<>();for(Deal d:r.offers)fingerprints.add(d.id+":"+d.price+":"+d.end+":"+d.minimum+":"+d.card);Collections.sort(fingerprints);String finger=String.join("|",fingerprints);
   String key="seen:"+DealsRepository.key(q);if(finger.equals(c.getSharedPreferences("deal_alerts",0).getString(key,"")))continue;
   if(!NotificationManagerCompat.from(c).areNotificationsEnabled())continue;
   Map<String,Deal> shops=new LinkedHashMap<>();for(Deal d:r.offers){Deal old=shops.get(d.store);if(old==null || d.price<old.price)shops.put(d.store,d);}
   StringBuilder body=new StringBuilder();for(Deal d:shops.values()){if(body.length()>0)body.append("\n");body.append(d.store).append(" · ").append(d.priceLabel()).append(" · do ").append(d.end).append("\n").append(d.terms());}
   Intent open=new Intent(c,DealsActivity.class).putExtra("query",q);int id=DealAlerts.notificationId(q);
   PendingIntent pi=PendingIntent.getActivity(c,id,open,PendingIntent.FLAG_UPDATE_CURRENT|(Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0));
   NotificationCompat.Builder b=new NotificationCompat.Builder(c,"promotion_alerts").setSmallIcon(android.R.drawable.ic_dialog_info).setContentTitle("Promocja: "+q).setContentText("Nowe oferty w "+shops.size()+" sieciach · sprawdź warunki").setStyle(new NotificationCompat.BigTextStyle().bigText(body.toString())).setContentIntent(pi).setAutoCancel(true);
   try{NotificationManagerCompat.from(c).notify(id,b.build());c.getSharedPreferences("deal_alerts",0).edit().putString(key,finger).apply();}catch(SecurityException ignored){}
  }
  if(!isStopped())c.getSharedPreferences("deal_alerts",0).edit().putLong("last_finished",System.currentTimeMillis()).apply();
  return failed && getRunAttemptCount()<2?Result.retry():Result.success();
 }
}
