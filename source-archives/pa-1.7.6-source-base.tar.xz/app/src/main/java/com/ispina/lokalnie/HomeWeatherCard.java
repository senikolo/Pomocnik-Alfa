package com.ispina.lokalnie;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Color;
import android.os.*;
import android.widget.*;
import com.ispina.lokalnie.weather.WeatherRepository;
import com.ispina.lokalnie.weather.WeatherRepository.Forecast;
import org.json.JSONObject;
import java.time.LocalDate;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.concurrent.*;

/** Current conditions on the dashboard; full forecast remains on WeatherActivity. */
final class HomeWeatherCard {
 private final Activity activity;private final Handler ui=new Handler(Looper.getMainLooper());
 private final ExecutorService executor=Executors.newFixedThreadPool(2);private Future<?> request;
 private final Button[] locations=new Button[2];private TextView temperature,description,details,status;
 private int place,generation;private boolean destroyed;
 HomeWeatherCard(Activity a){activity=a;place=a.getSharedPreferences("home_weather",0).getInt("place",0)==1?1:0;}
 LinearLayout view(){
  LinearLayout card=NativeUi.card(activity);card.addView(NativeUi.text(activity,"🌤️ Pogoda na teraz",20,true));NativeUi.addSpacer(card,activity,12);
  LinearLayout choices=new LinearLayout(activity);choices.setBaselineAligned(false);
  for(int i=0;i<2;i++){final int id=i;Button b=NativeUi.button(activity,i==0?"Ispina":"Warszawa\nBerensona",true);locations[i]=b;b.setOnClickListener(v->{if(place!=id){place=id;activity.getSharedPreferences("home_weather",0).edit().putInt("place",place).apply();load();}});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,NativeUi.dp(activity,64),1);if(i>0)p.leftMargin=NativeUi.dp(activity,8);choices.addView(b,p);}card.addView(choices);NativeUi.addSpacer(card,activity,12);
  temperature=NativeUi.text(activity,"—",32,true);card.addView(temperature);description=NativeUi.text(activity,"Pobieram pogodę…",16,true);card.addView(description);details=NativeUi.muted(activity,"",14);details.setPadding(0,NativeUi.dp(activity,6),0,0);card.addView(details);status=NativeUi.muted(activity,"",12);status.setPadding(0,NativeUi.dp(activity,8),0,0);status.setAccessibilityLiveRegion(android.view.View.ACCESSIBILITY_LIVE_REGION_POLITE);card.addView(status);NativeUi.addSpacer(card,activity,12);
  Button expand=NativeUi.button(activity,"Rozwiń pełną pogodę  ›",false);expand.setOnClickListener(v->activity.startActivity(new Intent(activity,WeatherActivity.class).putExtra("place",place)));card.addView(expand,new LinearLayout.LayoutParams(-1,-2));select();return card;
 }
 private void select(){for(int i=0;i<2;i++){boolean active=place==i;Button b=locations[i];b.setSelected(active);b.setTextColor(active?Color.WHITE:NativeUi.ink(activity));b.setBackground(NativeUi.roundedStroke(active?NativeUi.green(activity):NativeUi.soft(activity),active?NativeUi.green(activity):NativeUi.line(activity),16,activity));b.setContentDescription(b.getText()+(active?", wybrano":""));}}
 private boolean fresh(Forecast f){return f!=null && System.currentTimeMillis()-f.fetched<30*60000L && f.current().optString("time").startsWith(LocalDate.now(WeatherRepository.ZONE).toString());}
 void load(){
  if(destroyed)return;int id=++generation,target=place;if(request!=null)request.cancel(true);select();Forecast cached=WeatherRepository.cached(activity,target);
  if(cached!=null){show(cached);if(fresh(cached)){status.setText("Aktualizacja: "+stamp(cached.fetched));return;}status.setText("Odświeżam zapis z "+stamp(cached.fetched));}
  else{temperature.setText("—");description.setText("Pobieram pogodę…");details.setText("");status.setText(WeatherRepository.NAMES[target]);}
  request=executor.submit(()->{Forecast answer=null;try{answer=WeatherRepository.fetch(activity.getApplicationContext(),target);}catch(Exception ignored){}final Forecast result=answer;ui.post(()->{if(destroyed || generation!=id)return;if(result!=null){show(result);status.setText("Aktualizacja: "+stamp(result.fetched));}else if(cached!=null){status.setText("Brak połączenia · zapis z "+stamp(cached.fetched)+" może być nieaktualny.");}else{description.setText("Pogoda chwilowo niedostępna");status.setText("Sprawdź internet lub otwórz pełną pogodę.");}});});
 }
 private String stamp(long time){SimpleDateFormat f=new SimpleDateFormat("dd.MM, HH:mm",new Locale("pl","PL"));f.setTimeZone(SunTimes.ZONE);return f.format(new Date(time));}
 private void show(Forecast f){JSONObject c=f.current();temperature.setText(WeatherRepository.symbol(c.optInt("weather_code",-1),c.optInt("is_day",1)==1)+"  "+WeatherRepository.num(c,"temperature_2m",-1,"°C"));description.setText(WeatherRepository.description(c.optInt("weather_code",-1)));details.setText("Odczuwalna "+WeatherRepository.num(c,"apparent_temperature",-1,"°C")+"  ·  Wiatr "+WeatherRepository.num(c,"wind_speed_10m",-1," km/h"));}
 void pause(){generation++;if(request!=null)request.cancel(true);}
 void close(){destroyed=true;pause();executor.shutdownNow();ui.removeCallbacksAndMessages(null);}
}
