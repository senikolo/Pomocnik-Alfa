package com.ispina.lokalnie.tube;
import android.content.*;import org.json.*;
public final class TubeStore {
 public final SharedPreferences prefs;public TubeStore(Context c){prefs=c.getSharedPreferences("alfa_tube",0);}
 public JSONArray list(String key){try{return new JSONArray(prefs.getString(key,"[]"));}catch(Exception e){return new JSONArray();}}
 public synchronized void add(String key,Video v){JSONArray a=list(key),b=new JSONArray();b.put(v.json());for(int i=0;i<a.length()&&b.length()<200;i++){JSONObject x=a.optJSONObject(i);if(x!=null&&!x.optString("url").equals(v.url))b.put(x);}save(key,b);}
 public void save(String key,JSONArray a){prefs.edit().putString(key,a.toString()).apply();}
 public void history(Video v,long pos){if(!prefs.getBoolean("history_enabled",true))return;add("history",v);prefs.edit().putLong("position:"+v.url,Math.max(0,pos)).putLong("date:"+v.url,System.currentTimeMillis()).apply();}
 public void clearHistory(){SharedPreferences.Editor e=prefs.edit().remove("history");for(String k:prefs.getAll().keySet())if(k.startsWith("position:")||k.startsWith("date:"))e.remove(k);e.apply();}
 public void rememberSearch(String query){String term=query.trim();if(term.isEmpty()||term.startsWith("https://"))return;JSONArray old=list("searches"),fresh=new JSONArray();fresh.put(term);for(int i=0;i<old.length()&&fresh.length()<8;i++){String prior=old.optString(i);if(!prior.equalsIgnoreCase(term))fresh.put(prior);}save("searches",fresh);}
 public void clearSearches(){prefs.edit().remove("searches").apply();}
 public boolean flag(String k,boolean d){return prefs.getBoolean(k,d);}
}
