package com.ispina.lokalnie.rain;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.media.AudioAttributes;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;

import com.ispina.lokalnie.RainActivity;



public class RainService extends Service {
    public static final String ACTION_PLAY="com.senikolo.pomocniknowy.RAIN_PLAY";
    public static final String ACTION_STOP="com.senikolo.pomocniknowy.RAIN_STOP";
    public static final String ACTION_VOLUME="com.senikolo.pomocniknowy.RAIN_VOLUME";
    public static final String ACTION_TIMER="com.senikolo.pomocniknowy.RAIN_TIMER";

    private static final String CHANNEL="pomocnik_rain";
    private static final int NOTIFICATION_ID=9202;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private volatile boolean running=false;
    private volatile int intensity=40;
    private volatile String mode="rain";
    private volatile long generation=0;
    private PowerManager.WakeLock wakeLock;
    private Thread audioThread;
    private volatile AudioTrack track;
    private AudioManager audioManager;
    private long stopAt=0;

    private final Runnable stopRunnable=()->stopRain(true);
    private final AudioManager.OnAudioFocusChangeListener focusListener=change->{
        if(change==AudioManager.AUDIOFOCUS_LOSS || change==AudioManager.AUDIOFOCUS_LOSS_TRANSIENT) stopRain(true);
    };

    @Override public void onCreate(){
        super.onCreate();
        createChannel();
        audioManager=(AudioManager)getSystemService(Context.AUDIO_SERVICE);
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        if(intent==null){stopSelf();return START_NOT_STICKY;}
        String action=intent.getAction();
        if(ACTION_VOLUME.equals(action)){
            intensity=Math.max(0,Math.min(100,intent.getIntExtra("intensity",40)));saveState(running);if(!running)stopSelf();return START_NOT_STICKY;
        }
        if(ACTION_STOP.equals(action)){ stopRain(true); return START_NOT_STICKY; }
        if(ACTION_TIMER.equals(action)){
            int minutes=intent==null?0:intent.getIntExtra("minutes",0);
            if(!running){ stopAt=0; saveState(false); stopSelf(); }
            else setTimer(minutes);
            return START_NOT_STICKY;
        }
        intensity=Math.max(0,Math.min(100,intent.getIntExtra("intensity",getSharedPreferences("rain_state",0).getInt("intensity",40))));
        mode=AmbientSynth.valid(intent.getStringExtra("mode"));
        startRain();
        return START_NOT_STICKY;
    }

    private void startRain(){
        saveState(true);
        startForeground(NOTIFICATION_ID,notification());
        if(running){ updateNotification(); return; }
        try{ if(audioManager!=null && audioManager.requestAudioFocus(focusListener,AudioManager.STREAM_MUSIC,AudioManager.AUDIOFOCUS_GAIN)!=AudioManager.AUDIOFOCUS_REQUEST_GRANTED){stopRain(true);return;} }catch(RuntimeException e){stopRain(true);return;}
        running=true;
        long token=++generation;
        try{PowerManager pm=(PowerManager)getSystemService(POWER_SERVICE);wakeLock=pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK,"Pomocnik:Ambient");wakeLock.acquire();}catch(RuntimeException ignored){}
        audioThread=new Thread(()->audioLoop(token),"Pomocnik-Ambient");
        audioThread.start();
    }

    private void audioLoop(long token){
        final int sampleRate=22050;
        int min=AudioTrack.getMinBufferSize(sampleRate,AudioFormat.CHANNEL_OUT_MONO,AudioFormat.ENCODING_PCM_16BIT);
        int samples=Math.max(2048,min/2); AudioTrack local=null;
        try{
            local=new AudioTrack.Builder().setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build())
                .setAudioFormat(new AudioFormat.Builder().setEncoding(AudioFormat.ENCODING_PCM_16BIT).setSampleRate(sampleRate).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build())
                .setBufferSizeInBytes(samples*4).setTransferMode(AudioTrack.MODE_STREAM).build();
            if(!running || token!=generation)return;
            track=local; local.play(); short[] buffer=new short[samples];AmbientPlayer synth=new AmbientPlayer(this);
            while(running && token==generation){
                synth.fill(buffer,mode,intensity);
                if(!running || token!=generation)break;
                if(local.write(buffer,0,buffer.length)<0)break;
            }
        }catch(Exception ignored){}
        finally{
            if(local!=null){try{local.pause();local.flush();local.release();}catch(RuntimeException ignored){}}
            if(track==local)track=null;
            if(running && token==generation)handler.post(()->{if(token==generation)stopRain(true);});
        }
    }

    private void setTimer(int minutes){
        handler.removeCallbacks(stopRunnable);
        if(minutes<=0){ stopAt=0; }
        else { stopAt=System.currentTimeMillis()+minutes*60_000L; handler.postDelayed(stopRunnable,minutes*60_000L); }
        saveState(running);
        if(running) updateNotification();
    }

    private void stopRain(boolean stopService){
        running=false;
        generation++;
        if(wakeLock!=null && wakeLock.isHeld())wakeLock.release();wakeLock=null;
        stopAt=0;
        handler.removeCallbacks(stopRunnable);
        try{ if(track!=null) track.pause(); }catch(Throwable ignored){}
        try{ if(audioManager!=null) audioManager.abandonAudioFocus(focusListener); }catch(Throwable ignored){}
        saveState(false);
        try{ stopForeground(true); }catch(Throwable ignored){}
        if(stopService) stopSelf();
    }

    private void saveState(boolean playing){
        getSharedPreferences("rain_state",0).edit().putBoolean("playing",playing).putString("mode",mode).putInt("intensity",intensity).putLong("stop_at",stopAt).apply();
    }

    private Notification notification(){
        Intent open=new Intent(this,RainActivity.class);
        int pf=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
        PendingIntent content=PendingIntent.getActivity(this,0,open,pf);
        Intent stop=new Intent(this,RainService.class).setAction(ACTION_STOP);
        PendingIntent stopPi=PendingIntent.getService(this,1,stop,pf);
        Notification.Builder b=Build.VERSION.SDK_INT>=26?new Notification.Builder(this,CHANNEL):new Notification.Builder(this);
        b.setSmallIcon(android.R.drawable.ic_media_play)
                .setContentTitle("Pomocnik Alfa · "+AmbientSynth.name(mode))
                .setContentText(stopAt>System.currentTimeMillis()?AmbientSynth.name(mode)+" • timer aktywny":AmbientSynth.name(mode)+" gra w tle")
                .setOngoing(true)
                .setContentIntent(content)
                .addAction(android.R.drawable.ic_media_pause,"Zatrzymaj",stopPi);
        if(Build.VERSION.SDK_INT<26)b.setPriority(Notification.PRIORITY_LOW);
        return b.build();
    }

    private void updateNotification(){
        NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
        if(nm!=null)nm.notify(NOTIFICATION_ID,notification());
    }

    private void createChannel(){
        if(Build.VERSION.SDK_INT>=26){
            NotificationManager nm=(NotificationManager)getSystemService(Context.NOTIFICATION_SERVICE);
            if(nm!=null){
                NotificationChannel c=new NotificationChannel(CHANNEL,"Dźwięki do odpoczynku",NotificationManager.IMPORTANCE_LOW);
                c.setDescription("Odtwarzanie szumów i dźwięków natury w tle");
                nm.createNotificationChannel(c);
            }
        }
    }

    @Override public void onDestroy(){ stopRain(false); super.onDestroy(); }
    @Override public IBinder onBind(Intent intent){ return null; }
}
