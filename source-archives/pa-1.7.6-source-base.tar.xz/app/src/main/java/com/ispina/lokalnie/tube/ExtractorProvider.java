package com.ispina.lokalnie.tube;
import java.util.*;
import org.schabi.newpipe.extractor.*;
import org.schabi.newpipe.extractor.search.SearchInfo;
import org.schabi.newpipe.extractor.stream.*;
import org.schabi.newpipe.extractor.downloader.*;
import java.net.*;import java.io.*;
public final class ExtractorProvider implements VideoProvider {
 public ExtractorProvider(){NewPipe.init(new HttpDownloader());}
 public String name(){return "YouTube / PeerTube";}
 public boolean accepts(String u){try{NewPipe.getServiceByUrl(u);return true;}catch(Exception e){return false;}}
 public Page search(String q,Object cursor)throws Exception{
 Page out=new Page();if(cursor==null){SearchInfo i=SearchInfo.getInfo(NewPipe.getService(0),NewPipe.getService(0).getSearchQHFactory().fromQuery(q,Collections.singletonList("videos"),""));for(InfoItem item:i.getRelatedItems())if(item instanceof StreamInfoItem)out.items.add(item((StreamInfoItem)item));out.cursor=i.getNextPage();}
 else {Object[] c=(Object[])cursor;ListExtractor.InfoItemsPage<InfoItem> i=SearchInfo.getMoreItems(NewPipe.getService(0),NewPipe.getService(0).getSearchQHFactory().fromQuery((String)c[0],Collections.singletonList("videos"),""),(org.schabi.newpipe.extractor.Page)c[1]);for(InfoItem it:i.getItems())if(it instanceof StreamInfoItem)out.items.add(item((StreamInfoItem)it));out.cursor=i.getNextPage();}
 if(out.cursor!=null && org.schabi.newpipe.extractor.Page.isValid((org.schabi.newpipe.extractor.Page)out.cursor))out.cursor=new Object[]{q,out.cursor};else out.cursor=null;return out;}
 public static Video item(StreamInfoItem i){Video v=new Video();v.url=i.getUrl();v.title=i.getName();v.author=i.getUploaderName();v.channel=i.getUploaderUrl();v.duration=i.getDuration();v.thumb=i.getThumbnails().isEmpty()?"":i.getThumbnails().get(0).getUrl();v.provider="extractor";return v;}
 public Video resolve(String u)throws Exception{
 StreamInfo i=StreamInfo.getInfo(NewPipe.getServiceByUrl(u),u);Video v=new Video();v.url=u;v.title=i.getName();v.author=i.getUploaderName();v.channel=i.getUploaderUrl();v.duration=i.getDuration();v.thumb=i.getThumbnails().isEmpty()?"":i.getThumbnails().get(0).getUrl();v.license=i.getLicence();v.provider="extractor";
 v.downloadable=v.license!=null&&(v.license.toLowerCase(Locale.ROOT).contains("creative commons")||v.license.toLowerCase(Locale.ROOT).contains("cc by"));
 for(VideoStream s:i.getVideoStreams())add(v.video,s,false,s.getResolution(),s.getHeight());
 for(VideoStream s:i.getVideoOnlyStreams())add(v.video,s,true,s.getResolution(),s.getHeight());
 for(AudioStream s:i.getAudioStreams()){Video.Source a=source(s,s.getAverageBitrate()+" kb/s · "+(s.getAudioTrackName()==null?"audio":s.getAudioTrackName()));if(a!=null){a.language=s.getAudioLocale()==null?"":s.getAudioLocale().toLanguageTag();v.audio.add(a);}}
 for(SubtitlesStream s:i.getSubtitles()){Video.Source a=source(s,s.getDisplayLanguageName());if(a!=null){a.language=s.getLanguageTag();v.subtitles.add(a);}}
 if(v.video.isEmpty()&&!i.getHlsUrl().isEmpty())v.video.add(new Video.Source(i.getHlsUrl(),"HLS · automatyczna","application/x-mpegURL","m3u8"));
 for(InfoItem x:i.getRelatedItems())if(x instanceof StreamInfoItem)v.related.add(item((StreamInfoItem)x));
 if(v.video.isEmpty()&&v.audio.isEmpty())throw new IOException("Źródło nie udostępnia odtwarzalnego strumienia.");return v;}
 static void add(List<Video.Source> to,VideoStream s,boolean separate,String label,int h){Video.Source a=source(s,label);if(a!=null){a.separate=separate;a.height=h;to.add(a);}}
 static Video.Source source(Stream s,String label){if(!s.isUrl()||s.getDeliveryMethod()!=DeliveryMethod.PROGRESSIVE_HTTP)return null;MediaFormat f=s.getFormat();return new Video.Source(s.getContent(),label,f==null?"application/octet-stream":f.mimeType,f==null?"bin":f.suffix);}
 static final class HttpDownloader extends Downloader {
 public Response execute(Request r)throws IOException {HttpURLConnection c=(HttpURLConnection)new URL(r.url()).openConnection();try{c.setConnectTimeout(15000);c.setReadTimeout(20000);c.setRequestMethod(r.httpMethod());c.setRequestProperty("User-Agent","Mozilla/5.0");for(Map.Entry<String,List<String>> h:r.headers().entrySet())for(String val:h.getValue())c.addRequestProperty(h.getKey(),val);if(r.dataToSend()!=null){c.setDoOutput(true);try(OutputStream o=c.getOutputStream()){o.write(r.dataToSend());}}int code=c.getResponseCode();InputStream in=code>=400?c.getErrorStream():c.getInputStream();ByteArrayOutputStream bytes=new ByteArrayOutputStream();if(in!=null)try(InputStream s=in){byte[] b=new byte[8192];int n;while((n=s.read(b))!=-1){if(bytes.size()+n>16*1024*1024)throw new IOException("Odpowiedź jest zbyt duża.");bytes.write(b,0,n);}}return new Response(code,c.getResponseMessage(),c.getHeaderFields(),bytes.toString("UTF-8"),c.getURL().toString());}finally{c.disconnect();}}
 }
}
