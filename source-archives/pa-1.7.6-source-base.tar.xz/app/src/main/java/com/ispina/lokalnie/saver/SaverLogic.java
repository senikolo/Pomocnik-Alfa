package com.ispina.lokalnie.saver;
import java.text.Normalizer;
import java.math.*;
import java.util.*;
import java.util.regex.*;

/** Local tips and conservative extraction of publicly stated prices. */
public final class SaverLogic {
 public static final String REFUND="https://help.openai.com/en/articles/7232895-how-do-i-request-a-refund-for-my-chatgpt-subscription";
 public static final class Topic {
  public final String name,tip,url;public final boolean service;public final String kind;
  Topic(String n,String t,String u,boolean s,String k){name=n;tip=t;url=u;service=s;kind=k;}
 }
 public static String normalize(String q){return Normalizer.normalize(q.toLowerCase(Locale.ROOT),Normalizer.Form.NFD).replaceAll("\\p{M}","").replace('ł','l').replaceAll("[^a-z0-9]+"," ").trim();}
 private static boolean has(String s,String...words){for(String w:words)if(s.contains(w))return true;return false;}
 public static Topic topic(String query,int mode){
  String q=normalize(query);
  if(mode!=2){
   if(has(q,"netflix"))return new Topic("Netflix","Wykup miesiąc wtedy, gdy masz czas na oglądanie. Anulowanie odnowienia pozwala zwykle oglądać do końca opłaconego okresu; usunięcie aplikacji nie anuluje abonamentu. Sprawdź sposób rozliczenia na swoim koncie.","https://help.netflix.com/pl/node/24926",true,"netflix");
   if(has(q,"chatgpt","chat gpt","openai"))return new Topic(query,"Zacznij od bezpłatnego planu i sprawdź, czy płatne funkcje są Ci potrzebne. Anulowanie zatrzymuje kolejne odnowienia. Zwrot wymaga osobnego wniosku i zależy od zakupu oraz zasad dostawcy.","https://help.openai.com/en/articles/6950777-what-is-chatgpt-plus",true,q.equals("chatgpt plus")||q.equals("chat gpt plus")?"plus":"openai");
   if(has(q,"spotify"))return new Topic("Spotify","Porównaj dostępne plany z liczbą osób, które rzeczywiście będą korzystać. Przed okresem próbnym sprawdź cenę po promocji i ustaw przypomnienie. Pakiety wspólne wybieraj zgodnie z ich warunkami.","https://www.spotify.com/pl/premium/",true,"other");
   if(has(q,"youtube","you tube"))return new Topic("YouTube Premium","Sprawdź, czy wystarczy Ci bezpłatna wersja. Porównaj cenę i zakres planu na stronie z ofertą w aplikacji. Oferta próbna może dotyczyć tylko nowych lub wybranych klientów.","https://www.youtube.com/premium",true,"other");
   if(has(q,"disney"))return new Topic("Disney+","Zaplanuj miesiące oglądania. Plan roczny porównaj z liczbą miesięcy, w których będziesz korzystać; niższa cena miesięczna nie musi oznaczać niższego łącznego wydatku.","https://www.disneyplus.com/pl-pl",true,"other");
   if(has(q,"amazon prime","prime video"))return new Topic("Amazon Prime","Przed zakupem porównaj miesięczny i roczny koszt oraz sprawdź, czy wykorzystasz pozostałe korzyści. Okres próbny może przejść w płatny abonament.","https://www.amazon.pl/prime",true,"other");
   if(q.equals("max")||has(q,"hbo"))return new Topic(query,"Nie opłacaj kilku serwisów z podobnymi treściami bez przerwy. Zaplanuj oglądanie i porównaj cenę po zakończeniu promocji.","https://www.hbomax.com/pl/pl",true,"other");
   if(has(q,"abonament","subskrypcj","internet","telefon","canal","player" )||mode==1)return new Topic(query,"Sprawdź koszt po promocji, okres zobowiązania, dodatkowe opłaty i termin wypowiedzenia. Policz pełny koszt umowy. Porównaj z rachunkiem i ustaw przypomnienie przed odnowieniem.","",true,"other");
  }
  String tip="Porównaj cenę za kilogram, litr lub sztukę. Uwzględnij minimalny zakup, kartę klienta i termin promocji. Niższa cena opakowania nie zawsze oznacza oszczędność.";
  if(has(q,"mleko","jogurt","ser"))tip="Porównuj cenę za litr lub kilogram. Kupuj tyle, ile zużyjesz przed terminem ważności. Promocja na kilka sztuk opłaca się, jeśli rzeczywiście ich potrzebujesz.";
  else if(has(q,"kawa","herbata"))tip="Porównaj cenę za kilogram, nie tylko za paczkę. Przy kapsułkach policz koszt jednej filiżanki. Większy zapas ma sens, gdy go zużyjesz.";
  else if(has(q,"banan","owoc","warzyw"))tip="Porównaj cenę za kilogram i kup ilość, którą zużyjesz. Dojrzałe owoce możesz zamrozić. Rabat nie oszczędza pieniędzy, jeśli jedzenie się zmarnuje.";
  else if(has(q,"bilet"))tip="Porównaj bilet 90-dniowy z trzema 30-dniowymi. Uwzględnij urlopy i dni bez podróży. W Oszczędzaczu znajdziesz kalkulator obu wariantów.";
  else if(has(q,"prad","energia","ogrzew"))tip="Porównaj pełny koszt rachunku, w tym opłaty stałe, z rzeczywistym zużyciem. Nowy sprzęt oceniaj też pod kątem czasu, po którym zwróci się zakup.";
  return new Topic(query,tip,"",false,"product");
 }
 public static String plain(String html){return html.replaceAll("(?is)<(script|style)\\b[^>]*>.*?</\\1>"," ").replaceAll("<[^>]+>"," ").replace("&nbsp;"," ").replace("&#160;"," ").replace("&dollar;","$").replaceAll("\\s+"," ");}
 public static String price(Topic t,String html){
  String text=plain(html);
  if(t.kind.equals("plus")){
   Matcher m=Pattern.compile("(?i)ChatGPT Plus is a subscription plan.{0,220}?for \\$(\\d+(?:\\.\\d{1,2})?)/month").matcher(text);
   if(m.find())return m.group(1)+" USD / miesiąc · cena internetowa podana przez OpenAI. Kwota w Polsce, podatki i rozliczenie sklepu mogą się różnić.";
  }
  if(t.kind.equals("netflix")){
   // Reject foreign-currency pages, even when another PLN amount appears elsewhere.
   Matcher heading=Pattern.compile("(?i)(?:Pricing|Ceny|Cennik)\\s*\\((?:Polish Zloty|PLN|złoty polski)\\)").matcher(text);
   if(!heading.find())return "";String section=text.substring(heading.end(),Math.min(text.length(),heading.end()+1200));
   List<String> prices=new ArrayList<>();Matcher m=Pattern.compile("(?i)(Basic|Standard|Premium|Podstawowy)\\s*:\\s*(?:PLN\\s*)?(\\d+(?:[.,]\\d{1,2})?)\\s*(?:PLN|zł)?\\s*(?:/\\s*(?:month|miesiąc)|miesięcznie)").matcher(section);
   while(m.find())prices.add(m.group(1)+": "+m.group(2)+" zł / miesiąc");return String.join("\n",prices);
  }return "";
 }
 public static String refund(String html){String p=plain(html);return p.contains("EU, UK, or Turkey")&&p.contains("prorated refund")&&p.contains("within 14 days of purchase")?"Mieszkańcy UE: pomoc OpenAI wskazuje proporcjonalny zwrot przy anulowaniu w ciągu 14 dni od zakupu. Złóż osobny wniosek. Sposób postępowania zależy od miejsca zakupu; dla Apple wniosek składa się do Apple. Samo anulowanie nie jest wnioskiem o zwrot.":"";}
 public static BigDecimal amount(String value){String s=value.trim().replace(',','.');if(!s.matches("\\d{1,8}(?:\\.\\d{1,2})?"))throw new IllegalArgumentException();BigDecimal n=new BigDecimal(s);if(n.signum()<=0)throw new IllegalArgumentException();return n;}
 public static String money(BigDecimal n){return n.setScale(2,RoundingMode.HALF_UP).toPlainString().replace('.',',')+" zł";}
 public static String calculation(String cost,String uses,boolean monthly){BigDecimal n=amount(cost);String result=monthly?"Miesiąc: "+money(n)+"\n12 miesięcy bez przerw: "+money(n.multiply(BigDecimal.valueOf(12)))+"\nJedna miesięczna opłata mniej: "+money(n):"Koszt zakupu: "+money(n);if(!uses.trim().isEmpty()){if(!uses.trim().matches("[1-9]\\d{0,5}"))throw new IllegalArgumentException();result+="\nKoszt jednego użycia: "+money(n.divide(new BigDecimal(uses.trim()),8,RoundingMode.HALF_UP));}return result;}
 private SaverLogic(){}
}
