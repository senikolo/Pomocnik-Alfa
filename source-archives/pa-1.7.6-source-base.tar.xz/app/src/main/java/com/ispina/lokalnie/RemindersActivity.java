package com.ispina.lokalnie;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.app.TimePickerDialog;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.ispina.lokalnie.reminders.ReminderScheduler;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class RemindersActivity extends ThemedActivity {
    private LinearLayout list;
    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}
    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,16));root.setBackgroundColor(NativeUi.bg(this));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=NativeUi.button(this,"‹",true);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,46)));TextView t=NativeUi.text(this,"Przypomnienia",23,true);t.setPadding(NativeUi.dp(this,12),0,0,0);head.addView(t);root.addView(head);
        LinearLayout quick=new LinearLayout(this);quick.setPadding(0,NativeUi.dp(this,12),0,NativeUi.dp(this,8));Button ticket=NativeUi.button(this,"Bilet 30 / 90 dni",true);Button add=NativeUi.button(this,"Dodaj",false);ticket.setOnClickListener(v->{if(ensureNotificationPermission())addTicket();});add.setOnClickListener(v->{if(ensureNotificationPermission())showAdd();});quick.addView(ticket,new LinearLayout.LayoutParams(0,NativeUi.dp(this,46),1));LinearLayout.LayoutParams ap=new LinearLayout.LayoutParams(0,NativeUi.dp(this,46),1);ap.setMargins(NativeUi.dp(this,8),0,0,0);quick.addView(add,ap);root.addView(quick);
        Button check=NativeUi.button(this,"Sprawdź powiadomienia",true);check.setOnClickListener(v->checkNotifications());root.addView(check);NativeUi.addSpacer(root,this,10);
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);refresh();
    }
    private void refresh(){
        list.removeAllViews();List<JSONObject> items=new ArrayList<>();try{JSONArray a=new JSONArray(ReminderScheduler.status(this));for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null)items.add(o);}}catch(Exception ignored){}
        items.sort(Comparator.comparingLong(o->o.optLong("at",Long.MAX_VALUE)));if(items.isEmpty()){list.addView(NativeUi.muted(this,"Brak aktywnych przypomnień.",13));return;}
        SimpleDateFormat f=new SimpleDateFormat("dd.MM.yyyy HH:mm",Locale.getDefault());
        for(JSONObject o:items){LinearLayout c=NativeUi.card(this);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);tx.addView(NativeUi.text(this,o.optString("title","Przypomnienie"),16,true));tx.addView(NativeUi.muted(this,f.format(new Date(o.optLong("at",0)))+" • "+repeatLabel(o.optString("repeat","once")),11));String body=o.optString("body","");if(!body.isEmpty())tx.addView(NativeUi.muted(this,body,12));row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=NativeUi.button(this,"Usuń",true);String id=o.optString("id");del.setOnClickListener(v->{ReminderScheduler.cancel(this,id);MainActivity.updateDashboardState(this);refresh();});row.addView(del,new LinearLayout.LayoutParams(NativeUi.dp(this,76),NativeUi.dp(this,44)));c.addView(row);list.addView(c);}
    }
    private boolean ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},502);
            Toast.makeText(this,"Zezwól na powiadomienia, a potem wybierz tę opcję ponownie.",Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }
    private void checkNotifications(){
        com.ispina.lokalnie.reminders.ReminderReceiver.ensureChannel(this);
        android.app.NotificationManager nm=(android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE);
        boolean allowed=androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled();
        if(android.os.Build.VERSION.SDK_INT>=26){android.app.NotificationChannel ch=nm.getNotificationChannel(com.ispina.lokalnie.reminders.ReminderReceiver.CHANNEL);allowed=allowed && ch!=null && ch.getImportance()!=0;}
        android.app.AlarmManager am=(android.app.AlarmManager)getSystemService(ALARM_SERVICE);
        boolean exact=android.os.Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms();
        new AlertDialog.Builder(this).setTitle("Powiadomienia")
            .setMessage((allowed?"Powiadomienia są włączone.":"Powiadomienia są wyłączone. Włącz je w ustawieniach.")+"\n"+(exact?"Dokładne alarmy są dostępne.":"Alarmy mogą się opóźnić. Możesz włączyć dokładne alarmy.")+"\nTest za 15 sekund sprawdzi także działanie po wyjściu z aplikacji.")
            .setNegativeButton("Zamknij",null).setNeutralButton(exact?"Ustawienia":"Dokładne alarmy",(d,w)->{
                if(!exact && android.os.Build.VERSION.SDK_INT>=31){
                    try{
                        android.content.Intent i=new android.content.Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,android.net.Uri.parse("package:"+getPackageName()));
                        startActivity(i);
                    }catch(Exception e){
                        android.content.Intent i=new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));startActivity(i);
                    }
                }else{
                    android.content.Intent i=new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName()));startActivity(i);
                }
            }).setPositiveButton(allowed?"Test za 15 s":"Włącz",(d,w)->{
                if(!androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled() && android.os.Build.VERSION.SDK_INT>=33){requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},502);return;}
                if(!allowedNotifications()){startActivity(new android.content.Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,android.net.Uri.parse("package:"+getPackageName())));return;}
                boolean ok=ReminderScheduler.saveAndSchedule(this,"notification_test","Pomocnik Alfa: test powiadomień","Przypomnienia działają. Możesz usunąć tę wiadomość.",System.currentTimeMillis()+15000,"once");
                Toast.makeText(this,ok?"Test zaplanowany za 15 sekund.":"Nie udało się zaplanować testu.",Toast.LENGTH_LONG).show();refresh();
            }).show();
    }
    private boolean allowedNotifications(){
        if(!androidx.core.app.NotificationManagerCompat.from(this).areNotificationsEnabled())return false;
        if(android.os.Build.VERSION.SDK_INT>=26){android.app.NotificationChannel ch=((android.app.NotificationManager)getSystemService(NOTIFICATION_SERVICE)).getNotificationChannel(com.ispina.lokalnie.reminders.ReminderReceiver.CHANNEL);return ch==null || ch.getImportance()!=0;}return true;
    }
    private void addTicket(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(NativeUi.dp(this,18),0,NativeUi.dp(this,18),0);
        Calendar start=Calendar.getInstance();start.set(Calendar.SECOND,0);start.set(Calendar.MILLISECOND,0);
        Spinner duration=new Spinner(this);duration.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"30 dni","90 dni"}));
        duration.setSelection(getPreferences(0).getInt("ticket_days",30)==90?1:0);
        Button date=NativeUi.button(this,"Początek: "+fmtDate(start),true);
        Spinner warning=new Spinner(this);warning.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"1 dzień przed końcem","2 dni przed końcem","2 dni i 1 dzień przed końcem"}));
        warning.setSelection(2);TextView preview=NativeUi.muted(this,"",13);
        Runnable update=()->{Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_YEAR,(duration.getSelectedItemPosition()==0?30:90)-1);preview.setText("Ostatni dzień ważności: "+fmtDate(end)+"\nPowiadomienie o 09:00. Sprawdź termin na swoim bilecie.");};
        duration.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,android.view.View v,int pos,long id){update.run();}});
        date.setOnClickListener(v->new DatePickerDialog(this,(x,y,m,d)->{start.set(y,m,d);date.setText("Początek: "+fmtDate(start));update.run();},start.get(Calendar.YEAR),start.get(Calendar.MONTH),start.get(Calendar.DAY_OF_MONTH)).show());
        box.addView(NativeUi.text(this,"Ważność biletu",15,true));box.addView(duration);box.addView(date);NativeUi.addSpacer(box,this,8);box.addView(warning);box.addView(preview);update.run();
        AlertDialog dialog=new AlertDialog.Builder(this).setTitle("Bilet okresowy").setView(box).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",null).create();
        dialog.setOnShowListener(d->dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            int days=duration.getSelectedItemPosition()==0?30:90;Calendar end=(Calendar)start.clone();end.add(Calendar.DAY_OF_YEAR,days-1);end.set(Calendar.HOUR_OF_DAY,9);end.set(Calendar.MINUTE,0);
            int[] offsets=warning.getSelectedItemPosition()==2?new int[]{2,1}:new int[]{warning.getSelectedItemPosition()+1};
            for(int off:offsets){Calendar at=(Calendar)end.clone();at.add(Calendar.DAY_OF_YEAR,-off);if(at.getTimeInMillis()<=System.currentTimeMillis()){Toast.makeText(this,"Wybrane przypomnienie wypada w przeszłości. Zmień datę lub wyprzedzenie.",Toast.LENGTH_LONG).show();return;}}
            String base="ticket_"+System.currentTimeMillis();boolean ok=true;
            for(int off:offsets){Calendar at=(Calendar)end.clone();at.add(Calendar.DAY_OF_YEAR,-off);ok &= ReminderScheduler.saveAndSchedule(this,base+"_"+off,"Bilet "+days+"-dniowy","Ostatni dzień ważności: "+fmtDate(end)+". Został"+(off==1?" 1 dzień.":"y 2 dni."),at.getTimeInMillis(),"once");}
            if(!ok){for(int off:offsets)ReminderScheduler.cancel(this,base+"_"+off);Toast.makeText(this,"Nie udało się zapisać alarmów.",Toast.LENGTH_LONG).show();return;}
            getPreferences(0).edit().putInt("ticket_days",days).apply();dialog.dismiss();MainActivity.updateDashboardState(this);refresh();Toast.makeText(this,"Zapisano bilet "+days+" dni i przypomnienia.",Toast.LENGTH_LONG).show();
        }));dialog.show();
    }
    private void showAdd(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(NativeUi.dp(this,18),0,NativeUi.dp(this,18),0);EditText title=new EditText(this);title.setHint("Tytuł");EditText body=new EditText(this);body.setHint("Opis (opcjonalnie)");Calendar when=Calendar.getInstance();when.add(Calendar.HOUR_OF_DAY,1);Button date=NativeUi.button(this,"Data: "+fmtDate(when),true);Button time=NativeUi.button(this,"Godzina: "+fmtTime(when),true);String[] reps={"Jednorazowo","Codziennie","Co tydzień"};Spinner repeat=new Spinner(this);repeat.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,reps));
        date.setOnClickListener(v->new DatePickerDialog(this,(x,y,m,d)->{when.set(y,m,d);date.setText("Data: "+fmtDate(when));},when.get(Calendar.YEAR),when.get(Calendar.MONTH),when.get(Calendar.DAY_OF_MONTH)).show());
        time.setOnClickListener(v->new TimePickerDialog(this,(x,h,min)->{when.set(Calendar.HOUR_OF_DAY,h);when.set(Calendar.MINUTE,min);when.set(Calendar.SECOND,0);time.setText("Godzina: "+fmtTime(when));},when.get(Calendar.HOUR_OF_DAY),when.get(Calendar.MINUTE),true).show());
        box.addView(title);box.addView(body);box.addView(date);NativeUi.addSpacer(box,this,8);box.addView(time);NativeUi.addSpacer(box,this,8);box.addView(repeat);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Nowe przypomnienie").setView(box).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",null).create();dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{String tt=title.getText().toString().trim();if(tt.isEmpty()){title.setError("Podaj tytuł");return;}String rp=repeat.getSelectedItemPosition()==1?"daily":repeat.getSelectedItemPosition()==2?"weekly":"once";boolean ok=ReminderScheduler.saveAndSchedule(this,"rem_"+System.currentTimeMillis(),tt,body.getText().toString().trim(),when.getTimeInMillis(),rp);if(ok){dlg.dismiss();MainActivity.updateDashboardState(this);refresh();}else Toast.makeText(this,"Sprawdź datę i uprawnienia alarmów.",Toast.LENGTH_SHORT).show();}));dlg.show();
    }
    private String fmtDate(Calendar c){return new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(c.getTime());}
    private String fmtTime(Calendar c){return new SimpleDateFormat("HH:mm",Locale.getDefault()).format(c.getTime());}
    private static String repeatLabel(String repeat){
        switch(repeat){case "daily":return "Codziennie";case "weekly":return "Co tydzień";case "monthly":return "Co miesiąc";case "yearly":return "Co rok";default:return "Jednorazowo";}
    }
}
