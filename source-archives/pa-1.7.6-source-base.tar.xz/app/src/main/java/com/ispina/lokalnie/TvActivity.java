package com.ispina.lokalnie;

import android.app.Activity;
import android.app.PictureInPictureParams;
import android.content.Intent;
import android.net.Uri;
import android.net.ConnectivityManager;
import android.net.NetworkCapabilities;
import android.content.pm.ActivityInfo;
import android.provider.Settings;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.hls.HlsMediaSource;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Rational;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.ui.PlayerView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

@androidx.annotation.OptIn(markerClass = androidx.media3.common.util.UnstableApi.class)
public class TvActivity extends ThemedActivity {
    private PlayerView playerView;
    private FrameLayout screenRoot, inlineFrame, fullscreenFrame;
    private TextView vpnStatus;
    private ScrollView mainScroll;
    private boolean fullscreen;
    private boolean saver, qualityBeforeSaver, controllerBeforeSaver;
    private float brightnessBeforeSaver;
    private int uiBeforeSaver, flagsBeforeSaver;
    private FrameLayout saverFrame;
    private LinearLayout saverControls;
    private final Handler saverHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideSaverControls = () -> {
        if (!saver) return;
        saverControls.setVisibility(View.GONE);
        playerView.hideController();
        playerView.setUseController(false);
    };
    private ExoPlayer player;
    private DefaultTrackSelector trackSelector;
    private TextView status;
    private TextView currentChannel;
    private ProgressBar progress;
    private Button pipButton;
    private Button retryButton;
    private Button qualityButton;

    private final Handler retryHandler = new Handler(Looper.getMainLooper());
    private volatile boolean destroyed = false;
    private int selectionGeneration = 0;
    private int retryCount = 0;
    private String currentName = "";
    private String currentUrl = "";
    private String currentMode = "";
    private String currentCode = "";
    private String[] currentSources = new String[0];
    private int currentSourceIndex = 0;
    private boolean dataSaver = true;

    private static final int[] TVP3_KRAKOW_IDS = {71346000, 399746};
    private static final String ARD_STREAM = "https://daserste-live.ard-mcdn.de/daserste/live/hls/int/master.m3u8";
    private static final String ARD_ALPHA_STREAM = "https://mcdn.br.de/br/fs/ard_alpha/hls/int/master.m3u8";
    private static final String BR_SUED_STREAM = "https://mcdn.br.de/br/fs/bfs_sued/hls/int/master.m3u8";
    private static final String HEARTLAND_STREAM = "https://2-fss-2.streamhoster.com/pl_120/201950-2724904-1/playlist.m3u8";
    private static final String WFC_STREAM = "https://cdn.wfc.tv/cdn/stream-rus.m3u8";
    private static final String CBS_STREAM = "https://news20e7hhcb.airspace-cdn.cbsivideo.com/index.m3u8";
    private static final String ABC_STREAM = "https://abcnews-streams.akamaized.net/hls/live/2023570/abcnewslive_applenews/master.m3u8";

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        setTitle("Telewizja");
        setContentView(buildUi());
        initPlayer();
    }

    private View buildUi() {
        ScrollView scroll = new ScrollView(this);
        mainScroll = scroll;
        scroll.setFillViewport(true);
        scroll.setClipToPadding(false);
        scroll.setBackgroundColor(NativeUi.bg(this));

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(14), dp(14), dp(30));
        scroll.addView(root, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        LinearLayout head = new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back = button("‹", false);
        back.setTextSize(24);
        back.setOnClickListener(v -> finish());
        head.addView(back, new LinearLayout.LayoutParams(dp(48), dp(48)));

        LinearLayout titleBox = new LinearLayout(this);
        titleBox.setOrientation(LinearLayout.VERTICAL);
        TextView title = text("Telewizja", 25, true);
        TextView sub = text("Lekkie transmisje • oficjalne źródła", 12, false);
        sub.setTextColor(NativeUi.muted(this));
        titleBox.addView(title);
        titleBox.addView(sub);
        LinearLayout.LayoutParams tbp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        tbp.leftMargin = dp(10);
        head.addView(titleBox, tbp);
        root.addView(head);

        LinearLayout playerCard = card();
        currentChannel = text("📺  Wybierz stację", 18, true);
        playerCard.addView(currentChannel);
        TextView playerDesc = text("Oszczędzanie danych: aplikacja wybiera najniższą dostępną jakość obrazu.", 12, false);
        playerDesc.setTextColor(NativeUi.muted(this));
        addWithMargin(playerCard, playerDesc, 0, 4, 0, 10);

        FrameLayout frame = new FrameLayout(this);
        inlineFrame = frame;
        frame.setBackgroundColor(Color.BLACK);
        GradientDrawable frameBg = new GradientDrawable();
        frameBg.setColor(Color.BLACK);
        frameBg.setCornerRadius(dp(16));
        frame.setBackground(frameBg);
        frame.setClipToOutline(true);

        playerView = new PlayerView(this);
        playerView.setUseController(true);
        playerView.setKeepScreenOn(true);
        playerView.setBackgroundColor(Color.BLACK);
        frame.addView(playerView, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        playerCard.addView(frame, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dp(205)));

        LinearLayout statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        progress = new ProgressBar(this);
        progress.setVisibility(View.GONE);
        statusRow.addView(progress, new LinearLayout.LayoutParams(dp(24), dp(24)));
        status = text("Gotowe. Wybierz kanał poniżej.", 13, false);
        status.setTextColor(NativeUi.muted(this));
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1);
        sp.leftMargin = dp(9);
        statusRow.addView(status, sp);
        addWithMargin(playerCard, statusRow, 0, 10, 0, 4);

        LinearLayout playerActions = new LinearLayout(this);
        playerActions.setGravity(Gravity.CENTER_VERTICAL);
        pipButton = button("▣  PiP", false);
        pipButton.setOnClickListener(v -> enterMiniWindow());
        pipButton.setVisibility(Build.VERSION.SDK_INT >= 26 ? View.VISIBLE : View.GONE);
        qualityButton = button("Dane: oszczędnie", false);
        qualityButton.setOnClickListener(v -> toggleQuality());
        retryButton = button("Ponów", false);
        retryButton.setOnClickListener(v -> { retryCount = 0; retryCurrent(); });
        retryButton.setVisibility(View.GONE);
        playerActions.addView(qualityButton, new LinearLayout.LayoutParams(0, dp(46), 1));
        LinearLayout.LayoutParams pap = new LinearLayout.LayoutParams(0, dp(46), 1);
        pap.leftMargin = dp(7);
        playerActions.addView(pipButton, pap);
        LinearLayout.LayoutParams rap = new LinearLayout.LayoutParams(0, dp(46), 1);
        rap.leftMargin = dp(7);
        playerActions.addView(retryButton, rap);
        addWithMargin(playerCard, playerActions, 0, 7, 0, 0);
        addWithMargin(root, playerCard, 0, 10, 0, 0);

        Button full = button("⛶  Pełny ekran", false);
        full.setOnClickListener(v -> setFullscreen(true));
        Button saverButton = button("Saver • mały ekran", false);
        saverButton.setOnClickListener(v -> enterSaver());
        addWithMargin(playerCard, saverButton, 0, 7, 0, 0);
        addWithMargin(playerCard, full, 0, 7, 0, 0);

        LinearLayout pl = card();
        pl.addView(sectionTitle("🇵🇱  Polska"));
        TextView plInfo = text("Kanały TVP uruchamiane są przez aktualny oficjalny adres transmisji pobierany przy każdym starcie.", 12, false);
        plInfo.setTextColor(NativeUi.muted(this));
        addWithMargin(pl, plInfo, 0, 4, 0, 8);
        addStation(pl, "▶  TVP3 Kraków", "region • Małopolska", true, v -> startTvp3Low());
        addStation(pl, "▶  TVP Info", "wiadomości • Polska", false, v -> startTvpGo("TVP Info", "INF"));
        addStation(pl, "▶  TVP Polonia", "ogólna • informacje i programy", false, v -> startTvpGo("TVP Polonia", "T4D"));
        addWithMargin(root, pl, 0, 12, 0, 0);

        LinearLayout de = card();
        de.addView(sectionTitle("🇩🇪  Niemcy"));
        TextView deInfo = text("Kanały są odtwarzane w lekkim natywnym playerze, dzięki czemu sekcja TV zużywa mniej pamięci.", 12, false);
        deInfo.setTextColor(NativeUi.muted(this));
        addWithMargin(de, deInfo, 0, 4, 0, 8);
        addStation(de, "▶  ARD / Das Erste", "ogólna • 270p w trybie oszczędnym", true, v -> startDirect("ARD / Das Erste", ARD_STREAM));
        addStation(de, "▶  ARD alpha", "edukacja • nauka • kultura", false, v -> startDirect("ARD alpha", ARD_ALPHA_STREAM));
        addStation(de, "▶  BR Fernsehen Süd", "Bawaria • informacje • kultura", false, v -> startDirect("BR Fernsehen Süd", BR_SUED_STREAM));
        addWithMargin(root, de, 0, 12, 0, 0);

        LinearLayout ru = card();
        ru.addView(sectionTitle("🇷🇺  Rosyjskojęzyczne"));
        TextView ruInfo = text("Wybierz kanał, aby oglądać w aplikacji. World Fashion: moda, modelki i gwiazdy. NTV Style: wnętrza, podróże i styl życia.", 12, false);
        ruInfo.setTextColor(NativeUi.muted(this));
        addWithMargin(ru, ruInfo, 0, 4, 0, 8);
        addStation(ru, "▶  Россия 1", "filmy • seriale • programy • wiadomości", true, v -> startBroadcast("Россия 1", "1", true));
        addStation(ru, "▶  Россия 24", "wiadomości • rosyjski", false, v -> startBroadcast("Россия 24", "3", true));
        addStation(ru, "▶  Россия Культура", "kultura • filmy • teatr • koncerty", false, v -> startBroadcast("Россия Культура", "4", true));
        addStation(ru, "▶  НТВ Сериал / NTV Serial", "filmy telewizyjne • seriale • rosyjski", false, v -> startBroadcast("НТВ Сериал", "ntvseries", true));
        addStation(ru, "▶  СТС / STS", "komercyjna • komedie • filmy • rozrywka", false, v -> startBroadcast("СТС / STS", "ctc_ext", true));
        addStation(ru, "▶  НТВ / NTV", "wiadomości • seriale • programy", false, v -> startBroadcast("НТВ / NTV", "ntv", true));
        addStation(ru, "▶  World Fashion Channel Russia", "moda • modelki • gwiazdy • rosyjska wersja", false, v -> startBroadcast("World Fashion Channel Russia", "wfc", true));
        addStation(ru, "▶  НТВ Стиль / NTV Style", "wnętrza • podróże • styl życia", false, v -> startBroadcast("НТВ Стиль / NTV Style", "ntvstyle", true));
        vpnStatus = text("", 12, false);
        vpnStatus.setTextColor(NativeUi.muted(this));
        addWithMargin(ru, vpnStatus, 0, 8, 0, 4);
        Button vpn = button("🛡  Ustawienia VPN telefonu", false);
        vpn.setOnClickListener(v -> {
            try { startActivity(new Intent(Settings.ACTION_VPN_SETTINGS)); }
            catch (Exception e) { Toast.makeText(this, "Otwórz VPN w ustawieniach telefonu.", Toast.LENGTH_LONG).show(); }
        });
        addWithMargin(ru, vpn, 0, 4, 0, 4);
        addWithMargin(root, ru, 0, 12, 0, 0);

        LinearLayout us = card();
        us.addView(sectionTitle("🇺🇸  Stany Zjednoczone"));
        TextView usInfo = text("Kanały po angielsku, odtwarzane w aplikacji. Heartland: country i amerykańska rozrywka. Transmisja lokalnej stacji KVVB 33.4.", 12, false);
        usInfo.setTextColor(NativeUi.muted(this));
        addWithMargin(us, usInfo, 0, 4, 0, 8);
        addStation(us, "▶  Heartland / KVVB 33.4", "country • USA • rozrywka • transmisja lokalna", true, v -> startBroadcast("Heartland / KVVB 33.4", "heartland", true));
        addStation(us, "▶  CBS News 24/7", "wiadomości • USA i świat", false, v -> startBroadcast("CBS News 24/7", "cbs", true));
        addStation(us, "▶  ABC News Live", "wiadomości • relacje • programy", false, v -> startBroadcast("ABC News Live", "abc", true));
        addWithMargin(root, us, 0, 12, 0, 0);

        LinearLayout more=card();more.addView(sectionTitle("Świat"));
        addStation(more,"▶  tagesschau24","wiadomości • niemiecki",false,v->startDirect("tagesschau24","https://tagesschau.akamaized.net/hls/live/2020115/tagesschau/tagesschau_1/master.m3u8"));
        addStation(more,"▶  DW English","wiadomości • angielski",false,v->startDirect("DW English","https://dwamdstream102.akamaized.net/hls/live/2015525/dwstream102/master.m3u8"));
        addStation(more,"▶  WDR International","regiony i reportaże • niemiecki",false,v->startDirect("WDR International","https://wdr-live.ard-mcdn.de/wdr/live/hls/int/master.m3u8"));
        addStation(more,"▶  TRT World","wiadomości • angielski",false,v->startDirect("TRT World","https://tv-trtworld.medya.trt.com.tr/master.m3u8"));
        addStation(more,"▶  TRT Haber","wiadomości • turecki",false,v->startDirect("TRT Haber","https://tv-trthaber.medya.trt.com.tr/master.m3u8"));
        addWithMargin(root,more,0,12,0,0);
        TextView note = text("Dostępność zależy od nadawcy i kraju odbioru. TVP3 Kraków może wymagać połączenia z Polski. Jeśli nadawca zmieni adres transmisji, kanał może chwilowo wymagać aktualizacji aplikacji.", 11, false);
        note.setTextColor(NativeUi.muted(this));
        addWithMargin(root, note, 4, 12, 4, 0);
        screenRoot = new FrameLayout(this);
        screenRoot.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        return screenRoot;
    }

    private void initPlayer() {
        trackSelector = new DefaultTrackSelector(this);
        try {
            trackSelector.setParameters(trackSelector.buildUponParameters()
                    .setForceLowestBitrate(true)
                    .setMaxVideoSize(640, 360)
                    .setMaxVideoBitrate(1_450_000));
        } catch (Throwable ignored) {
            try { trackSelector.setParameters(trackSelector.buildUponParameters().setForceLowestBitrate(true)); } catch (Throwable ignored2) {}
        }
        player = new ExoPlayer.Builder(this).setTrackSelector(trackSelector).build();
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.setHandleAudioBecomingNoisy(true);
        try {
            AudioAttributes aa = new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build();
            player.setAudioAttributes(aa, true);
        } catch (Throwable ignored) {}
        playerView.setPlayer(player);
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int playbackState) {
                if (destroyed) return;
                if (playbackState == Player.STATE_BUFFERING) setStatus("Buforowanie transmisji…", true);
                else if (playbackState == Player.STATE_READY) {
                    setStatus(dataSaver ? "Odtwarzanie • tryb oszczędny" : "Odtwarzanie • lepsza jakość", false);
                    if (retryButton != null) retryButton.setVisibility(View.GONE);
                } else if (playbackState == Player.STATE_ENDED) setStatus("Transmisja zakończona.", false);
            }

            @Override public void onPlayerError(PlaybackException error) {
                if (destroyed) return;
                if ("multi".equals(currentMode) && currentSources != null && currentSourceIndex + 1 < currentSources.length) {
                    currentSourceIndex++;
                    currentUrl = currentSources[currentSourceIndex];
                    setStatus("Pierwsze źródło nie odpowiada. Przełączam na zapasowe " + (currentSourceIndex + 1) + "/" + currentSources.length + "…", true);
                    final int gen = selectionGeneration;
                    retryHandler.postDelayed(() -> { if (!destroyed && gen == selectionGeneration) playResolved(currentName, currentUrl, false); }, 700L);
                    return;
                }
                if (retryCount < 1 && currentName != null && !currentName.isEmpty()) {
                    retryCount++;
                    setStatus("Połączenie przerwane. Ponawiam…", true);
                    final int gen = selectionGeneration;
                    retryHandler.postDelayed(() -> { if (!destroyed && gen == selectionGeneration) retryCurrent(); }, 1800L);
                } else {
                    setStatus("broadcast".equals(currentMode)
                            ? "Nadawca nie udostępnia teraz transmisji dla tego połączenia. Sprawdź internet lub swój VPN, następnie wybierz Ponów."
                            : "Ta transmisja jest teraz niedostępna. Użyj Ponów lub wybierz inny kanał.", false);
                    if (retryButton != null) retryButton.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    private void retryCurrent() {
        if ("broadcast".equals(currentMode)) startBroadcast(currentName, currentCode, false);
        else if ("tvp3".equals(currentMode)) startTvp3Low(false);
        else if ("tvpgo".equals(currentMode)) startTvpGo(currentName, currentCode, false);
        else if ("multi".equals(currentMode) && currentSources != null && currentSources.length > 0) {
            currentSourceIndex = 0;
            currentUrl = currentSources[0];
            retryCount = 0;
            playResolved(currentName, currentUrl, false);
        } else if ("direct".equals(currentMode) && currentUrl != null && !currentUrl.isEmpty()) playResolved(currentName, currentUrl, false);
    }

    private void startDirect(String name, String url) {
        retryCount = 0;
        currentMode = "direct";
        currentCode = "";
        currentSources = new String[0];
        currentSourceIndex = 0;
        currentName = name;
        currentUrl = url;
        selectionGeneration++;
        currentChannel.setText("📺  " + name);
        setStatus("Uruchamiam najniższą dostępną jakość…", true);
        playResolved(name, url, false);
    }

    private void startDirectFallback(String name, String[] urls) {
        retryCount = 0;
        currentMode = "multi";
        currentCode = "";
        currentName = name;
        currentSources = urls == null ? new String[0] : urls.clone();
        currentSourceIndex = 0;
        currentUrl = currentSources.length > 0 ? currentSources[0] : "";
        selectionGeneration++;
        currentChannel.setText("📺  " + name);
        if (currentUrl.isEmpty()) {
            setStatus("Brak dostępnego źródła transmisji.", false);
            if (retryButton != null) retryButton.setVisibility(View.VISIBLE);
            return;
        }
        setStatus("Uruchamiam źródło 1/" + currentSources.length + "…", true);
        playResolved(name, currentUrl, false);
    }

    private void toggleQuality() {
        setDataSaver(!dataSaver);
    }

    private void setDataSaver(boolean enabled) {
        dataSaver = enabled;
        try {
            DefaultTrackSelector.Parameters.Builder p = trackSelector.buildUponParameters();
            if (dataSaver) p.setForceLowestBitrate(true).setMaxVideoSize(640, 360).setMaxVideoBitrate(1_450_000);
            else p.setForceLowestBitrate(false).setMaxVideoSize(1280, 720).setMaxVideoBitrate(3_500_000);
            trackSelector.setParameters(p);
            if (qualityButton != null) qualityButton.setText(dataSaver ? "Dane: oszczędnie" : "Dane: lepsza jakość");
            setStatus(dataSaver ? "Tryb oszczędny włączony." : "Lepsza jakość włączona.", false);
        } catch (Throwable ignored) {}
    }

    private void playResolved(String name, String url, boolean resetRetry) {
        if (destroyed || player == null || url == null || url.isEmpty()) return;
        if (resetRetry) retryCount = 0;
        currentName = name;
        currentUrl = url;
        currentChannel.setText("📺  " + name);
        try {
            retryHandler.removeCallbacksAndMessages(null);
            player.stop();
            player.clearMediaItems();
            if ("broadcast".equals(currentMode)) {
                DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                        .setUserAgent("Mozilla/5.0 (Linux; Android) PomocnikAlfa/1.6.9")
                        .setConnectTimeoutMs(12000).setReadTimeoutMs(15000)
                        .setDefaultRequestProperties(Collections.singletonMap("Referer", broadcastReferer(currentCode)));
                player.setMediaSource(new HlsMediaSource.Factory(http).createMediaSource(MediaItem.fromUri(url)));
            } else player.setMediaItem(MediaItem.fromUri(url));
            player.prepare();
            player.play();
        } catch (Throwable e) {
            setStatus("Nie udało się uruchomić transmisji.", false);
        }
    }

    private static String broadcastReferer(String code) {
        if ("ntvseries".equals(code)) return "https://www.ntv.ru/air/ntvseries/";
        if ("ntv".equals(code) || "ctc_ext".equals(code)) return "https://www.ntv.ru/";
        if ("heartland".equals(code)) return "https://kvvb.tv/";
        if ("wfc".equals(code)) return "https://wfc.tv/ru/live/";
        if ("ntvstyle".equals(code)) return "https://www.ntv.ru/air/ntvstyle/";
        if ("cbs".equals(code)) return "https://www.cbsnews.com/live/";
        if ("abc".equals(code)) return "https://abcnews.com/live";
        return "https://smotrim.ru/";
    }

    private void startBroadcast(String name, String channelCode, boolean resetRetry) {
        if (resetRetry) retryCount = 0;
        retryHandler.removeCallbacksAndMessages(null);
        currentMode = "broadcast";
        currentCode = channelCode;
        currentName = name;
        currentUrl = "";
        currentSources = new String[0];
        final int gen = ++selectionGeneration;
        player.stop();
        player.clearMediaItems();
        currentChannel.setText("📺  " + name);
        setStatus("Pobieram transmisję " + name + "…", true);
        mainScroll.smoothScrollTo(0, 0);
        new Thread(() -> {
            String stream = null;
            String problem = null;
            try {
                if ("heartland".equals(channelCode)) stream = HEARTLAND_STREAM;
                else if ("wfc".equals(channelCode)) stream = WFC_STREAM;
                else if ("cbs".equals(channelCode)) stream = CBS_STREAM;
                else if ("abc".equals(channelCode)) stream = ABC_STREAM;
                else if ("ctc_ext".equals(channelCode)) {
                    JSONObject response = new JSONObject(get("https://api.ntv.ru/vitrina/v1/channels", broadcastReferer(channelCode)));
                    stream = RussianTvStream.parseVitrina(response, channelCode);
                } else if ("ntvseries".equals(channelCode) || "ntv".equals(channelCode) || "ntvstyle".equals(channelCode)) {
                    JSONObject response = new JSONObject(get("https://www.ntv.ru/api/new/widgets/air/source/index.jsp", broadcastReferer(channelCode)));
                    stream = RussianTvStream.parseNtv(response, channelCode);
                } else {
                    JSONObject response = new JSONObject(get("https://player-api.smotrim.ru/api/v1/channel/" + channelCode, broadcastReferer(channelCode)));
                    stream = RussianTvStream.parse(response);
                }
            } catch (Exception e) {
                String message = e.getMessage() == null ? "" : e.getMessage();
                problem = message.contains("403") || message.contains("451")
                        ? "Nadawca odrzucił dostęp dla tego połączenia. Wybierz inny kanał lub Ponów po zmianie połączenia."
                        : "Nie udało się pobrać transmisji. Sprawdź internet i wybierz Ponów.";
            }
            final String resolved = stream, failure = problem;
            runOnUiThread(() -> {
                if (destroyed || gen != selectionGeneration) return;
                if (resolved == null) {
                    setStatus(failure == null ? "Nadawca nie udostępnia transmisji. Wybierz inny kanał lub Ponów." : failure, false);
                    retryButton.setVisibility(View.VISIBLE);
                } else playResolved(name, resolved, false);
            });
        }, "Pomocnik-TV").start();
    }

    @Override protected void onResume() {
        super.onResume();
        if (vpnStatus == null) return;
        ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
        NetworkCapabilities nc = cm == null ? null : cm.getNetworkCapabilities(cm.getActiveNetwork());
        boolean active = nc != null && nc.hasTransport(NetworkCapabilities.TRANSPORT_VPN);
        vpnStatus.setText(active ? "🛡 VPN aktywny. Po zmianie połączenia wybierz Ponów."
                : "VPN nieaktywny. Najpierw spróbuj odtwarzać. Jeśli potrzebny, uruchom własny VPN i wybierz Ponów.");
    }

    private void enterSaver() {
        if (saver || player == null || currentUrl.isEmpty()) {
            Toast.makeText(this, "Najpierw uruchom kanał TV.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (fullscreen) setFullscreen(false);
        brightnessBeforeSaver = getWindow().getAttributes().screenBrightness;
        uiBeforeSaver = getWindow().getDecorView().getSystemUiVisibility();
        flagsBeforeSaver = getWindow().getAttributes().flags;
        qualityBeforeSaver = dataSaver;
        controllerBeforeSaver = playerView.getUseController();
        saver = true;
        setDataSaver(true);
        saverFrame = new FrameLayout(this);
        saverFrame.setBackgroundColor(Color.BLACK);
        saverFrame.setOnClickListener(v -> revealSaverControls());
        ((ViewGroup) playerView.getParent()).removeView(playerView);
        playerView.hideController();
        playerView.setUseController(false);
        saverFrame.addView(playerView, new FrameLayout.LayoutParams(1, 1, Gravity.CENTER));
        saverFrame.addOnLayoutChangeListener((v,l,t,r,b,ol,ot,or,ob) -> resizeSaverPlayer());
        saverControls = new LinearLayout(this);
        saverControls.setOrientation(LinearLayout.VERTICAL);
        saverControls.setGravity(Gravity.CENTER);
        TextView hint = text("Saver • najniższa jakość • dotknij tła, aby pokazać sterowanie", 12, false);
        hint.setTextColor(Color.WHITE);
        hint.setGravity(Gravity.CENTER);
        saverControls.addView(hint);
        Button exit = button("Wyjdź z Savera", false);
        exit.setContentDescription("Wyłącz tryb Saver i przywróć jasność");
        exit.setOnClickListener(v -> exitSaver());
        saverControls.addView(exit, new LinearLayout.LayoutParams(-2, dp(48)));
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM);
        cp.setMargins(dp(16), dp(16), dp(16), dp(24));
        saverFrame.addView(saverControls, cp);
        screenRoot.addView(saverFrame, new FrameLayout.LayoutParams(-1, -1));
        android.view.WindowManager.LayoutParams wp = getWindow().getAttributes();
        wp.screenBrightness = 0.5f;
        getWindow().setAttributes(wp);
        getWindow().addFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        revealSaverControls();
    }

    private void resizeSaverPlayer() {
        if (!saver || saverFrame == null) return;
        int width = Math.min(dp(480), Math.round(saverFrame.getWidth() * 0.975f));
        width = Math.min(width, Math.round(saverFrame.getHeight() * 0.825f * 16f / 9f));
        if (width > 0) playerView.setLayoutParams(new FrameLayout.LayoutParams(width, width * 9 / 16, Gravity.CENTER));
    }

    private void revealSaverControls() {
        if (!saver) return;
        saverHandler.removeCallbacks(hideSaverControls);
        saverControls.setVisibility(View.VISIBLE);
        playerView.setUseController(true);
        playerView.showController();
        saverHandler.postDelayed(hideSaverControls, 4000L);
    }

    private void exitSaver() {
        if (!saver) return;
        saver = false;
        saverHandler.removeCallbacksAndMessages(null);
        ((ViewGroup) playerView.getParent()).removeView(playerView);
        screenRoot.removeView(saverFrame);
        saverFrame = null;
        saverControls = null;
        inlineFrame.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
        playerView.setUseController(controllerBeforeSaver);
        android.view.WindowManager.LayoutParams wp = getWindow().getAttributes();
        wp.screenBrightness = brightnessBeforeSaver;
        getWindow().setAttributes(wp);
        getWindow().setFlags(flagsBeforeSaver, android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getWindow().getDecorView().setSystemUiVisibility(uiBeforeSaver);
        setDataSaver(qualityBeforeSaver);
    }

    private void setFullscreen(boolean enabled) {
        if (enabled && saver) exitSaver();
        if (fullscreen == enabled || playerView == null) return;
        fullscreen = enabled;
        ((ViewGroup) playerView.getParent()).removeView(playerView);
        if (enabled) {
            fullscreenFrame = new FrameLayout(this);
            fullscreenFrame.setBackgroundColor(Color.BLACK);
            fullscreenFrame.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
            Button exit = button("✕  Wróć", false);
            exit.setOnClickListener(v -> setFullscreen(false));
            FrameLayout.LayoutParams ep = new FrameLayout.LayoutParams(dp(120), dp(48), Gravity.TOP | Gravity.END);
            ep.setMargins(dp(12), dp(12), dp(12), 0);
            fullscreenFrame.addView(exit, ep);
            screenRoot.addView(fullscreenFrame, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        } else {
            screenRoot.removeView(fullscreenFrame);
            fullscreenFrame = null;
            inlineFrame.addView(playerView, new FrameLayout.LayoutParams(-1, -1));
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED);
        }
    }

    @Override public void onBackPressed() {
        if (saver) exitSaver();
        else if (fullscreen) setFullscreen(false);
        else super.onBackPressed();
    }

    private void startTvpGo(String name, String code) { startTvpGo(name, code, true); }

    private void startTvpGo(String name, String code, boolean resetRetry) {
        if (resetRetry) retryCount = 0;
        currentMode = "tvpgo";
        currentSources = new String[0];
        currentSourceIndex = 0;
        currentCode = code;
        currentName = name;
        currentUrl = "";
        final int gen = ++selectionGeneration;
        currentChannel.setText("📺  " + name);
        setStatus("Pobieram aktualny oficjalny strumień…", true);
        new Thread(() -> {
            String stream = null;
            try { stream = resolveTvpGo(code); } catch (Throwable ignored) {}
            final String f = stream;
            runOnUiThread(() -> {
                if (destroyed || gen != selectionGeneration) return;
                if (f == null || f.isEmpty()) {
                    setStatus("Kanał jest teraz niedostępny. Spróbuj ponownie za chwilę.", false);
                    return;
                }
                currentUrl = f;
                playResolved(name, f, false);
            });
        }, "Pomocnik-TVP-" + code).start();
    }

    private String resolveTvpGo(String code) throws Exception {
        String metaUrl = "https://tvpstream.tvp.pl/api/tvp-stream/stream/data?station_code=" + code;
        JSONObject meta = new JSONObject(get(metaUrl, "https://stream.tvp.pl/"));
        JSONObject data = meta.optJSONObject("data");
        if (data == null) return null;
        String tokenizer = data.optString("stream_url", "");
        if (!tokenizer.startsWith("https://")) return null;
        JSONObject token = new JSONObject(get(tokenizer, "https://stream.tvp.pl/"));
        List<Source> sources = new ArrayList<>();
        collectSources(token, sources, 0);
        return chooseBestSource(sources);
    }

    private void startTvp3Low() { startTvp3Low(true); }

    private void startTvp3Low(boolean resetRetry) {
        if (resetRetry) retryCount = 0;
        currentMode = "tvp3";
        currentSources = new String[0];
        currentSourceIndex = 0;
        currentCode = "";
        currentName = "TVP3 Kraków";
        currentUrl = "";
        final int gen = ++selectionGeneration;
        currentChannel.setText("📺  TVP3 Kraków");
        setStatus("Pobieram aktualny strumień TVP3 Kraków…", true);
        new Thread(() -> {
            String stream = null;
            for (int id : TVP3_KRAKOW_IDS) {
                try {
                    List<Source> sources = resolveJsonp(id);
                    stream = chooseBestSource(sources);
                    if (stream != null) break;
                } catch (Exception ignored) {}
            }
            if (stream == null) {
                try {
                    List<Source> sources = resolveVod();
                    stream = chooseBestSource(sources);
                } catch (Exception ignored) {}
            }
            final String f = stream;
            runOnUiThread(() -> {
                if (destroyed || gen != selectionGeneration) return;
                if (f == null || f.isEmpty()) {
                    setStatus("TVP3 Kraków jest niedostępna. Powodem może być blokada regionalna nadawcy lub chwilowa awaria.", false);
                    return;
                }
                currentUrl = f;
                playResolved("TVP3 Kraków", f, false);
            });
        }, "Pomocnik-TVP3").start();
    }

    private List<Source> resolveJsonp(int id) throws Exception {
        String callback = "PomocnikCb";
        String url = "https://www.tvp.pl/sess/TVPlayer2/api.php?id=" + id + "&@method=getTvpConfig&@callback=" + callback;
        String txt = get(url, "https://stream.tvp.pl/");
        int p = txt.indexOf(callback + "(");
        int e = txt.lastIndexOf(");");
        if (p < 0 || e <= p) return Collections.emptyList();
        String json = txt.substring(p + callback.length() + 1, e);
        JSONObject root = new JSONObject(json);
        List<Source> out = new ArrayList<>();
        collectSources(root, out, 0);
        return out;
    }

    private List<Source> resolveVod() throws Exception {
        String url = "https://vod.tvp.pl/api/products/399746/videos/playlist?lang=pl&platform=BROWSER&videoType=MOVIE";
        JSONObject root = new JSONObject(get(url, "https://vod.tvp.pl/"));
        List<Source> out = new ArrayList<>();
        collectSources(root, out, 0);
        return out;
    }

    private void collectSources(Object obj, List<Source> out, int depth) {
        if (obj == null || depth > 12) return;
        try {
            if (obj instanceof JSONObject) {
                JSONObject o = (JSONObject) obj;
                String url = firstString(o, "url", "src", "source", "hls", "HLS");
                String type = firstString(o, "type", "format", "mimeType", "mime", "mime_type", "protocol");
                int bitrate = 0;
                if (o.has("bitrate")) bitrate = o.optInt("bitrate", 0);
                JSONObject q = o.optJSONObject("quality");
                if (q != null) bitrate = q.optInt("bitrate", bitrate);
                if (url != null && url.startsWith("https://") && !url.contains("material_niedostepny")) {
                    String l = (type == null ? "" : type.toLowerCase()) + " " + url.toLowerCase();
                    if (l.contains("m3u8") || l.contains("mpegurl") || l.contains("hls") || l.contains(".mp4")) out.add(new Source(url, bitrate));
                }
                JSONArray names = o.names();
                if (names != null) for (int i = 0; i < names.length(); i++) collectSources(o.opt(names.optString(i)), out, depth + 1);
            } else if (obj instanceof JSONArray) {
                JSONArray a = (JSONArray) obj;
                for (int i = 0; i < a.length(); i++) collectSources(a.opt(i), out, depth + 1);
            } else if (obj instanceof String) {
                String s = (String) obj;
                if (s.startsWith("https://") && (s.contains(".m3u8") || s.contains(".mp4")) && !s.contains("material_niedostepny")) out.add(new Source(s, 0));
            }
        } catch (Exception ignored) {}
    }

    private String chooseBestSource(List<Source> sources) {
        if (sources == null || sources.isEmpty()) return null;
        ArrayList<Source> valid = new ArrayList<>();
        for (Source s : sources) if (s != null && s.url != null && !s.url.contains("material_niedostepny")) valid.add(s);
        if (valid.isEmpty()) return null;
        valid.sort(Comparator.comparingInt(a -> a.bitrate > 0 ? a.bitrate : Integer.MAX_VALUE));
        for (Source s : valid) if (s.url.contains(".m3u8")) return s.url;
        return valid.get(0).url;
    }

    private String firstString(JSONObject o, String... keys) {
        for (String k : keys) {
            Object v = o.opt(k);
            if (v instanceof String && !((String) v).trim().isEmpty()) return ((String) v).trim().replace("&amp;", "&");
        }
        return null;
    }

    private String get(String u, String referer) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(u).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(10000);
        c.setInstanceFollowRedirects(true);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) Pomocnik/1.6.9");
        c.setRequestProperty("Accept", "application/json,text/javascript,application/vnd.apple.mpegurl,*/*");
        if (referer != null) c.setRequestProperty("Referer", referer);
        int code = c.getResponseCode();
        if (code < 200 || code >= 300) { c.disconnect(); throw new Exception("HTTP " + code); }
        StringBuilder b = new StringBuilder();
        try (BufferedReader r = new BufferedReader(new InputStreamReader("gzip".equalsIgnoreCase(c.getContentEncoding()) ? new java.util.zip.GZIPInputStream(c.getInputStream()) : c.getInputStream(), StandardCharsets.UTF_8))) {
            String line;
            while ((line = r.readLine()) != null) b.append(line).append('\n');
        } finally { c.disconnect(); }
        return b.toString();
    }

    private void enterMiniWindow() {
        if (Build.VERSION.SDK_INT < 26 || player == null || player.getCurrentMediaItem() == null) return;
        try {
            if (saver) exitSaver();
            if (fullscreen) setFullscreen(false);
            PictureInPictureParams p = new PictureInPictureParams.Builder().setAspectRatio(new Rational(16, 9)).build();
            enterPictureInPictureMode(p);
        } catch (Throwable ignored) {}
    }

    @Override public void onPictureInPictureModeChanged(boolean isInPictureInPictureMode, android.content.res.Configuration newConfig) {
        super.onPictureInPictureModeChanged(isInPictureInPictureMode, newConfig);
        if (playerView != null) playerView.setUseController(!isInPictureInPictureMode);
    }

    private void setStatus(String s, boolean busy) {
        if (status != null) status.setText(s);
        if (progress != null) progress.setVisibility(busy ? View.VISIBLE : View.GONE);
        if (busy && retryButton != null) retryButton.setVisibility(View.GONE);
    }

    private LinearLayout card() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setPadding(dp(15), dp(15), dp(15), dp(15));
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(NativeUi.cardColor(this));
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(1), NativeUi.line(this));
        l.setBackground(bg);
        if (Build.VERSION.SDK_INT >= 21) l.setElevation(dp(2));
        return l;
    }

    private TextView sectionTitle(String s) {
        TextView t = text(s, 18, true);
        t.setPadding(0, 0, 0, dp(2));
        return t;
    }

    private TextView text(String s, int sp, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(NativeUi.ink(this));
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        return t;
    }

    private Button button(String s, boolean primary) {
        return NativeUi.button(this, s, !primary);
    }

    private void addStation(LinearLayout parent, String title, String desc, boolean primary, View.OnClickListener listener) {
        Button b = button(title + "\n" + desc, primary);
        b.setGravity(Gravity.START | Gravity.CENTER_VERTICAL);
        b.setMinHeight(dp(60));
        b.setLineSpacing(0, 1.05f);
        b.setOnClickListener(listener);
        addWithMargin(parent, b, 0, 7, 0, 0);
    }

    private void addWithMargin(LinearLayout parent, View v, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        parent.addView(v, p);
    }

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    @Override protected void onPause() {
        if (saver) exitSaver();
        super.onPause();
    }

    @Override protected void onStop() {
        super.onStop();
        if (saver) exitSaver();
        boolean pip = Build.VERSION.SDK_INT >= 26 && isInPictureInPictureMode();
        if (!pip && player != null) player.pause();
    }

    @Override protected void onDestroy() {
        if (saver) exitSaver();
        saverHandler.removeCallbacksAndMessages(null);
        destroyed = true;
        selectionGeneration++;
        retryHandler.removeCallbacksAndMessages(null);
        if (playerView != null) playerView.setPlayer(null);
        if (player != null) {
            try { player.stop(); } catch (Throwable ignored) {}
            player.release();
            player = null;
        }
        playerView = null;
        super.onDestroy();
    }

    private static final class Source {
        final String url;
        final int bitrate;
        Source(String url, int bitrate) { this.url = url; this.bitrate = bitrate; }
    }
}
