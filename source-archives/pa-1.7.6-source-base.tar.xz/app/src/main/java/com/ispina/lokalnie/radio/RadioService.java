package com.ispina.lokalnie.radio;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

import androidx.annotation.Nullable;
import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MediaMetadata;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.session.MediaSession;
import androidx.media3.session.MediaSessionService;

public class RadioService extends MediaSessionService {
    public static final String ACTION_PLAY="com.ispina.lokalnie.radio.PLAY";
    public static final String ACTION_PAUSE="com.ispina.lokalnie.radio.PAUSE";
    public static final String ACTION_STOP="com.ispina.lokalnie.radio.STOP";

    private ExoPlayer player;
    private MediaSession session;
    private SharedPreferences prefs;
    private final Handler handler=new Handler(Looper.getMainLooper());
    private int retryGeneration=0;
    private int retryCount=0;
    private boolean desiredPlaying=false;
    private String lastName="Radio",lastUrl="";

    @Override public void onCreate(){
        super.onCreate();
        prefs=getSharedPreferences("radio_state",MODE_PRIVATE);
        lastName=prefs.getString("name","Radio");
        lastUrl=prefs.getString("url","");
        desiredPlaying=prefs.getBoolean("desired",false);

        player=new ExoPlayer.Builder(this).build();
        player.setWakeMode(C.WAKE_MODE_NETWORK);
        player.setHandleAudioBecomingNoisy(true);
        try{
            AudioAttributes aa=new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MUSIC).build();
            player.setAudioAttributes(aa,true);
        }catch(Throwable ignored){}

        player.addListener(new Player.Listener(){
            @Override public void onIsPlayingChanged(boolean isPlaying){
                prefs.edit().putBoolean("playing",isPlaying).apply();
            }

            @Override public void onPlaybackStateChanged(int state){
                if(state==Player.STATE_READY){
                    retryCount=0;
                    prefs.edit().putString("error","").apply();
                }
            }

            @Override public void onPlayerError(androidx.media3.common.PlaybackException error){
                String msg=error.getMessage()==null?"Błąd odtwarzania":error.getMessage();
                prefs.edit().putBoolean("playing",false).putString("error",msg).apply();
                scheduleRetry();
            }
        });
        session=new MediaSession.Builder(this,player).build();
    }

    @Override public int onStartCommand(Intent intent,int flags,int startId){
        super.onStartCommand(intent,flags,startId);
        if(intent==null){
            if(desiredPlaying && lastUrl!=null && !lastUrl.isEmpty()){
                playInternal(lastName,lastUrl,false);
                return START_STICKY;
            }
            return START_NOT_STICKY;
        }

        String a=intent.getAction();
        if(ACTION_PLAY.equals(a)){
            String name=intent.getStringExtra("name"),url=intent.getStringExtra("url");
            if(url!=null&&!url.trim().isEmpty()){
                if(name==null||name.trim().isEmpty())name="Radio";
                lastName=name;
                lastUrl=url;
                desiredPlaying=true;
                retryCount=0;
                retryGeneration++;
                handler.removeCallbacksAndMessages(null);
                prefs.edit().putBoolean("desired",true).putString("name",name).putString("url",url).putString("error","").apply();
                playInternal(name,url,false);
            }
        }else if(ACTION_PAUSE.equals(a)){
            desiredPlaying=false;
            retryGeneration++;
            retryCount=0;
            handler.removeCallbacksAndMessages(null);
            if(player!=null)player.pause();
            prefs.edit().putBoolean("desired",false).putBoolean("playing",false).apply();
        }else if(ACTION_STOP.equals(a)){
            desiredPlaying=false;
            retryGeneration++;
            retryCount=0;
            handler.removeCallbacksAndMessages(null);
            if(player!=null){player.stop();player.clearMediaItems();}
            prefs.edit().putBoolean("desired",false).putBoolean("playing",false).putString("error","").apply();
            stopSelf();
            return START_NOT_STICKY;
        }
        return desiredPlaying?START_STICKY:START_NOT_STICKY;
    }

    private void scheduleRetry(){
        if(!desiredPlaying||lastUrl==null||lastUrl.isEmpty())return;
        if(retryCount>=2){
            desiredPlaying=false;
            prefs.edit().putBoolean("desired",false).putBoolean("playing",false).apply();
            stopSelf();
            return;
        }
        final int generation=retryGeneration;
        retryCount++;
        long delay=2500L*retryCount;
        handler.postDelayed(() -> {
            if(generation==retryGeneration&&desiredPlaying)playInternal(lastName,lastUrl,true);
        },delay);
    }

    private void playInternal(String name,String url,boolean retry){
        try{
            if(player==null)return;
            MediaItem current=player.getCurrentMediaItem();
            String currentUri=current!=null&&current.localConfiguration!=null?String.valueOf(current.localConfiguration.uri):"";
            int state=player.getPlaybackState();
            if(url.equals(currentUri)&&(state==Player.STATE_READY||state==Player.STATE_BUFFERING)){
                player.play();
                return;
            }

            MediaMetadata md=new MediaMetadata.Builder().setTitle(name).setArtist("Pomocnik Alfa").build();
            MediaItem item=new MediaItem.Builder().setUri(url).setMediaMetadata(md).build();
            player.stop();
            player.clearMediaItems();
            player.setMediaItem(item);
            player.prepare();
            player.play();
            prefs.edit().putString("name",name).putString("url",url).putString("error","").putBoolean("desired",true).apply();
        }catch(Throwable e){
            String msg=e.getMessage()==null?e.getClass().getSimpleName():e.getMessage();
            prefs.edit().putBoolean("playing",false).putString("error",msg).apply();
            scheduleRetry();
        }
    }

    @Nullable @Override public MediaSession onGetSession(androidx.media3.session.MediaSession.ControllerInfo controllerInfo){return session;}

    @Override public void onDestroy(){
        retryGeneration++;
        handler.removeCallbacksAndMessages(null);
        prefs.edit().putBoolean("playing",false).apply();
        if(session!=null){session.release();session=null;}
        if(player!=null){player.release();player=null;}
        super.onDestroy();
    }
}
