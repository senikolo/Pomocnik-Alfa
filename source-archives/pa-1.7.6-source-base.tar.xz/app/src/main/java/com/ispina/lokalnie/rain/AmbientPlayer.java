package com.ispina.lokalnie.rain;
import android.content.Context;
import android.content.res.AssetFileDescriptor;
import java.io.IOException;
/** Uses real recordings for storm and cat, the existing synth for other profiles. */
final class AmbientPlayer {
 private final Context context;private final AmbientSynth synth=new AmbientSynth(System.nanoTime());private RecordedLoop recording;private String loaded="";private double gain;
 AmbientPlayer(Context c){context=c.getApplicationContext();}
 void fill(short[] buffer,String mode,int volume)throws IOException{
  if(!"storm".equals(mode) && !"purr".equals(mode)){recording=null;loaded="";gain=0;synth.fill(buffer,mode,volume);return;}
  if(!mode.equals(loaded)){String path="audio/"+mode+".pcm";long length;try(AssetFileDescriptor file=context.getAssets().openFd(path)){length=file.getLength();}recording=null;recording=new RecordedLoop(context.getAssets().open(path),length);loaded=mode;gain=0;}
  double target=Math.max(0,Math.min(100,volume))/100.0;for(int i=0;i<buffer.length;i++){gain+=(target-gain)*.0008;buffer[i]=(short)Math.round(recording.sample()*gain);}
 }
}
