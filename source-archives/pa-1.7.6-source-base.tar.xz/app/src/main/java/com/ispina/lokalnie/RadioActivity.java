package com.ispina.lokalnie;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import com.ispina.lokalnie.radio.RadioService;

public class RadioActivity extends ThemedActivity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView status;
    private LinearLayout list;
    private Button favoritesToggle;
    private boolean onlyFavorites = false;
    private SharedPreferences favorites;

    private static final String[][] STATIONS={
            {"Program 1 Polskiego Radia","https://stream11.polskieradio.pl/pr1/pr1.sdp/playlist.m3u8"},
            {"Program 3 Polskiego Radia","https://stream13.polskieradio.pl/pr3/pr3.sdp/playlist.m3u8"},
            {"TOK FM","https://radiostream.pl/tuba10-1.mp3"},
            {"ESKA Bochnia","https://ic1.smcdn.pl/2330-1.mp3"},
            {"RMF FM","https://rs103-krk-cyfronet.rmfstream.pl/RMFFM48"},
            {"Radio ZET","https://zt02.cdn.eurozet.pl/zet-old.mp3"},
            {"VOX FM","https://ic2.smcdn.pl/3990-1.mp3"},
            {"RMF Classic","https://rs9-krk2.rmfstream.pl/rmf_classic"},
            {"RMF MAXX","https://rs9-krk2-cyfronet.rmfstream.pl/RMFMAXXX48"},
            {"Złote Przeboje","https://radiostream.pl/tuba8904-1.mp3"},
            {"Radio Pogoda","https://hub.radiostream.pl/stream.pls?radio=38&type=none&app=none&coding=mp3&redirect=true"},
            {"Eska2","https://waw.ic.smcdn.pl/6040-1.aac"},
            {"Eska ROCK","https://n07-eu.rcs.revma.com/1nnezw8qz7zuv"},
            {"1.FM Birds","https://strm112.1.fm/brazilianbirds_mobile_mp3"},
            {"Radio Arabella München","https://edge21.stream.radioarabella.de/radioarabella-muenchen/stream/mp3"},
            {"Antenne Bayern","https://stream.antenne.de/antenne/stream/mp3"},
            {"Bayern 2","https://dispatcher.rndfnk.com/br/br2/live/mp3/mid"},
            {"Bayern 3","https://dispatcher.rndfnk.com/br/br3/live/mp3/mid"},
            {"Deutschlandfunk","https://st01.sslstream.dlf.de/dlf/01/low/aac/stream.aac?aggregator=web"},
            {"ROCK ANTENNE","https://stream.rockantenne.de/rockantenne/stream/mp3"},
            {"BR24","https://dispatcher.rndfnk.com/br/br24/live/mp3/mid"},
            {"BR-KLASSIK","https://dispatcher.rndfnk.com/br/brklassik/live/mp3/mid"},
            {"BR Heimat","https://dispatcher.rndfnk.com/br/brheimat/live/mp3/mid"},
            {"Deutschlandfunk Kultur","https://st02.sslstream.dlf.de/dlf/02/low/aac/stream.aac?aggregator=web"}
    };

    @Override protected void onCreate(Bundle b){
        super.onCreate(b);
        favorites = getSharedPreferences("radio_favorites",0);
        build();
    }

    private void build(){
        LinearLayout root=new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(NativeUi.bg(this));
        root.setPadding(NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,16));

        LinearLayout head=new LinearLayout(this);
        head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=NativeUi.button(this,"‹",true);
        back.setOnClickListener(v->finish());
        head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,46)));
        TextView t=NativeUi.text(this,"Radio",24,true);
        t.setPadding(NativeUi.dp(this,12),0,0,0);
        head.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        favoritesToggle=NativeUi.button(this,"☆ Ulubione",true);
        favoritesToggle.setOnClickListener(v->{onlyFavorites=!onlyFavorites;renderStations();});
        head.addView(favoritesToggle,new LinearLayout.LayoutParams(NativeUi.dp(this,118),NativeUi.dp(this,46)));
        root.addView(head);

        status=NativeUi.muted(this,"Nic nie gra",13);
        LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);
        sp.setMargins(0,NativeUi.dp(this,10),0,NativeUi.dp(this,10));
        root.addView(status,sp);

        LinearLayout controls=new LinearLayout(this);
        controls.setGravity(Gravity.CENTER_VERTICAL);
        Button pause=NativeUi.button(this,"Pauza",true);
        Button stop=NativeUi.button(this,"Stop",true);
        pause.setOnClickListener(v->send(RadioService.ACTION_PAUSE,null,null));
        stop.setOnClickListener(v->send(RadioService.ACTION_STOP,null,null));
        controls.addView(pause,new LinearLayout.LayoutParams(0,NativeUi.dp(this,46),1));
        LinearLayout.LayoutParams gap=new LinearLayout.LayoutParams(0,NativeUi.dp(this,46),1);
        gap.setMargins(NativeUi.dp(this,8),0,0,0);
        controls.addView(stop,gap);
        root.addView(controls);

        TextView hint=NativeUi.muted(this,"Dotknij gwiazdki, aby przypiąć stację na górze. Ulubione zostają zapisane w telefonie.",11);
        LinearLayout.LayoutParams hp=new LinearLayout.LayoutParams(-1,-2);
        hp.setMargins(0,NativeUi.dp(this,9),0,0);
        root.addView(hint,hp);

        ScrollView sc=new ScrollView(this);
        sc.setFillViewport(true);
        list=new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        list.setPadding(0,NativeUi.dp(this,12),0,0);
        sc.addView(list);
        root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));
        setContentView(root);
        renderStations();
    }

    private void renderStations(){
        list.removeAllViews();
        favoritesToggle.setText(onlyFavorites?"★ Wszystkie":"☆ Ulubione");
        int shown=0;
        for(String[] s:STATIONS){
            if(onlyFavorites && !isFavorite(s[0])) continue;
            addStation(list,s[0],s[1]);
            shown++;
        }
        if(shown==0){
            LinearLayout c=NativeUi.card(this);
            c.addView(NativeUi.text(this,"Nie masz jeszcze ulubionych stacji",16,true));
            TextView m=NativeUi.muted(this,"Wróć do wszystkich stacji i dotknij ☆ przy wybranej pozycji.",12);
            NativeUi.addSpacer(c,this,4);
            c.addView(m);
            list.addView(c);
        }
    }

    private void addStation(LinearLayout parent,String name,String url){
        LinearLayout c=NativeUi.card(this);
        LinearLayout row=new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout tx=new LinearLayout(this);
        tx.setOrientation(LinearLayout.VERTICAL);
        tx.addView(NativeUi.text(this,name,16,true));
        boolean de=url.contains("rndfnk")||url.contains("antenne")||url.contains("arabella")||name.contains("Deutschland")||name.startsWith("BR");
        tx.addView(NativeUi.muted(this,de?"Niemcy • stream live":"Stream live",11));
        row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));

        Button star=NativeUi.button(this,isFavorite(name)?"★":"☆",true);
        star.setTextSize(20);
        star.setOnClickListener(v->{
            favorites.edit().putBoolean(key(name),!isFavorite(name)).apply();
            renderStations();
        });
        row.addView(star,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,44)));

        Button play=NativeUi.button(this,"▶",false);
        play.setOnClickListener(v->send(RadioService.ACTION_PLAY,name,url));
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(NativeUi.dp(this,52),NativeUi.dp(this,44));
        pp.leftMargin=NativeUi.dp(this,6);
        row.addView(play,pp);
        c.addView(row);
        NativeUi.softTouch(c); NativeUi.onClick(c,v->send(RadioService.ACTION_PLAY,name,url));
        parent.addView(c);
    }

    private boolean isFavorite(String name){ return favorites.getBoolean(key(name),false); }
    private String key(String name){ return "fav_"+name; }

    private void send(String action,String name,String url){
        Intent i=new Intent(this,RadioService.class).setAction(action);
        if(name!=null)i.putExtra("name",name);
        if(url!=null)i.putExtra("url",url);
        try{startService(i);}catch(Throwable ignored){}
        handler.postDelayed(this::refreshStatus,300);
    }

    private final Runnable ticker=new Runnable(){public void run(){refreshStatus();handler.postDelayed(this,1200);}};
    private void refreshStatus(){
        SharedPreferences p=getSharedPreferences("radio_state",0);
        String n=p.getString("name","");
        boolean playing=p.getBoolean("playing",false);
        String e=p.getString("error","");
        if(status!=null)status.setText(!e.isEmpty()?"Błąd: "+e:n.isEmpty()?"Nic nie gra":(playing?"Teraz gra: ":"Wybrano: ")+n);
    }
    @Override protected void onResume(){super.onResume();handler.post(ticker);}
    @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
}
