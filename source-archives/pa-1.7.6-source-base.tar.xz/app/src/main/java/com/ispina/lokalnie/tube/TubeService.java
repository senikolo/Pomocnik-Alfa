package com.ispina.lokalnie.tube;
import android.content.*;import android.app.PendingIntent;import android.net.Uri;import android.os.*;
import androidx.media3.common.*;import androidx.media3.exoplayer.*;import androidx.media3.exoplayer.source.*;import androidx.media3.datasource.*;import androidx.media3.session.*;
import com.google.common.util.concurrent.*;import com.google.common.collect.ImmutableList;
import java.util.*;
import com.ispina.lokalnie.TubeActivity;
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class TubeService extends MediaSessionService {
 public static TubeService active;public ExoPlayer player;private MediaSession session;private android.net.ConnectivityManager connectivity;private android.net.ConnectivityManager.NetworkCallback networks;private int currentQuality,currentAudio,currentSub=-1;private boolean audioOnly;public Video current;public String error="";private TubeStore store;
 private final Map<String,Video> videos=new HashMap<>();private final Handler clock=new Handler(Looper.getMainLooper());
 private long sleepDeadline;
 private final Runnable sleepExpired=new Runnable(){public void run(){long remaining=sleepRemainingMs();if(remaining>0){clock.postDelayed(this,remaining);return;}sleepDeadline=0;if(player!=null){player.pause();remember();}}};
 public long sleepRemainingMs(){return sleepDeadline==0?0:Math.max(0,sleepDeadline-SystemClock.elapsedRealtime());}
 public void setSleepTimer(long durationMs){if(durationMs<0)throw new IllegalArgumentException("Negative timer");clock.removeCallbacks(sleepExpired);sleepDeadline=durationMs==0?0:SystemClock.elapsedRealtime()+durationMs;if(durationMs>0)clock.postDelayed(sleepExpired,durationMs);}
 private final Runnable save=new Runnable(){public void run(){remember();clock.postDelayed(this,15000);}};
 public static final SessionCommand CLOSE=new SessionCommand("tube.close",Bundle.EMPTY);
 @Override public void onCreate(){super.onCreate();active=this;store=new TubeStore(this);
 player=new ExoPlayer.Builder(this).setSeekBackIncrementMs(10000).setSeekForwardIncrementMs(10000).setLoadControl(new DefaultLoadControl.Builder().setBufferDurationsMs(10000,30000,1500,2000).build()).build();
 player.setWakeMode(C.WAKE_MODE_NETWORK);player.setHandleAudioBecomingNoisy(true);player.setAudioAttributes(new AudioAttributes.Builder().setUsage(C.USAGE_MEDIA).setContentType(C.AUDIO_CONTENT_TYPE_MOVIE).build(),true);
 player.setPauseAtEndOfMediaItems(!store.flag("autoplay",false));
 player.addListener(new Player.Listener(){public void onPlayerError(PlaybackException e){error="Nie można odtworzyć materiału. Sprawdź internet lub ponownie otwórz film.";remember();}public void onMediaItemTransition(MediaItem i,int reason){current=i==null?null:videos.get(i.mediaId);error="";}public void onPlaybackStateChanged(int s){if(s==Player.STATE_READY){error="";if(current!=null&&player.getDuration()>0)current.duration=player.getDuration()/1000;}}});
 PendingIntent open=PendingIntent.getActivity(this,0,new Intent(this,TubeActivity.class).putExtra("player",true),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
 session=new MediaSession.Builder(this,player).setSessionActivity(open).setCallback(new MediaSession.Callback(){
 public MediaSession.ConnectionResult onConnect(MediaSession s,MediaSession.ControllerInfo c){return new MediaSession.ConnectionResult.AcceptedResultBuilder(s).setAvailableSessionCommands(MediaSession.ConnectionResult.DEFAULT_SESSION_COMMANDS.buildUpon().add(CLOSE).build()).build();}
 public ListenableFuture<SessionResult> onCustomCommand(MediaSession s,MediaSession.ControllerInfo c,SessionCommand command,Bundle args){if(command.customAction.equals(CLOSE.customAction)){close();return Futures.immediateFuture(new SessionResult(SessionResult.RESULT_SUCCESS));}return Futures.immediateFuture(new SessionResult(SessionError.ERROR_NOT_SUPPORTED));}
 }).setCustomLayout(ImmutableList.of(new CommandButton.Builder().setDisplayName("Zamknij").setIconResId(android.R.drawable.ic_menu_close_clear_cancel).setSessionCommand(CLOSE).build())).build();clock.post(save);watchNetwork();
 }
 public void remember(){saveQueue();if(current!=null&&player!=null)store.history(current,player.getCurrentPosition());}
 public void saveQueue(){if(player==null)return;org.json.JSONArray a=new org.json.JSONArray();for(int i=0;i<player.getMediaItemCount();i++){Video v=videos.get(player.getMediaItemAt(i).mediaId);if(v!=null)a.put(v.json());}store.save("queue",a);}
 public void add(Video v,int quality,int audio,int subtitle,boolean onlyAudio,int mode){add(v,quality,audio,subtitle,onlyAudio,mode,false);}
 public void add(Video v,int quality,int audio,int subtitle,boolean onlyAudio,int mode,boolean startOver){
 remember();if(startOver)store.prefs.edit().remove("position:"+v.url).apply();error="";if(mode==0)videos.clear();else if(player.getMediaItemCount()>=200)throw new IllegalStateException("Kolejka ma już 200 materiałów.");videos.put(v.url,v);MediaSource source=source(v,quality,audio,subtitle,onlyAudio);player.setPauseAtEndOfMediaItems(!store.flag("autoplay",false));
 if(mode==0){currentQuality=quality;currentAudio=audio;currentSub=subtitle;audioOnly=onlyAudio;player.setMediaSource(source);current=v;player.prepare();player.seekTo(TubeUx.resumePosition(store.prefs.getLong("position:"+v.url,0),v.duration>0?v.duration*1000:0));player.play();}
 else {int index=mode==1?Math.min(player.getCurrentMediaItemIndex()+1,player.getMediaItemCount()):player.getMediaItemCount();player.addMediaSource(index,source);if(player.getMediaItemCount()==1){current=v;player.prepare();player.play();}}
 }
 public void switchSource(int quality,int audio,int subtitle,boolean onlyAudio){if(current==null)return;currentQuality=quality;currentAudio=audio;currentSub=subtitle;audioOnly=onlyAudio;Video v=current;long pos=player.getCurrentPosition();boolean play=player.getPlayWhenReady();MediaSource s=source(v,quality,audio,subtitle,onlyAudio);int index=player.getCurrentMediaItemIndex();player.removeMediaItem(index);player.addMediaSource(index,s);player.seekTo(index,pos);player.prepare();player.setPlayWhenReady(play);}
 private MediaSource source(Video v,int quality,int audio,int sub,boolean only){
 DefaultMediaSourceFactory factory=new DefaultMediaSourceFactory(new DefaultDataSource.Factory(this,new DefaultHttpDataSource.Factory().setUserAgent("PomocnikAlfa/1.7").setConnectTimeoutMs(15000).setReadTimeoutMs(20000)));
 MediaMetadata md=new MediaMetadata.Builder().setTitle(v.title).setArtist(v.author).setArtworkUri(v.thumb.isEmpty()?null:Uri.parse(v.thumb)).build();
 Video.Source a=v.audio.isEmpty()?null:v.audio.get(Math.max(0,Math.min(audio,v.audio.size()-1)));
 Video.Source s=(only&&a!=null)||v.video.isEmpty()?a:v.video.get(Math.max(0,Math.min(quality,v.video.size()-1)));
 if(s==null)throw new IllegalArgumentException("Brak ścieżki audio lub wideo.");
 MediaItem.Builder b=new MediaItem.Builder().setMediaId(v.url).setUri(s.url).setMimeType(s.mime).setMediaMetadata(md);
 if(sub>=0&&sub<v.subtitles.size()){Video.Source t=v.subtitles.get(sub);b.setSubtitleConfigurations(Collections.singletonList(new MediaItem.SubtitleConfiguration.Builder(Uri.parse(t.url)).setMimeType(t.mime).setLanguage(t.language).setSelectionFlags(C.SELECTION_FLAG_DEFAULT).build()));}
 MediaSource main=factory.createMediaSource(b.build());
 if(s.separate&&a!=null&&!only){MediaItem ai=new MediaItem.Builder().setMediaId(v.url).setUri(a.url).setMimeType(a.mime).build();main=new MergingMediaSource(main,factory.createMediaSource(ai));}
 player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_VIDEO,only).build());return main;
 }
 private void watchNetwork(){connectivity=(android.net.ConnectivityManager)getSystemService(CONNECTIVITY_SERVICE);networks=new android.net.ConnectivityManager.NetworkCallback(){public void onCapabilitiesChanged(android.net.Network n,android.net.NetworkCapabilities c){clock.post(()->adaptNetwork());}public void onLost(android.net.Network n){clock.post(()->{if(!connectivity.isActiveNetworkMetered()&&player.getPlayerError()!=null&&current!=null)player.prepare();});}};try{if(Build.VERSION.SDK_INT>=24)connectivity.registerDefaultNetworkCallback(networks);else connectivity.registerNetworkCallback(new android.net.NetworkRequest.Builder().addCapability(android.net.NetworkCapabilities.NET_CAPABILITY_INTERNET).build(),networks);}catch(Exception ignored){}}
 private void adaptNetwork(){if(current==null||current.video.isEmpty()||current.url.startsWith("file:"))return;int height=store.prefs.getInt(connectivity.isActiveNetworkMetered()?"quality_mobile":"quality_wifi",connectivity.isActiveNetworkMetered()?360:720);int best=0,h=-1;for(int i=0;i<current.video.size();i++){int v=current.video.get(i).height;if(v<=height&&v>h){best=i;h=v;}}if(best!=currentQuality)try{switchSource(best,currentAudio,currentSub,audioOnly);}catch(Exception ignored){}if(player.getPlayerError()!=null)player.prepare();}
 public void close(){setSleepTimer(0);remember();player.stop();player.clearMediaItems();current=null;videos.clear();stopSelf();}
 @Override public MediaSession onGetSession(MediaSession.ControllerInfo c){return session;}
 @Override public void onDestroy(){if(connectivity!=null&&networks!=null)try{connectivity.unregisterNetworkCallback(networks);}catch(Exception ignored){}clock.removeCallbacksAndMessages(null);remember();if(session!=null)session.release();if(player!=null)player.release();if(active==this)active=null;super.onDestroy();}
}
