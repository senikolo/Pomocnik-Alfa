package com.ispina.lokalnie;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.widget.RemoteViews;

public class TodayWidget extends AppWidgetProvider {
    @Override public void onUpdate(Context context, AppWidgetManager manager, int[] ids){
        for(int id:ids) updateOne(context,manager,id);
    }

    static void updateAll(Context context){
        try{
            AppWidgetManager m=AppWidgetManager.getInstance(context);
            int[] ids=m.getAppWidgetIds(new ComponentName(context,TodayWidget.class));
            for(int id:ids) updateOne(context,m,id);
        }catch(Throwable ignored){}
    }

    private static void updateOne(Context c,AppWidgetManager m,int id){
        SharedPreferences p=c.getSharedPreferences("dashboard_state",0);
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_today);
        v.setTextViewText(R.id.widgetTask,p.getString("task","Brak zadań"));
        v.setTextViewText(R.id.widgetReminder,p.getString("reminder","Brak przypomnień"));
        v.setTextViewText(R.id.widgetSubs,p.getString("subscriptions","Brak subskrypcji"));
        Intent i=new Intent(c,MainActivity.class).putExtra("screen","day").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi=PendingIntent.getActivity(c,741,i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
        v.setOnClickPendingIntent(R.id.widgetRoot,pi);
        m.updateAppWidget(id,v);
    }
}
