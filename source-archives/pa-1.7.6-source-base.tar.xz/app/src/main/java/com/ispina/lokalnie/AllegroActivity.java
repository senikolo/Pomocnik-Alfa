package com.ispina.lokalnie;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Build;
import android.graphics.Bitmap;
import android.view.View;
import android.view.inputmethod.InputMethodManager;
import android.webkit.*;
import android.widget.*;
import com.ispina.lokalnie.deals.DealsRepository;

/** Official storefront, without scraping prices or exposing a native JavaScript bridge. */
public final class AllegroActivity extends ThemedActivity {
 private WebView web;private EditText query;private ProgressBar progress;private TextView status;private Button retry;private boolean failed;
 @Override protected void onCreate(Bundle saved){super.onCreate(saved);
  LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setBackgroundColor(NativeUi.bg(this));setContentView(root);
  LinearLayout controls=new LinearLayout(this);controls.setOrientation(LinearLayout.VERTICAL);controls.setPadding(NativeUi.dp(this,12),NativeUi.dp(this,8),NativeUi.dp(this,12),NativeUi.dp(this,8));
  Button back=NativeUi.button(this,"‹  Allegro · wróć do Pomocnika",true);back.setOnClickListener(v->finish());controls.addView(back);
  LinearLayout row=new LinearLayout(this);query=NativeUi.input(this,"Nazwa produktu");query.setSingleLine(true);query.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);query.setOnEditorActionListener((v,a,event)->{if(a==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){find();return true;}return false;});row.addView(query,new LinearLayout.LayoutParams(0,-2,1));Button find=NativeUi.button(this,"Szukaj",false);find.setOnClickListener(v->find());row.addView(find,new LinearLayout.LayoutParams(-2,-2));controls.addView(row);
  status=NativeUi.muted(this,"Wyniki pochodzą bezpośrednio z Allegro.",12);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);controls.addView(status);
  retry=NativeUi.button(this,"Spróbuj ponownie",true);retry.setVisibility(View.GONE);retry.setOnClickListener(v->web.reload());controls.addView(retry);root.addView(controls);
  progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setMax(100);root.addView(progress,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,3)));
  web=new WebView(this);root.addView(web,new LinearLayout.LayoutParams(-1,0,1));WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(false);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);if(Build.VERSION.SDK_INT>=26)settings.setSafeBrowsingEnabled(true);
  web.setWebChromeClient(new WebChromeClient(){@Override public void onProgressChanged(WebView view,int value){progress.setProgress(value);progress.setVisibility(value==100?View.GONE:View.VISIBLE);}});
  web.setWebViewClient(new WebViewClient(){
   @Override public void onPageStarted(WebView view,String url,Bitmap icon){failed=false;retry.setVisibility(View.GONE);status.setText("Ładuję stronę Allegro…");}
   @Override public void onPageFinished(WebView view,String url){if(!failed){status.setText("Strona Allegro · ceny i warunki sprawdzisz w ofercie.");progress.setVisibility(View.GONE);}}
   @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return route(request.getUrl());}
   @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return route(Uri.parse(url));}
   @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){if(request.isForMainFrame())showError("Nie udało się załadować strony. Sprawdź internet i spróbuj ponownie.");}
   @Override public void onReceivedHttpError(WebView view,WebResourceRequest request,WebResourceResponse response){if(request.isForMainFrame()&&response.getStatusCode()>=400)showError(response.getStatusCode()==403?"Allegro ograniczyło dostęp. Jeśli strona pokazuje weryfikację, wykonaj ją na stronie.":"Allegro chwilowo nie odpowiada. Spróbuj ponownie.");}
  });
  web.setDownloadListener((url,ua,disposition,mime,length)->routeExternal(Uri.parse(url)));
  query.setText(saved==null?getIntent().getStringExtra("query"):saved.getString("query",""));if(saved==null||web.restoreState(saved)==null)find();
 }
 private boolean route(Uri uri){String host=uri.getHost(),scheme=uri.getScheme();if("https".equals(scheme)&&host!=null&&(host.equals("allegro.pl")||host.endsWith(".allegro.pl")||host.equals("allegro.com")||host.endsWith(".allegro.com")))return false;routeExternal(uri);return true;}
 private void routeExternal(Uri uri){if(!"https".equals(uri.getScheme()))return;try{startActivity(new Intent(Intent.ACTION_VIEW,uri));}catch(Exception e){Toast.makeText(this,"Nie można otworzyć tej strony.",Toast.LENGTH_SHORT).show();}}
 private void showError(String message){failed=true;status.setText(message);retry.setVisibility(View.VISIBLE);progress.setVisibility(View.GONE);}
 private void find(){String q=DealsRepository.clean(query.getText().toString());if(q.length()<2||q.length()>80){query.setError("Wpisz od 2 do 80 znaków.");return;}query.setError(null);query.clearFocus();InputMethodManager input=(InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(input!=null)input.hideSoftInputFromWindow(query.getWindowToken(),0);web.loadUrl(DealsRepository.allegroUrl(q));}
 @Override protected void onSaveInstanceState(Bundle b){super.onSaveInstanceState(b);b.putString("query",query.getText().toString());web.saveState(b);}
 @Override public void onBackPressed(){if(web!=null&&web.canGoBack())web.goBack();else super.onBackPressed();}
 @Override protected void onPause(){if(web!=null)web.onPause();super.onPause();}
 @Override protected void onResume(){super.onResume();if(web!=null)web.onResume();}
 @Override protected void onDestroy(){if(web!=null){web.stopLoading();web.setWebChromeClient(null);web.setWebViewClient(null);((android.view.ViewGroup)web.getParent()).removeView(web);web.destroy();web=null;}super.onDestroy();}
}
