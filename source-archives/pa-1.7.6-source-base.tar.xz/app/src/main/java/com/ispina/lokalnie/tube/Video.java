package com.ispina.lokalnie.tube;
import org.json.*;
import java.util.*;
public final class Video {
 public String url="",title="",author="",channel="",thumb="",license="",provider=""; public long duration; public boolean downloadable;
 public final List<Source> video=new ArrayList<>(), audio=new ArrayList<>(), subtitles=new ArrayList<>(); public final List<Video> related=new ArrayList<>();
 public JSONObject json(){JSONObject o=new JSONObject();try{o.put("url",url).put("title",title).put("author",author).put("channel",channel).put("thumb",thumb).put("duration",duration).put("provider",provider);}catch(Exception ignored){}return o;}
 public static Video from(JSONObject o){Video v=new Video();v.url=o.optString("url");v.title=o.optString("title");v.author=o.optString("author");v.channel=o.optString("channel");v.thumb=o.optString("thumb");v.duration=o.optLong("duration");v.provider=o.optString("provider");return v;}
 public static final class Source {public String url,label,mime,extension,language="";public boolean separate;public int height;public long size;public Source(String u,String l,String m,String e){url=u;label=l;mime=m;extension=e;}}
}
