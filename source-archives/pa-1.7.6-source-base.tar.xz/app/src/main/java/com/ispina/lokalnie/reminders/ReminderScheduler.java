package com.ispina.lokalnie.reminders;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.os.Build;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.Calendar;

public final class ReminderScheduler {
    private static final String PREF="my_reminders";
    private ReminderScheduler(){}

    public static boolean saveAndSchedule(Context c,String id,String title,String body,long at,String repeat){
        if(id==null||id.isEmpty()||at<=System.currentTimeMillis())return false;
        try{
            JSONObject o=new JSONObject();o.put("id",id);o.put("title",title==null?"Przypomnienie":title);o.put("body",body==null?"":body);o.put("at",at);o.put("repeat",repeat==null?"once":repeat);o.put("anchor",at);o.put("enabled",true);
            if(!schedule(c,o,false))return false;
            c.getSharedPreferences(PREF,0).edit().putString(id,o.toString()).apply();
            return true;
        }catch(Exception e){return false;}
    }

    public static void cancel(Context c,String id){
        if(id==null)return;
        try{ alarm(c).cancel(pending(c,id,0,"FIRE",null)); }catch(Throwable ignored){}
        try{ alarm(c).cancel(pending(c,id,77,"SNOOZE_FIRE",null)); }catch(Throwable ignored){}
        c.getSharedPreferences(PREF,0).edit().remove(id).apply();
    }

    public static void restoreAll(Context c){
        SharedPreferences p=c.getSharedPreferences(PREF,0);
        for(String key:p.getAll().keySet()){
            try{
                JSONObject o=new JSONObject(p.getString(key,"{}"));
                if(o.optBoolean("enabled",true)) schedule(c,o,true);
            }catch(Exception ignored){}
        }
    }

    public static String status(Context c){
        try{JSONArray a=new JSONArray();SharedPreferences p=c.getSharedPreferences(PREF,0);for(String k:p.getAll().keySet())a.put(new JSONObject(p.getString(k,"{}")));return a.toString();}catch(Exception e){return "[]";}
    }

    static void onFired(Context c,JSONObject o){
        try{if(!o.has("anchor"))o.put("anchor",o.optLong("at"));}catch(Exception ignored){}
        String repeat=o.optString("repeat","once");
        if("once".equals(repeat)){c.getSharedPreferences(PREF,0).edit().remove(o.optString("id")).apply();return;}
        long next=nextAfter(o,System.currentTimeMillis()+60000L);try{o.put("at",next);}catch(Exception ignored){}
        c.getSharedPreferences(PREF,0).edit().putString(o.optString("id"),o.toString()).apply();schedule(c,o,false);
    }

    private static boolean schedule(Context c,JSONObject o,boolean fromRestore){
        long now=System.currentTimeMillis(),at=o.optLong("at",0);String repeat=o.optString("repeat","once");
        if(at<=0)return false;
        if(at<=now){
            if("once".equals(repeat)){
                if(fromRestore)c.getSharedPreferences(PREF,0).edit().remove(o.optString("id")).apply();
                return false;
            }
            at=nextAfter(o,now+60000L);try{o.put("at",at);}catch(Exception ignored){}
            c.getSharedPreferences(PREF,0).edit().putString(o.optString("id"),o.toString()).apply();
        }
        PendingIntent pi=pending(c,o.optString("id"),0,"FIRE",o.toString());
        AlarmManager am=alarm(c);
        try{
            if(Build.VERSION.SDK_INT<31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else if(Build.VERSION.SDK_INT>=23) am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);
            else am.set(AlarmManager.RTC_WAKEUP,at,pi);
            return true;
        }catch(Throwable e){return false;}
    }

    static void snooze(Context c,JSONObject o){
        long at=System.currentTimeMillis()+10*60*1000L;
        PendingIntent pi=pending(c,o.optString("id"),77,"SNOOZE_FIRE",o.toString());
        AlarmManager am=alarm(c);if(Build.VERSION.SDK_INT>=23)am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP,at,pi);else am.set(AlarmManager.RTC_WAKEUP,at,pi);
    }

    private static long nextAfter(JSONObject o,long now){
        String r=o.optString("repeat","once");long base=o.optLong("anchor",o.optLong("at",now+60000L));
        Calendar c=Calendar.getInstance();c.setTimeInMillis(Math.max(base,now));
        Calendar original=Calendar.getInstance();original.setTimeInMillis(base);
        c.set(Calendar.HOUR_OF_DAY,original.get(Calendar.HOUR_OF_DAY));c.set(Calendar.MINUTE,original.get(Calendar.MINUTE));c.set(Calendar.SECOND,0);c.set(Calendar.MILLISECOND,0);
        if("daily".equals(r)){while(c.getTimeInMillis()<=now)c.add(Calendar.DAY_OF_YEAR,1);return c.getTimeInMillis();}
        if("weekly".equals(r)){c.set(Calendar.DAY_OF_WEEK,original.get(Calendar.DAY_OF_WEEK));while(c.getTimeInMillis()<=now)c.add(Calendar.WEEK_OF_YEAR,1);return c.getTimeInMillis();}
        if("monthly".equals(r)||"yearly".equals(r)){
            c.set(Calendar.DAY_OF_MONTH,1);
            if("yearly".equals(r))c.set(Calendar.MONTH,original.get(Calendar.MONTH));
            c.set(Calendar.DAY_OF_MONTH,Math.min(original.get(Calendar.DAY_OF_MONTH),c.getActualMaximum(Calendar.DAY_OF_MONTH)));
            if(c.getTimeInMillis()<=now){
                c.set(Calendar.DAY_OF_MONTH,1);
                c.add("monthly".equals(r)?Calendar.MONTH:Calendar.YEAR,1);
                c.set(Calendar.DAY_OF_MONTH,Math.min(original.get(Calendar.DAY_OF_MONTH),c.getActualMaximum(Calendar.DAY_OF_MONTH)));
            }
            return c.getTimeInMillis();
        }
        if(r.startsWith("days:")){
            String[] ds=r.substring(5).split(",");
            for(int add=0;add<14;add++){
                Calendar t=(Calendar)c.clone();t.add(Calendar.DAY_OF_YEAR,add);int dow=t.get(Calendar.DAY_OF_WEEK);int mondayIndex=(dow+5)%7+1;
                boolean ok=false;for(String d:ds)try{if(Integer.parseInt(d.trim())==mondayIndex)ok=true;}catch(Exception ignored){}
                if(ok&&t.getTimeInMillis()>now)return t.getTimeInMillis();
            }
        }
        return Math.max(base,now+60000L);
    }

    private static AlarmManager alarm(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
    static PendingIntent pending(Context c,String id,int salt,String action,String payload){
        Intent i=new Intent(c,ReminderReceiver.class).setAction(action);
        i.setData(Uri.parse("pomocnik://reminder/"+Uri.encode(id==null?"rem":id)+"/"+salt));
        if(payload!=null)i.putExtra("payload",payload);
        return PendingIntent.getBroadcast(c,code(id,salt),i,PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
    }
    static int code(String id,int salt){return (id==null?0:id.hashCode())^salt;}
}
