package com.ispina.lokalnie;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

public class AppearanceActivity extends ThemedActivity {
    private final String[] names = {"Wyłączone", "1 · Bardzo delikatne", "2 · Delikatne", "3 · Średnie", "4 · Wyraźne", "5 · Mocne"};
    private final Button[] options = new Button[6];
    private TextView summary;
    private Button test;
    private ScrollView scroll;
    private final Button[] themeOptions=new Button[4],shadeOptions=new Button[3];
    private ThemeTransition transition;
    private final String[] themeIcons={"💜", "💙", "💠", "💚"};

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(NativeUi.bg(this));
        getWindow().getDecorView().setSystemUiVisibility(android.view.View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
        scroll = new ScrollView(this); scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,24));
        root.setBackgroundColor(NativeUi.bg(this)); scroll.addView(root); setContentView(scroll);
        LinearLayout head=new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=NativeUi.button(this,"‹",true); back.setContentDescription("Wróć do Pomocnika Alfa"); back.setOnClickListener(v->finish());
        head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,48)));
        TextView title=NativeUi.text(this,"Ustawienia",24,true); title.setPadding(NativeUi.dp(this,12),0,0,0); head.addView(title); root.addView(head);
        NativeUi.addSpacer(root,this,20);
        LinearLayout themes=NativeUi.card(this);
        themes.addView(NativeUi.text(this,"🎨 Motyw aplikacji",21,true));
        NativeUi.addSpacer(themes,this,6);
        themes.addView(NativeUi.muted(this,"Wybierz ulubiony kolor. Motyw obejmuje całą aplikację i zapisuje się automatycznie.",14));
        NativeUi.addSpacer(themes,this,14);
        for(int i=0;i<NativeUi.THEME_NAMES.length;i++){
            final int choice=i;
            Button option=NativeUi.button(this,"",true);themeOptions[i]=option;
            option.setOnClickListener(v->chooseTheme(choice,NativeUi.shade(this)));
            themes.addView(option,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,52)));
            NativeUi.addSpacer(themes,this,8);
        }
        NativeUi.addSpacer(themes,this,8);
        themes.addView(NativeUi.text(this,"Odcień",18,true));
        NativeUi.addSpacer(themes,this,8);
        for(int i=0;i<shadeOptions.length;i++){
            final int tone=i;Button option=NativeUi.button(this,"",true);shadeOptions[i]=option;
            option.setOnClickListener(v->chooseTheme(NativeUi.theme(this),tone));
            themes.addView(option,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,52)));
            NativeUi.addSpacer(themes,this,8);
        }
        themes.addView(NativeUi.muted(this,"Kolory zmieniają się płynnie w ciągu 1 sekundy.",13));
        refreshThemeButtons(NativeUi.theme(this),NativeUi.shade(this));
        root.addView(themes);
        LinearLayout card=NativeUi.card(this);
        card.addView(NativeUi.text(this,"📳 Wibracje dotyku",21,true));
        NativeUi.addSpacer(card,this,6);
        card.addView(NativeUi.muted(this,"Krótka wibracja potwierdza naciśnięcie kafelka lub przycisku. Wybierz poziom wygodny dla Ciebie.",14));
        NativeUi.addSpacer(card,this,14);
        summary=NativeUi.text(this,"",14,true); card.addView(summary);
        NativeUi.addSpacer(card,this,12);
        for(int i=0;i<options.length;i++) {
            final int level=i;
            Button option=NativeUi.button(this,names[i],true); option.setTag("no_haptic"); options[i]=option;
            option.setOnClickListener(v->{ Haptics.setLevel(this,level); refresh(); Haptics.click(this); });
            card.addView(option,new LinearLayout.LayoutParams(-1,-2)); NativeUi.addSpacer(card,this,8);
        }
        test=NativeUi.button(this,"Przetestuj wibrację",false); test.setTag("no_haptic");
        test.setOnClickListener(v->{ if(!Haptics.click(this)) Toast.makeText(this,"Wibracja jest niedostępna lub wyłączona.",Toast.LENGTH_SHORT).show(); });
        card.addView(test,new LinearLayout.LayoutParams(-1,-2));
        NativeUi.addSpacer(card,this,12);
        card.addView(NativeUi.muted(this,"Wybór zapisuje się automatycznie. Na telefonach bez regulacji siły poziomy różnią się długością impulsu. To ustawienie dotyczy dotyku w Pomocniku Alfa. Wibracjami powiadomień zarządza Android.",13));
        root.addView(card); refresh();
    }

    private void chooseTheme(int family,int shade){
        if(NativeUi.theme(this)==family && NativeUi.shade(this)==shade)return;
        if(transition!=null)transition.cancel();
        // The selection changes immediately; colors keep their current frame.
        refreshThemeButtons(family,shade);
        transition=new ThemeTransition(this,scroll,family,shade);
        acceptCurrentTheme();transition.start();
    }
    private void refreshThemeButtons(int family,int tone){
        for(int i=0;i<themeOptions.length;i++){
            styleChoice(themeOptions[i],themeIcons[i]+"  "+NativeUi.THEME_NAMES[i],i==family);
        }
        for(int i=0;i<shadeOptions.length;i++)styleChoice(shadeOptions[i],NativeUi.SHADE_NAMES[i],i==tone);
    }
    private void styleChoice(Button b,String label,boolean active){
        b.setText((active?"✓  ":"")+label);b.setSelected(active);
        b.setContentDescription(label+(active?", wybrano":""));
        b.setTextColor(active?android.graphics.Color.WHITE:NativeUi.ink(this));
        b.setBackground(NativeUi.roundedStroke(active?NativeUi.green(this):NativeUi.soft(this),active?NativeUi.green(this):NativeUi.line(this),16,this));
    }
    @Override protected void onDestroy(){if(transition!=null)transition.cancel();NativeUi.transitionPalette(this,null);super.onDestroy();}
    private void refresh() {
        int selected=Haptics.level(this); boolean available=Haptics.available(this);
        summary.setText(available ? "Wybrano: "+names[selected] : "Ten telefon nie ma silnika wibracji.");
        for(int i=0;i<options.length;i++) {
            Button b=options[i]; boolean active=i==selected;
            b.setText((active?"✓  ":"")+names[i]); b.setSelected(active);
            b.setContentDescription(names[i]+(active?", wybrany":""));
            b.setTextColor(active?android.graphics.Color.WHITE:NativeUi.ink(this));
            b.setBackground(NativeUi.roundedStroke(active?NativeUi.green(this):NativeUi.soft(this),active?NativeUi.green(this):NativeUi.line(this),16,this));
            b.setEnabled(available || i==0);
        }
        test.setEnabled(available && selected>0); test.setAlpha(test.isEnabled()?1f:.5f);
    }
}
