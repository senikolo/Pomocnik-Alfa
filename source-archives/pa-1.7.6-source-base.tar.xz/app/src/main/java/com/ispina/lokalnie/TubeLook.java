package com.ispina.lokalnie;
import android.content.Context;
import android.graphics.*;
import android.graphics.drawable.Drawable;
/** Consistent small line icons; drawn locally on every supported Android. */
final class TubeLook extends Drawable {
 private final Context context;private final String key;private final boolean placeholder;private final Paint paint=new Paint(Paint.ANTI_ALIAS_FLAG);
 TubeLook(Context c,String key,boolean placeholder){context=c;this.key=key;this.placeholder=placeholder;}
 static Drawable icon(Context c,String key){return new TubeLook(c,key,false);}
 static Drawable placeholder(Context c){return new TubeLook(c,"play",true);}
 @Override public void draw(Canvas canvas){Rect b=getBounds();float size=Math.min(b.width(),b.height());if(placeholder)size=Math.min(NativeUi.dp(context,44),size*.4f);if(size<=0)return;int saved=canvas.save();canvas.translate(b.exactCenterX()-size/2,b.exactCenterY()-size/2);canvas.scale(size/24,size/24);paint.setColor(NativeUi.green(context));paint.setStyle(Paint.Style.STROKE);paint.setStrokeWidth(1.7f);paint.setStrokeCap(Paint.Cap.ROUND);paint.setStrokeJoin(Paint.Join.ROUND);Path p=new Path();
 if(key.equals("♡")){p.moveTo(12,20);p.cubicTo(9,18,3,14,3,8);p.cubicTo(3,3,9,2,12,7);p.cubicTo(15,2,21,3,21,8);p.cubicTo(21,14,15,18,12,20);canvas.drawPath(p,paint);}
 else if(key.equals("↓")){line(canvas,12,3,12,15);line(canvas,7,10,12,15);line(canvas,17,10,12,15);p.moveTo(4,16);p.lineTo(4,21);p.lineTo(20,21);p.lineTo(20,16);canvas.drawPath(p,paint);}
 else if(key.equals("↺")){canvas.drawArc(4,4,20,20,-70,290,false,paint);line(canvas,4,4,4,10);line(canvas,4,10,9,10);line(canvas,12,8,12,12);line(canvas,12,12,16,14);}
 else if(key.equals("≡")){line(canvas,4,6,18,6);line(canvas,4,11,18,11);line(canvas,4,16,11,16);p.moveTo(16,15);p.lineTo(21,18);p.lineTo(16,21);p.close();canvas.drawPath(p,paint);}
 else if(key.equals("◎")){canvas.drawCircle(12,12,3,paint);canvas.drawArc(5,5,19,19,-55,110,false,paint);canvas.drawArc(5,5,19,19,125,110,false,paint);canvas.drawArc(1,1,23,23,-55,110,false,paint);canvas.drawArc(1,1,23,23,125,110,false,paint);}
 else if(key.equals("⚙")){for(int y:new int[]{6,12,18})line(canvas,3,y,21,y);paint.setStyle(Paint.Style.FILL);canvas.drawCircle(8,6,2.5f,paint);canvas.drawCircle(16,12,2.5f,paint);canvas.drawCircle(10,18,2.5f,paint);}
 else if(key.equals("◷")){canvas.drawCircle(12,12,9,paint);line(canvas,12,6,12,12);line(canvas,12,12,16,15);}
 else if(key.equals("⌕")){canvas.drawCircle(10,10,6.5f,paint);line(canvas,15,15,21,21);}
 else {p.moveTo(8,5);p.lineTo(20,12);p.lineTo(8,19);p.close();canvas.drawPath(p,paint);}
 canvas.restoreToCount(saved);}
 private void line(Canvas c,float x,float y,float a,float b){c.drawLine(x,y,a,b,paint);}
 @Override public int getIntrinsicWidth(){return NativeUi.dp(context,placeholder?160:24);}
 @Override public int getIntrinsicHeight(){return NativeUi.dp(context,placeholder?90:24);}
 @Override public void setAlpha(int a){paint.setAlpha(a);}
 @Override public void setColorFilter(ColorFilter f){paint.setColorFilter(f);}
 @Override public int getOpacity(){return PixelFormat.TRANSLUCENT;}
}
