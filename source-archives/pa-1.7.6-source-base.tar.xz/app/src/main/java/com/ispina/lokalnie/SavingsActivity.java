package com.ispina.lokalnie;
import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.widget.*;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
public class SavingsActivity extends ThemedActivity {
    private static final String[] TIPS={
        "Przed zakupami sprawdź zapasy i zapisz krótką listę. Kupuj to, czego potrzebujesz.",
        "Porównuj cenę za kilogram lub litr. Większe opakowanie nie zawsze jest tańsze.",
        "Raz w miesiącu przejrzyj subskrypcje. Ustaw przypomnienie przed kolejną opłatą.",
        "Przed zakupem biletu porównaj koszt 90 dni z trzema biletami 30-dniowymi. Uwzględnij planowane przerwy w podróżach.",
        "Nie kupuj dodatkowych sztuk tylko dla rabatu. Policz koszt całego koszyka.",
        "Na nieplanowany zakup daj sobie dobę namysłu. Zapisz go w Notatkach.",
        "Porcje jedzenia na kolejne dni możesz zamrozić. Podpisz pojemnik datą.",
        "Przy zakupach online dolicz dostawę. Sprawdź też koszt odbioru w sklepie.",
        "Zaplanuj jedno większe wyjście po zakupy. Mniej spontanicznych wizyt ułatwia trzymanie się listy.",
        "Przy promocji sprawdź datę końca i warunki: kartę klienta, kupon, limit sztuk i minimalny zakup."
    };
    @Override public void onCreate(Bundle b){super.onCreate(b);
        ScrollView scroll=new ScrollView(this);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,16),NativeUi.dp(this,24));root.setBackgroundColor(NativeUi.bg(this));scroll.addView(root);setContentView(scroll);
        Button back=NativeUi.button(this,"‹  Oszczędzacz",true);back.setOnClickListener(v->finish());root.addView(back);NativeUi.addSpacer(root,this,14);
        LinearLayout smart=NativeUi.card(this);smart.addView(NativeUi.text(this,"💡 Smart Saver",23,true));smart.addView(NativeUi.muted(this,"Porady do wpisanej usługi lub produktu, sprawdzanie źródeł i kalkulator kosztów.",14));Button saver=NativeUi.button(this,"Otwórz Smart Saver",false);saver.setOnClickListener(v->startActivity(new Intent(this,SmartSaverActivity.class)));smart.addView(saver);root.addView(smart);
        LinearLayout promo=NativeUi.card(this);promo.setBackground(NativeUi.rounded(NativeUi.softStrong(this),24,this));promo.addView(NativeUi.text(this,"Łowca promocji",23,true));NativeUi.addSpacer(promo,this,6);promo.addView(NativeUi.muted(this,"Znajdź mleko, kawę i inne produkty w ofertach dziewięciu sklepów. Ustaw alert na swój produkt.",14));NativeUi.addSpacer(promo,this,14);Button browse=NativeUi.button(this,"Szukaj promocji i ustaw alert",false);browse.setOnClickListener(v->startActivity(new Intent(this,DealsActivity.class)));promo.addView(browse,new LinearLayout.LayoutParams(-1,-2));root.addView(promo);
        LinearLayout tip=NativeUi.card(this);tip.addView(NativeUi.text(this,"Mały krok na dziś",21,true));Calendar day=Calendar.getInstance(SunTimes.ZONE);tip.addView(NativeUi.muted(this,TIPS[day.get(Calendar.DAY_OF_YEAR)%TIPS.length],15));root.addView(tip);
        LinearLayout calc=NativeUi.card(this);calc.addView(NativeUi.text(this,"Bilet 30 czy 90 dni?",19,true));
        EditText a=amount("Cena biletu 30-dniowego (zł)"),c=amount("Cena biletu 90-dniowego (zł)");calc.addView(a);calc.addView(c);TextView result=NativeUi.text(this,"",14,true);Button compare=NativeUi.button(this,"Porównaj 90 dni podróży",false);compare.setOnClickListener(v->{try{BigDecimal shortCost=number(a).multiply(new BigDecimal("3")),longCost=number(c),diff=shortCost.subtract(longCost);result.setText(diff.signum()>0?"Bilet 90-dniowy: o "+money(diff)+" taniej.":diff.signum()<0?"Trzy bilety 30-dniowe: o "+money(diff.abs())+" taniej.":"Oba warianty kosztują tyle samo.");}catch(Exception e){result.setText("Wpisz dwie poprawne ceny większe od zera.");}});calc.addView(compare);calc.addView(result);root.addView(calc);
        LinearLayout goal=NativeUi.card(this);goal.addView(NativeUi.text(this,"Mój mały cel",19,true));SharedPreferences prefs=getSharedPreferences("savings",0);EditText label=NativeUi.input(this,"Na co odkładasz?");label.setText(prefs.getString("label",""));goal.addView(label);EditText total=amount("Cel (zł)"),saved=amount("Odłożone (zł)");total.setText(prefs.getString("total",""));saved.setText(prefs.getString("saved",""));goal.addView(total);goal.addView(saved);TextView progress=NativeUi.muted(this,"",14);Runnable update=()->{try{BigDecimal left=number(total).subtract(new BigDecimal(saved.getText().toString().replace(',','.')));progress.setText(left.signum()<=0?"Cel osiągnięty!":"Do celu zostało "+money(left));}catch(Exception ignored){progress.setText("Wpisz swój cel i odłożoną kwotę.");}};Button save=NativeUi.button(this,"Zapisz cel",false);save.setOnClickListener(v->{try{number(total);BigDecimal n=new BigDecimal(saved.getText().toString().replace(',','.'));if(n.signum()<0)throw new IllegalArgumentException();prefs.edit().putString("label",label.getText().toString()).putString("total",total.getText().toString()).putString("saved",saved.getText().toString()).apply();update.run();Toast.makeText(this,"Cel zapisany",Toast.LENGTH_SHORT).show();}catch(Exception e){progress.setText("Podaj cel większy od zera i odłożoną kwotę co najmniej 0.");}});goal.addView(save);goal.addView(progress);update.run();root.addView(goal);
        LinearLayout deals=NativeUi.card(this);deals.addView(NativeUi.text(this,"Sprawdź aktualne okazje",19,true));deals.addView(NativeUi.muted(this,"Oferty otwierają się w przeglądarce. Ceny, terminy i warunki sprawdzisz u sprzedawcy.",13));
        link(deals,"Rossmann · aktualne promocje","https://www.rossmann.pl/promocje");link(deals,"Biedronka · gazetki","https://www.biedronka.pl/pl/gazetki");link(deals,"Lidl · oferta sklepu","https://www.lidl.pl/");link(deals,"Aldi · aktualne oferty","https://www.aldi.pl/oferty.html");link(deals,"Netto · gazetki","https://netto.pl/gazetka-netto/");root.addView(deals);
    }
    private EditText amount(String hint){EditText e=NativeUi.input(this,hint);e.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);e.setTextSize(15);return e;}
    private BigDecimal number(EditText e){BigDecimal n=new BigDecimal(e.getText().toString().trim().replace(',','.'));if(n.signum()<=0)throw new IllegalArgumentException();return n;}
    private String money(BigDecimal n){return n.setScale(2,RoundingMode.HALF_UP).toPlainString().replace('.',',')+" zł";}
    private void link(LinearLayout box,String label,String url){Button b=NativeUi.button(this,label,true);b.setOnClickListener(v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(url)));}catch(Exception e){Toast.makeText(this,"Brak przeglądarki do otwarcia oferty.",Toast.LENGTH_LONG).show();}});NativeUi.addSpacer(box,this,8);box.addView(b);}
}
