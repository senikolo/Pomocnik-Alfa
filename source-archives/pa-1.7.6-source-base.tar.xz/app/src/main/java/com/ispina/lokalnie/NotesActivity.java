package com.ispina.lokalnie;

import android.app.Activity;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class NotesActivity extends ThemedActivity {
    private EditText note;
    @Override protected void onCreate(Bundle b){super.onCreate(b);LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,16));root.setBackgroundColor(NativeUi.bg(this));LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);Button back=NativeUi.button(this,"‹",true);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,46)));TextView t=NativeUi.text(this,"Notatki",23,true);t.setPadding(NativeUi.dp(this,12),0,0,0);head.addView(t);root.addView(head);note=new EditText(this);note.setHint("Zapisz coś, o czym nie chcesz zapomnieć…");note.setGravity(Gravity.TOP|Gravity.START);note.setTextColor(NativeUi.ink(this));note.setHintTextColor(NativeUi.muted(this));note.setBackground(NativeUi.roundedStroke(NativeUi.cardColor(this),NativeUi.line(this),18,this));note.setPadding(NativeUi.dp(this,14),NativeUi.dp(this,14),NativeUi.dp(this,14),NativeUi.dp(this,14));note.setText(getSharedPreferences("native_notes",0).getString("note",""));LinearLayout.LayoutParams np=new LinearLayout.LayoutParams(-1,0,1);np.setMargins(0,NativeUi.dp(this,12),0,NativeUi.dp(this,10));root.addView(note,np);Button save=NativeUi.button(this,"Zapisz notatkę",false);save.setOnClickListener(v->{getSharedPreferences("native_notes",0).edit().putString("note",note.getText().toString()).apply();Toast.makeText(this,"Zapisano",Toast.LENGTH_SHORT).show();});root.addView(save,new LinearLayout.LayoutParams(-1,NativeUi.dp(this,48)));setContentView(root);}
    @Override protected void onPause(){getSharedPreferences("native_notes",0).edit().putString("note",note.getText().toString()).apply();super.onPause();}
}
