package com.ispina.lokalnie;

import android.app.Activity;
import android.os.Bundle;

/** Rebuild a returning screen after the palette changes in settings. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public abstract class ThemedActivity extends Activity {
    private int shownTheme;
    private com.ispina.lokalnie.tube.TubeMini tubeMini;
    @Override protected void onCreate(Bundle state){super.onCreate(state);shownTheme=NativeUi.themeKey(this);getWindow().setNavigationBarColor(NativeUi.green(this));}
    protected final void acceptCurrentTheme(){shownTheme=NativeUi.themeKey(this);}
    @Override protected void onResume(){super.onResume();if(tubeMini==null)tubeMini=new com.ispina.lokalnie.tube.TubeMini(this);tubeMini.show();if(shownTheme!=NativeUi.themeKey(this)){shownTheme=NativeUi.themeKey(this);recreate();}}
    @Override protected void onPause(){if(tubeMini!=null)tubeMini.hide();super.onPause();}
}
