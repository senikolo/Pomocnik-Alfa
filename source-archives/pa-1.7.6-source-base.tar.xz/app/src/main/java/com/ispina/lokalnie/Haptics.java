package com.ispina.lokalnie;

import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;

/** Click feedback only; unrelated to reminder notification vibration. */
public final class Haptics {
    private Haptics() {}
    public static int level(Context c) {
        return Math.max(0, Math.min(5, c.getSharedPreferences("appearance", 0).getInt("haptic_level", 2)));
    }
    public static void setLevel(Context c, int level) {
        c.getSharedPreferences("appearance", 0).edit().putInt("haptic_level", Math.max(0, Math.min(5, level))).apply();
    }
    public static boolean available(Context c) {
        Vibrator v = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
        return v != null && v.hasVibrator();
    }
    @SuppressWarnings("deprecation")
    public static boolean click(Context c) {
        int level = level(c);
        if (level == 0) return false;
        try {
            Vibrator v = (Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);
            if (v == null || !v.hasVibrator()) return false;
            int[] duration = {0, 12, 20, 30, 45, 65};
            int[] amplitude = {0, 35, 65, 110, 170, 230};
            if (Build.VERSION.SDK_INT >= 26) {
                int strength = v.hasAmplitudeControl() ? amplitude[level] : VibrationEffect.DEFAULT_AMPLITUDE;
                v.vibrate(VibrationEffect.createOneShot(duration[level], strength));
            } else v.vibrate(duration[level]);
            return true;
        } catch (RuntimeException e) { return false; }
    }
}
