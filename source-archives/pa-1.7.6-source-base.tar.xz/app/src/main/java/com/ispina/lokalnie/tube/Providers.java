package com.ispina.lokalnie.tube;
import java.util.*;
import android.net.Uri;
public final class Providers {
 public static final VideoProvider EXTRACTOR=new ExtractorProvider(), DIRECT=new DirectProvider();
 public static Video resolve(String url)throws Exception{return (EXTRACTOR.accepts(url)?EXTRACTOR:DIRECT).resolve(url);}
 static final class DirectProvider implements VideoProvider {
 public String name(){return "MP4 / HLS / własny serwer";}
 public boolean accepts(String u){
  if(u==null||u.trim().isEmpty())return false;
  Uri uri=Uri.parse(u);String scheme=uri.getScheme();String path=uri.getPath();
  if(path==null)return false;path=path.toLowerCase(Locale.ROOT);
  boolean local="file".equals(scheme)||("http".equals(scheme)&&("127.0.0.1".equals(uri.getHost())||"localhost".equals(uri.getHost())));
  boolean remote="https".equals(scheme);
  // Do not treat an arbitrary web page as an MP4. This was the source of
  // confusing "preparing playback" errors after pasting non-media links.
  return (local||remote)&&(path.endsWith(".mp4")||path.endsWith(".m4v")||path.endsWith(".webm")||path.endsWith(".m4a")||path.endsWith(".aac")||path.endsWith(".mp3")||path.endsWith(".ogg")||path.endsWith(".opus")||path.endsWith(".wav")||path.endsWith(".m3u8"));
 }
 public Page search(String q,Object c)throws Exception{Page p=new Page();p.items.add(resolve(q));return p;}
 public Video resolve(String u)throws Exception{if(!accepts(u))throw new Exception("Wklej bezpośredni adres pliku MP4, audio albo listy HLS (.m3u8), nie adres strony internetowej.");Video v=new Video();v.url=u;v.title=Uri.parse(u).getLastPathSegment();if(v.title==null)v.title="Własny materiał";v.provider="direct";v.author="Własne źródło";String path=Uri.parse(u).getPath().toLowerCase(Locale.ROOT);boolean a=path.matches(".*\\.(m4a|aac|mp3|ogg|opus|wav)$");String e=a?path.substring(path.lastIndexOf('.')+1):path.endsWith(".m3u8")?"m3u8":"mp4";Video.Source s=new Video.Source(u,path.endsWith(".m3u8")?"HLS · automatyczna":"Oryginalna",path.endsWith(".m3u8")?"application/x-mpegURL":a?"audio/"+e:"video/mp4",e);(a?v.audio:v.video).add(s);v.downloadable=!path.endsWith(".m3u8")&&!u.startsWith("file:");return v;}
 }
}
