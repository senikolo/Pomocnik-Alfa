package com.ispina.lokalnie.deals;
import org.json.*;
import java.util.*;
import java.text.Normalizer;
import java.time.*;
import java.util.regex.*;
public final class DealsParser {
 public static final String[] STORES={"Biedronka","Lidl","Aldi","Netto","Action","MR.DIY","Rossmann","Pepco","Auchan","Allegro"};
 private static final ZoneId ZONE=ZoneId.of("Europe/Warsaw");
 public static String normalize(String s){return Normalizer.normalize(s.toLowerCase(Locale.ROOT).replace('ł','l'),Normalizer.Form.NFD).replaceAll("\\p{M}","").replaceAll("[^a-z0-9]+"," ").trim();}
 // Commas/semicolons mean alternative products, words within a phrase mean AND.
 public static List<String> queries(String q){LinkedHashSet<String> out=new LinkedHashSet<>();for(String part:q.split("[,;]+")){String t=part.trim();if(!t.isEmpty())out.add(t);if(out.size()==3)break;}return new ArrayList<>(out);}
 private static String searchText(String s){return normalize(s).replaceAll("\\bpasty\\b","pasta").replaceAll("\\bbanany\\b","banan").replaceAll("\\bkawy\\b","kawa").replaceAll("\\bmleka\\b","mleko").replaceAll("\\b(zebow|zebom|zeby)\\b","zeb").replaceAll("\\bblend a med\\b","blendamed").replaceAll("\\boral b\\b","oralb");}
 public static boolean matches(String name,String q){if(q.trim().isEmpty())return true;String n=" "+searchText(name)+" ";for(String part:queries(q)){boolean ok=true,hasToken=false;for(String token:searchText(part).split(" +")){if(token.isEmpty()||token.equals("do")||token.equals("na"))continue;hasToken=true;if(!n.contains(" "+token+" ")){ok=false;break;}}if(ok&&hasToken)return true;}return false;}
 public static String requestQuery(String q){String n=normalize(q);if(n.equals("banan"))return "banany";if(n.equals("kawy"))return "kawa";if(n.equals("mleka"))return "mleko";if(n.equals("pasty do zebow")||n.equals("pasta do zebow")||n.equals("pasta do zebow "))return "pasta";return q;}
 public static final String ALLEGRO_STATUS="Oferty Allegro zobaczysz na stronie sklepu wewnątrz Pomocnika. Nie są uwzględniane w porównaniu naszych kafelków ani alertach cenowych.";
 public static String store(String s){String n=normalize(s);for(String x:STORES)if(normalize(x).equals(n))return x;if(n.equals("rossman"))return "Rossmann";if(n.equals("mrdiy")||n.equals("mr diy poland")||n.equals("mr diy polska"))return "MR.DIY";if(n.equals("auchan hipermarket")||n.equals("auchan supermarket")||n.equals("auchan supermarkety"))return "Auchan";return "";}
 public static String[] filters(){String[] a=new String[STORES.length+1];a[0]="Wszystkie";System.arraycopy(STORES,0,a,1,STORES.length);return a;}
 public static String emptyStore(String shop){if(shop.equals("Allegro"))return ALLEGRO_STATUS;if(shop.equals("MR.DIY"))return "Automatyczne ceny MR.DIY nie są dostępne. Brak wyniku nie oznacza braku produktu w sklepie.";if(shop.equals("Action"))return "Brak dopasowania w pobranym katalogu Action i gazetkach. Spróbuj krótszej nazwy.";if(shop.equals("Biedronka"))return "Brak dopasowania w sklepie internetowym Biedronka i gazetkach. Nie jest to pełny asortyment sklepów stacjonarnych.";if(shop.equals("Rossmann"))return "Brak dopasowania w pobranych stronach Rossmanna i katalogu gazetek. Spróbuj samej marki.";if(shop.equals("Aldi"))return "Brak dopasowania w katalogu ofert ALDI i gazetkach. Nie jest to pełny cennik sklepu.";return "Brak dopasowania w pobranym katalogu gazetek. Nie jest to pełny asortyment "+shop+". Spróbuj krótszej nazwy.";}
 public static String catalogue(String s){switch(s){case "Biedronka":return "https://www.biedronka.pl/pl/gazetki";case "Lidl":return "https://www.lidl.pl/";case "Aldi":return "https://www.aldi.pl/oferty.html";case "Netto":return "https://netto.pl/gazetka-netto/";case "Action":return "https://www.action.com/pl-pl/promocja-tygodnia/";case "MR.DIY":return "https://www.mrdiy.com/pl/pl/promotion?mode=ongoing";case "Rossmann":return "https://www.rossmann.pl/promocje";case "Pepco":return "https://pepco.pl/trendy/oferta-gazetkowa";case "Allegro":return "https://allegro.pl/";case "Auchan":return "https://www.auchan.pl/pl/gazetki";default:return "";}}
 public static long date(String s,boolean end){try{LocalDate d=LocalDate.parse(s.substring(0,10));return (end?d.plusDays(1):d).atStartOfDay(ZONE).toInstant().toEpochMilli()-(end?1:0);}catch(Exception e){return 0;}}
 public static List<Deal> ding(Object root,String q,long now){LinkedHashMap<String,Deal> out=new LinkedHashMap<>();walk(root,q,now,out);return new ArrayList<>(out.values());}
 private static void walk(Object o,String q,long now,Map<String,Deal> out){
  if(o instanceof JSONObject){JSONObject j=(JSONObject)o;JSONObject shop=j.optJSONObject("contractor"),dates=j.optJSONObject("duration");
   if(j.has("price") && shop!=null && dates!=null){
    String s=store(shop.optString("name")),name=j.optString("name");double price=j.optDouble("price",0);
    long from=date(dates.optString("begin"),false),to=date(dates.optString("end"),true);
    if(!s.isEmpty() && matches(name+" "+j.optString("description"),q) && !j.optBoolean("archived") && price>0 && !Double.isNaN(price) && !Double.isInfinite(price) && from>0 && from<=now && to>=now){
     Deal d=new Deal();d.id="ding:"+j.optString("id");d.name=name;d.store=s;d.price=price;d.from=from;d.to=to;d.start=dates.optString("begin").substring(0,10);d.end=dates.optString("end").substring(0,10);d.description=j.optString("description","");d.image=j.optString("image");d.details=!d.description.isEmpty();d.url="https://ding.pl/oferta/"+slug(name)+","+j.optString("id");measure(d,name+" "+d.description);
     Deal old=out.get(d.id);if(old==null || d.details)out.put(d.id,d);
    }
    // Similar products on details pages must not replace queried product data.
    return;
   }
   Iterator<String> keys=j.keys();while(keys.hasNext())walk(j.opt(keys.next()),q,now,out);
  }else if(o instanceof JSONArray){JSONArray a=(JSONArray)o;for(int i=0;i<a.length();i++)walk(a.opt(i),q,now,out);}
 }
 public static String slug(String s){return normalize(s).replace(' ','-');}
 public static void measure(Deal d,String text){
  String n=normalize(text);d.card=n.contains("karta") || n.contains("aplikac") || n.contains("kupon") || n.contains("lidl plus");
  Matcher m=Pattern.compile("(?i)(\\d+(?:[.,]\\d+)?)\\s*(kg|ml|g|l)\\b").matcher(text);
  if(m.find()){double quantity=Double.parseDouble(m.group(1).replace(',','.'));String u=m.group(2).toLowerCase(Locale.ROOT);if(quantity>0){d.unit=u.equals("g")||u.equals("kg")?"kg":"l";if(u.equals("g")||u.equals("ml"))quantity/=1000;d.unitPrice=d.price/quantity;}}
  else if(n.contains("za kilogram") || n.contains("za kg") || n.contains("cena za kg")){d.unit="kg";d.unitPrice=d.price;}
  String[] words={"dwoch","trzech","czterech","pieciu","szesciu","siedmiu","osmiu","dziewieciu","dziesieciu","jedenastu","dwunastu"};
  Matcher buy=Pattern.compile("(?:przy zakupie|kup)\\s+(\\d+)").matcher(n);if(buy.find())d.minimum=Math.max(1,Math.min(100,Integer.parseInt(buy.group(1))));
  for(int i=0;i<words.length;i++)if(n.contains("przy zakupie "+words[i]))d.minimum=i+2;
 }
 public static List<Deal> aldi(JSONObject root,String q,long now)throws Exception{
  List<Deal> out=new ArrayList<>();JSONObject props=root.getJSONObject("props").getJSONObject("pageProps");JSONArray api=new JSONArray(props.getString("apiData"));
  for(int i=0;i<api.length();i++){JSONArray item=api.optJSONArray(i);if(item==null || !"OFFER_GET".equals(item.optString(0)))continue;
   JSONObject products=item.getJSONObject(1).getJSONObject("res").optJSONObject("algoliaDataMap");if(products==null)continue;Iterator<String> keys=products.keys();
   while(keys.hasNext()){String key=keys.next();JSONObject p=products.getJSONObject(key),price=p.optJSONObject("currentPrice");String name=p.optString("brandName")+" "+p.optString("name");if(price==null || !matches(name,q))continue;
    long from=price.optLong("validFrom")*1000,to=price.optLong("validUntil")*1000;double value=price.optDouble("priceValue",0);if(value<=0 || from<=0 || from>now || to<now)continue;
    Deal d=new Deal();d.id="aldi:"+key;d.store="Aldi";d.source="ALDI.pl";d.name=name.trim();d.price=value;d.from=from;d.to=to;d.start=Instant.ofEpochMilli(from).atZone(ZONE).toLocalDate().toString();d.end=Instant.ofEpochMilli(to).atZone(ZONE).toLocalDate().toString();d.details=true;
    d.url="https://www.aldi.pl/oferty.html";d.description=p.optString("salesUnit")+" · "+p.optString("shortDescription");JSONObject labels=price.optJSONObject("priceTagLabels");if(labels!=null)d.description+=" · "+labels.optString("promoText1")+" · "+labels.optString("textualAddition");
    JSONArray bases=price.optJSONArray("basePrice");if(bases!=null && bases.length()>0){JSONObject b=bases.getJSONObject(0);d.description+=" · "+b.optString("basePriceAdditionalInformation");String u=b.optString("basePriceScale");if(u.equals("kg")||u.equals("l")){d.unit=u;d.unitPrice=b.optDouble("basePriceValue",0);}}
    String known=d.unit;double amount=d.unitPrice;measure(d,d.description);if(!known.isEmpty() && amount>0){d.unit=known;d.unitPrice=amount;}
    JSONArray assets=p.optJSONArray("assets");if(assets!=null && assets.length()>0)d.image=assets.getJSONObject(0).optString("url");out.add(d);
   }
  }return out;
 }
 public static JSONObject rossmannData(JSONObject root)throws Exception{return root.getJSONObject("props").getJSONObject("pageProps").getJSONObject("pageProps").getJSONObject("dehydratedFilters").getJSONArray("queries").getJSONObject(0).getJSONObject("state").getJSONObject("data");}
 public static List<Deal> rossmann(JSONObject root,String q,long now)throws Exception{
  List<Deal> out=new ArrayList<>();JSONArray items=rossmannData(root).getJSONArray("items");
  for(int i=0;i<items.length();i++){JSONObject p=items.getJSONObject(i);String name=(p.optString("brand")+" "+p.optString("name")+" · "+p.optString("caption")+" · "+p.optString("unit")).trim();
   double value=p.optDouble("price",0);String path=p.optString("navigateUrl");if(!"Product".equals(p.optString("type"))||!matches(name,q)||!Double.isFinite(value)||value<=0||!path.startsWith("/Produkt/"))continue;
   // Club-only price is never substituted for the displayed public price.
   Deal d=new Deal();d.id="rossmann:"+p.optString("id");d.store="Rossmann";d.source="Rossmann.pl";d.name=name;d.price=value;d.url="https://www.rossmann.pl"+path;d.details=true;d.checked=now;
   long from=date(p.optString("promotionFrom"),false),to=date(p.optString("promotionTo"),true);d.promotion=from>0&&from<=now&&to>=now&&p.optDouble("oldPrice",0)>value;
   if(d.promotion){d.from=from;d.to=to;d.start=p.optString("promotionFrom").substring(0,10);d.end=p.optString("promotionTo").substring(0,10);}else{d.currentPrice=true;d.from=now;d.to=now+86400000;}
   d.description=p.optString("caption")+" · "+p.optString("unit")+"\n"+p.optString("cmpDescription");d.description+="\nCena online. Dostępność i cena w drogerii mogą się różnić.";
   if(p.optDouble("lastLowestPriceV2",0)>0)d.description+="\nNajniższa cena przed obniżką podana przez sklep: "+d.money(p.optDouble("lastLowestPriceV2"));
   measure(d,p.optString("unit"));out.add(d);
  }return out;
 }

 public static String htmlText(String raw){String s=raw.replaceAll("(?s)<script\\b.*?</script>|<style\\b.*?</style>"," ").replaceAll("<[^>]*>"," ");String[][] entities={{"&quot;","\""},{"&apos;","'"},{"&lt;","<"},{"&gt;",">"},{"&nbsp;"," "},{"&ouml;","ö"},{"&uuml;","ü"},{"&auml;","ä"},{"&Ouml;","Ö"},{"&Uuml;","Ü"},{"&Auml;","Ä"},{"&szlig;","ß"},{"&eacute;","é"},{"&oacute;","ó"}};for(String[] e:entities)s=s.replace(e[0],e[1]);Matcher m=Pattern.compile("&#(x[0-9a-fA-F]+|[0-9]+);").matcher(s);StringBuffer b=new StringBuffer();while(m.find()){try{String n=m.group(1);int code=Integer.parseInt(n.startsWith("x")?n.substring(1):n,n.startsWith("x")?16:10);m.appendReplacement(b,Matcher.quoteReplacement(new String(Character.toChars(code))));}catch(Exception e){m.appendReplacement(b,Matcher.quoteReplacement(m.group()));}}m.appendTail(b);return b.toString().replace("&amp;","&").replaceAll("\\s+"," ").trim();}
 private static String field(String html,String id){Matcher m=Pattern.compile("<[^>]*data-testid=\""+Pattern.quote(id)+"\"[^>]*>(.*?)</[^>]+>",Pattern.DOTALL).matcher(html);return m.find()?htmlText(m.group(1)):"";}
 public static List<Deal> action(String html,String q,long now){List<Deal> out=new ArrayList<>();Matcher cards=Pattern.compile("<a([^>]*data-testid=\"product-card-link\"[^>]*)>(.*?)</a>",Pattern.DOTALL).matcher(html);while(cards.find()){String body=cards.group(2),name=field(body,"product-card-title"),pack=field(body,"product-card-description");Matcher link=Pattern.compile("href=\"(/pl-pl/p/([0-9]+)/[^\"]*)\"").matcher(cards.group(1));String whole=field(body,"product-card-price-whole"),fraction=field(body,"product-card-price-fractional");if(!link.find()||!matches(name+" "+pack,q)||!whole.matches("[0-9]+")||!fraction.matches("[0-9]{2}"))continue;double price=Double.parseDouble(whole+"."+fraction);if(price<=0||!Double.isFinite(price))continue;Deal d=new Deal();d.id="action:"+link.group(2);d.name=name+" · "+pack;d.store="Action";d.source="Action.com";d.url="https://www.action.com"+link.group(1);d.price=price;d.checked=now;d.from=now;d.to=now+86400000;d.currentPrice=true;d.promotion=false;d.details=true;d.description=pack+"\nCena z katalogu Action. Dostępność w wybranym sklepie wymaga sprawdzenia.";measure(d,pack.replaceAll("(?i)gramów|gramy|gram","g").replaceAll("(?i)litrów|litry|litr","l"));out.add(d);}return out;}
 public static List<Deal> biedronka(String html,String q,long now){List<Deal> out=new ArrayList<>();Matcher starts=Pattern.compile("<div class=\"product-tile js-product-tile[^\"]*\"[^>]*>").matcher(html);List<Integer> offsets=new ArrayList<>();while(starts.find())offsets.add(starts.start());for(int i=0;i<offsets.size();i++){String block=html.substring(offsets.get(i),i+1<offsets.size()?offsets.get(i+1):html.length());Matcher gtm=Pattern.compile("data-product-gtm=\"([^\"]+)\"").matcher(block);if(!gtm.find())continue;try{JSONObject data=new JSONObject(htmlText(gtm.group(1)));String name=data.optString("item_name"),id=data.optString("item_id");double value=data.optDouble("price",0);Matcher link=Pattern.compile("href=\"(https://zakupy\\.biedronka\\.pl/[^\"]+\\.html)\"").matcher(block);Matcher sales=Pattern.compile("class=\"price-tile__sales\"[^>]*>(.*?)</div>",Pattern.DOTALL).matcher(block);if(id.isEmpty()||!matches(name,q)||value<=0||!Double.isFinite(value)||!link.find()||!sales.find())continue;String visible=htmlText(sales.group(1));Matcher numbers=Pattern.compile("^([0-9]+)\\s+([0-9]{2})(?:\\s|$)").matcher(visible);if(!numbers.find()||Math.abs(Double.parseDouble(numbers.group(1)+"."+numbers.group(2))-value)>.001)continue;Deal d=new Deal();d.id="biedronka-online:"+id;d.store="Biedronka";d.source="zakupy.biedronka.pl";d.name=name;d.price=value;d.url=link.group(1);d.checked=now;d.from=now;d.to=now+86400000;d.currentPrice=true;d.promotion=false;d.details=true;d.description="Cena sklepu internetowego Biedronka. Cena w sklepie stacjonarnym może być inna. Dostępność, koszt dostawy i warunki zakupu zależą od adresu oraz koszyka.";measure(d,name);out.add(d);}catch(Exception ignored){}}return out;}

}
