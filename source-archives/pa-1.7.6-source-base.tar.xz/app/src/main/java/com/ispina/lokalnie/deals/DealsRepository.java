package com.ispina.lokalnie.deals;
import android.content.Context;
import android.util.Base64;
import org.json.*;
import java.util.*;
import java.util.concurrent.*;
import java.util.regex.*;
import java.net.*;
import java.io.*;
import java.nio.charset.StandardCharsets;
public final class DealsRepository {
 public static class Result {
  public final List<Deal> offers=new ArrayList<>();public long checked;public boolean stale,partial;public String note="";
  public JSONObject json(){JSONObject o=new JSONObject();JSONArray a=new JSONArray();for(Deal d:offers)a.put(d.json());try{o.put("offers",a).put("checked",checked).put("partial",partial).put("note",note);}catch(Exception ignored){}return o;}
 }
 public static String clean(String q){return q.trim().replaceAll("[,;]+$","").replaceAll("\\s+"," ");}
 public static String key(String q){List<String> parts=new ArrayList<>();for(String part:DealsParser.queries(q))parts.add(DealsParser.normalize(part));return String.join(" | ",parts);}
 private static final String UA="Mozilla/5.0 (Linux; Android) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36";
 public static String get(String url)throws Exception{
  HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(12000);c.setReadTimeout(18000);c.setRequestProperty("User-Agent",UA);c.setRequestProperty("Accept-Language","pl-PL,pl;q=0.9");c.setInstanceFollowRedirects(true);
  try{if(c.getResponseCode()!=200)throw new IOException("Źródło chwilowo niedostępne");try(InputStream in=c.getInputStream();ByteArrayOutputStream b=new ByteArrayOutputStream()){byte[] block=new byte[8192];int n;while((n=in.read(block))!=-1){b.write(block,0,n);if(b.size()>5_000_000)throw new IOException("Odpowiedź za duża");}return b.toString("UTF-8");}}finally{c.disconnect();}
 }
 public static JSONObject embedded(String html,String id)throws Exception{
  Matcher m=Pattern.compile("<script[^>]*id=[\"']"+Pattern.quote(id)+"[\"'][^>]*>(.*?)</script>",Pattern.DOTALL).matcher(html);
  if(!m.find())throw new IOException("Źródło zmieniło format danych");String text=m.group(1).trim();
  if(id.equals("hydration-data"))text=new String(Base64.decode(text,Base64.DEFAULT),StandardCharsets.UTF_8);return new JSONObject(text);
 }
 // ESI fragments contain a JSON object after a spread; read JSON without evaluating JavaScript.
 public static List<JSONObject> gridObjects(String html)throws Exception{
  List<JSONObject> out=new ArrayList<>();Matcher m=Pattern.compile("\\.\\.\\.(\\{\"pl-productsQuery)").matcher(html);
  while(m.find()){int start=m.start(1),depth=0;boolean string=false,escape=false;
   for(int i=start;i<html.length();i++){char ch=html.charAt(i);if(string){if(escape)escape=false;else if(ch=='\\')escape=true;else if(ch=='\"')string=false;}else if(ch=='\"')string=true;else if(ch=='{')depth++;else if(ch=='}' && --depth==0){out.add(new JSONObject(html.substring(start,i+1)));break;}}
  }return out;
 }
 // Sponsored fragments may report one product per page. Use the actual result grid.
 public static int dingPages(List<JSONObject> grids){int pages=1;for(JSONObject grid:grids){Iterator<String> keys=grid.keys();while(keys.hasNext()){JSONObject fragment=grid.optJSONObject(keys.next());if(fragment==null)continue;JSONObject data=fragment.optJSONObject("data");JSONObject products=data==null?null:data.optJSONObject("products");if(products==null)continue;JSONArray items=products.optJSONArray("items");if(items!=null&&items.length()>1)pages=Math.max(pages,products.optInt("totalPages",1));}}return pages;}
 public static String allegroUrl(String query){try{return "https://allegro.pl/listing?string="+java.net.URLEncoder.encode(clean(query),"UTF-8");}catch(UnsupportedEncodingException e){throw new IllegalArgumentException(e);}}
 private static List<Deal> direct(String query,long now,long deadline,boolean action,java.util.concurrent.atomic.AtomicBoolean partial)throws Exception{List<Deal> out=new ArrayList<>();boolean ok=false;for(String part:DealsParser.queries(query)){if(System.nanoTime()>=deadline||Thread.currentThread().isInterrupted()){partial.set(true);break;}try{String url=(action?"https://www.action.com/pl-pl/search/?q=":"https://zakupy.biedronka.pl/search?q=")+URLEncoder.encode(part,"UTF-8");String html=get(url);out.addAll(action?DealsParser.action(html,part,now):DealsParser.biedronka(html,part,now));ok=true;}catch(Exception e){partial.set(true);}}if(!ok)throw new IOException("Źródło niedostępne");return out;}
 public static Result search(Context context,String phrase){
  String query=clean(phrase);long now=System.currentTimeMillis();Result result=new Result();result.checked=now;
  ExecutorService ex=Executors.newFixedThreadPool(6);long deadline=System.nanoTime()+TimeUnit.SECONDS.toNanos(55);
  java.util.concurrent.atomic.AtomicBoolean rossPartial=new java.util.concurrent.atomic.AtomicBoolean(),dingPartial=new java.util.concurrent.atomic.AtomicBoolean();
  List<Future<List<Deal>>> dingTasks=new ArrayList<>(),rossTasks=new ArrayList<>();
  for(String part:DealsParser.queries(query)){
   dingTasks.add(ex.submit(()->{
    String encoded=URLEncoder.encode(DealsParser.requestQuery(part),"UTF-8");String html=get("https://ding.pl/oferty?name="+encoded);List<Deal> a=new ArrayList<>();a.addAll(DealsParser.ding(embedded(html,"hydration-data"),"",now));List<JSONObject> grids=gridObjects(html);if(grids.isEmpty())throw new IOException("Brak danych katalogu");for(JSONObject g:grids)a.addAll(DealsParser.ding(g,"",now));int available=dingPages(grids),pages=Math.min(6,available);if(available>pages)dingPartial.set(true);
    for(int page=2;page<=pages;page++){if(System.nanoTime()>=deadline||Thread.currentThread().isInterrupted()){dingPartial.set(true);break;}try{String next=get("https://ding.pl/oferty/"+page+"?name="+encoded);List<JSONObject> more=gridObjects(next);if(more.isEmpty())throw new IOException("Brak strony");for(JSONObject g:more)a.addAll(DealsParser.ding(g,"",now));}catch(Exception e){dingPartial.set(true);}}
    return a;
   }));
   rossTasks.add(ex.submit(()->{
    String url="https://www.rossmann.pl/szukaj?Search="+URLEncoder.encode(part,"UTF-8");JSONObject data=embedded(get(url),"__NEXT_DATA__");List<Deal> a=new ArrayList<>(DealsParser.rossmann(data,part,now));int pages=Math.min(3,DealsParser.rossmannData(data).optInt("totalPages",1));
    for(int page=2;page<=pages&&System.nanoTime()<deadline&&!Thread.currentThread().isInterrupted();page++)try{a.addAll(DealsParser.rossmann(embedded(get(url+"&Page="+page),"__NEXT_DATA__"),part,now));}catch(Exception ignored){rossPartial.set(true);}
    return a;
   }));
  }
  Future<List<Deal>> aldi=ex.submit(()->DealsParser.aldi(embedded(get("https://www.aldi.pl/oferty.html"),"__NEXT_DATA__"),query,now));
  java.util.concurrent.atomic.AtomicBoolean directPartial=new java.util.concurrent.atomic.AtomicBoolean();
  Future<List<Deal>> action=ex.submit(()->direct(query,now,deadline,true,directPartial)),biedronka=ex.submit(()->direct(query,now,deadline,false,directPartial));
  boolean dingOk=true,aldiOk=false,rossOk=true,actionOk=false,biedronkaOk=false;
  for(Future<List<Deal>> f:dingTasks)try{result.offers.addAll(f.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS));}catch(InterruptedException e){Thread.currentThread().interrupt();dingOk=false;}catch(Exception e){dingOk=false;}
  for(Future<List<Deal>> f:rossTasks)try{result.offers.addAll(f.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS));}catch(InterruptedException e){Thread.currentThread().interrupt();rossOk=false;}catch(Exception e){rossOk=false;}
  try{result.offers.addAll(aldi.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS));aldiOk=true;}catch(InterruptedException e){Thread.currentThread().interrupt();}catch(Exception ignored){}
  try{result.offers.addAll(action.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS));actionOk=true;}catch(InterruptedException e){Thread.currentThread().interrupt();}catch(Exception ignored){}
  try{result.offers.addAll(biedronka.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS));biedronkaOk=true;}catch(InterruptedException e){Thread.currentThread().interrupt();}catch(Exception ignored){}
  LinkedHashMap<String,Deal> unique=new LinkedHashMap<>();for(Deal d:result.offers)unique.put(d.id,d);result.offers.clear();result.offers.addAll(unique.values());
  // Enrich the cheapest indexed offers with pack sizes and purchase conditions.
  result.offers.sort(Comparator.comparing((Deal d)->!DealsParser.matches(d.name+" "+d.description,query)).thenComparingDouble(d->d.price));List<Future<Deal>> details=new ArrayList<>();int limit=0;
  for(Deal d:result.offers){if(System.nanoTime()>=deadline || Thread.currentThread().isInterrupted())break;if(!d.id.startsWith("ding:") || limit++>=16)continue;details.add(ex.submit(()->{
   try{List<Deal> found=DealsParser.ding(embedded(get(d.url),"hydration-data"),"",now);for(Deal full:found)if(full.id.equals(d.id))return full;}catch(Exception ignored){}return d;
  }));}
  for(Future<Deal> f:details)try{Deal d=f.get(Math.max(1,deadline-System.nanoTime()),TimeUnit.NANOSECONDS);for(int i=0;i<result.offers.size();i++)if(result.offers.get(i).id.equals(d.id))result.offers.set(i,d);}catch(InterruptedException interrupted){Thread.currentThread().interrupt();}catch(Exception ignored){}
  for(Future<Deal> f:details)f.cancel(true);for(Future<?> f:dingTasks)f.cancel(true);for(Future<?> f:rossTasks)f.cancel(true);aldi.cancel(true);action.cancel(true);biedronka.cancel(true);result.offers.removeIf(d->!DealsParser.matches(d.name+" "+d.description,query));ex.shutdownNow();result.partial=!dingOk || !aldiOk || !rossOk || rossPartial.get() || dingPartial.get() || directPartial.get() || !actionOk || !biedronkaOk;
  result.note="Źródła: "+(dingOk?"Ding.pl":"Ding.pl niedostępne")+" · "+(aldiOk?"ALDI.pl":"ALDI.pl niedostępne")+" · "+(rossOk?"Rossmann.pl":"Rossmann.pl niedostępne")+" · "+(actionOk?"Action.com":"Action niedostępne")+" · "+(biedronkaOk?"Biedronka online":"Biedronka online niedostępna")+". Przeszukano do 6 stron gazetek i 3 stron Rossmanna na hasło; wyniki nie obejmują całego rynku. Allegro: osobny widok ofert w aplikacji.";
  if(!dingOk && !aldiOk && !rossOk && !actionOk && !biedronkaOk){Result cached=cached(context,query);if(cached!=null){cached.stale=true;cached.partial=true;cached.note="Brak połączenia ze źródłami. Zapisane wyniki mogą być nieaktualne.";return cached;}result.note="Nie udało się pobrać ofert. Sprawdź internet i spróbuj ponownie.";}
  else context.getSharedPreferences("deals_cache_v3",0).edit().putString(key(query),result.json().toString()).apply();
  String preferred=preferredUnit(query);result.offers.sort(Comparator.comparing((Deal d)->!preferred.isEmpty()&&!preferred.equals(d.unit)).thenComparing((Deal d)->d.unit.isEmpty()?"z":d.unit).thenComparingDouble(d->d.unit.isEmpty()?d.price:d.unitPrice));return result;
 }
 public static Result cached(Context c,String q){try{JSONObject o=new JSONObject(c.getSharedPreferences("deals_cache_v3",0).getString(key(q),""));Result r=new Result();r.checked=o.optLong("checked");r.note=o.optString("note");r.partial=o.optBoolean("partial");JSONArray a=o.getJSONArray("offers");long now=System.currentTimeMillis();for(int i=0;i<a.length();i++){Deal d=Deal.read(a.getJSONObject(i));if(d.from<=now && d.to>=now)r.offers.add(d);}return r;}catch(Exception e){return null;}}
 public static List<Deal> preview(List<Deal> matching){List<Deal> out=new ArrayList<>();Set<String> stores=new HashSet<>();for(Deal d:matching)if(stores.add(d.store)){out.add(d);if(out.size()==5)return out;}for(Deal d:matching)if(!out.contains(d)){out.add(d);if(out.size()==5)break;}return out;}
 public static String preferredUnit(String query){String n=DealsParser.normalize(query);if(n.equals("mleko")||n.equals("pasta do zebow")||n.equals("pasty do zebow"))return "l";if(n.equals("kawa")||n.equals("kawy"))return "kg";return "";}
 public static String summary(List<Deal> list){
  if(list.isEmpty())return "Nie znaleziono pasujących cen w pobranych danych. Spróbuj krótszej nazwy lub samej marki.";
  Deal best=null;Set<String> units=new HashSet<>();int unknown=0;
  for(Deal d:list){if(d.unit.isEmpty() || !d.details){unknown++;continue;}units.add(d.unit);if(best==null || d.unitPrice<best.unitPrice)best=d;}
  if(units.size()!=1 || best==null)return "Znaleziono "+list.size()+" ofert. Nie wszystkie mają porównywalną wielkość opakowania.";
  return "Najniższa znaleziona cena za "+best.unit+": "+best.store+" · "+best.money(best.unitPrice)+" / "+best.unit+(unknown>0?". Część ofert ma niepełne dane.":". Warunki zakupu poniżej.");
 }
}
