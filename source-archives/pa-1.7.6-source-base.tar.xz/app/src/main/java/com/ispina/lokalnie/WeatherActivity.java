package com.ispina.lokalnie;

import android.app.Activity;
import android.content.*;
import android.net.Uri;
import android.os.*;
import android.view.*;
import android.widget.*;
import com.ispina.lokalnie.weather.WeatherRepository;
import com.ispina.lokalnie.weather.WeatherRepository.Forecast;
import org.json.*;
import java.text.SimpleDateFormat;
import java.time.*;
import java.util.*;
import java.util.concurrent.*;

public class WeatherActivity extends ThemedActivity {
 private int place,tab,selectedDay=-1,token;private boolean destroyed;
 private ScrollView scroll;private LinearLayout content;private TextView status;private ProgressBar progress;private Button refresh;
 private final Button[] places=new Button[3],tabs=new Button[3];
 private EditText city;private Button findCity;private TextView cityStatus;private Future<?> lookup;private int lookupToken;
 private Forecast forecast;private Future<?> task;
 private final ExecutorService executor=Executors.newFixedThreadPool(2);
 private final Handler ui=new Handler(Looper.getMainLooper());
 @Override protected void onCreate(Bundle state){super.onCreate(state);place=state!=null?state.getInt("place",0):getIntent().getIntExtra("place",getSharedPreferences("weather_ui",0).getInt("place",getSharedPreferences("home",0).getBoolean("warsaw",false)?1:0));place=place==2 && WeatherRepository.custom(this)!=null?2:place==1?1:0;if(state!=null){tab=state.getInt("tab",0);selectedDay=state.getInt("day",-1);}build();load(false);}
 private int dp(int n){return NativeUi.dp(this,n);}
 private void build(){
  getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_ALWAYS_HIDDEN|android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);getWindow().setStatusBarColor(NativeUi.bg(this));getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
  scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(NativeUi.bg(this));LinearLayout root=new LinearLayout(this);root.setFocusableInTouchMode(true);root.requestFocus();root.setOrientation(LinearLayout.VERTICAL);root.setPadding(dp(16),dp(16),dp(16),dp(28));scroll.addView(root);setContentView(scroll);
  LinearLayout header=new LinearLayout(this);header.setGravity(Gravity.CENTER_VERTICAL);Button back=NativeUi.button(this,"‹",true);back.setContentDescription("Wróć do Pomocnika Alfa");back.setOnClickListener(v->finish());header.addView(back,new LinearLayout.LayoutParams(dp(48),dp(48)));TextView heading=NativeUi.text(this,"Pogoda",26,true);heading.setPadding(dp(12),0,0,0);header.addView(heading,new LinearLayout.LayoutParams(0,-2,1));refresh=NativeUi.button(this,"Odśwież",true);refresh.setOnClickListener(v->load(true));header.addView(refresh);root.addView(header);NativeUi.addSpacer(root,this,18);
  LinearLayout locations=new LinearLayout(this);locations.setBaselineAligned(false);locations.setGravity(Gravity.CENTER_VERTICAL);for(int i=0;i<2;i++){final int id=i;Button b=NativeUi.button(this,i==0?"Ispina":"Warszawa\nBerensona",true);places[i]=b;b.setOnClickListener(v->{if(place==id)return;place=id;selectedDay=-1;getSharedPreferences("weather_ui",0).edit().putInt("place",id).apply();forecast=null;load(false);});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(72),1);if(i>0)p.leftMargin=dp(8);locations.addView(b,p);}root.addView(locations);NativeUi.addSpacer(root,this,8);
  places[2]=NativeUi.button(this,"",true);places[2].setOnClickListener(v->{if(WeatherRepository.custom(this)==null)return;place=2;selectedDay=-1;getSharedPreferences("weather_ui",0).edit().putInt("place",2).apply();load(false);});root.addView(places[2],new LinearLayout.LayoutParams(-1,-2));
  LinearLayout cityCard=NativeUi.card(this);city=NativeUi.input(this,"Wpisz inną miejscowość");city.setSingleLine(true);city.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);city.setOnEditorActionListener((v,action,event)->{if(action==android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH){searchCity();return true;}return false;});cityCard.addView(city,new LinearLayout.LayoutParams(-1,-2));NativeUi.addSpacer(cityCard,this,8);
  findCity=NativeUi.button(this,"Znajdź miejscowość",true);findCity.setOnClickListener(v->searchCity());cityCard.addView(findCity,new LinearLayout.LayoutParams(-1,-2));cityStatus=NativeUi.muted(this,"Ispina i Berensona są zawsze pod ręką.",12);cityStatus.setPadding(0,dp(8),0,0);cityStatus.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);cityCard.addView(cityStatus);NativeUi.addSpacer(root,this,8);root.addView(cityCard);NativeUi.addSpacer(root,this,4);
  LinearLayout choices=new LinearLayout(this);String[] labels={"Teraz","Godzinowo","7 dni"};for(int i=0;i<3;i++){final int index=i;Button b=NativeUi.button(this,labels[i],true);tabs[i]=b;b.setOnClickListener(v->{tab=index;selectedDay=-1;render();});LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,-2,1);if(i>0)p.leftMargin=dp(6);choices.addView(b,p);}root.addView(choices);NativeUi.addSpacer(root,this,12);
  progress=new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);progress.setIndeterminate(true);progress.setVisibility(View.GONE);root.addView(progress,new LinearLayout.LayoutParams(-1,dp(4)));
  status=NativeUi.muted(this,"Pobieram prognozę…",13);status.setAccessibilityLiveRegion(View.ACCESSIBILITY_LIVE_REGION_POLITE);status.setPadding(dp(3),dp(8),dp(3),dp(12));root.addView(status);
  content=new LinearLayout(this);content.setOrientation(LinearLayout.VERTICAL);root.addView(content);
  TextView attribution=NativeUi.muted(this,"Prognoza: Open-Meteo · okolice wybranego miejsca\nGodziny w czasie polskim. Prognoza na dalsze dni może się zmieniać.",12);attribution.setPadding(dp(3),dp(10),dp(3),0);NativeUi.onClick(attribution,v->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("https://open-meteo.com/")));}catch(Exception ignored){}});root.addView(attribution);selectButtons();
 }
 private void selectButtons(){WeatherRepository.Place custom=WeatherRepository.custom(this);places[2].setVisibility(custom==null?View.GONE:View.VISIBLE);if(custom!=null)places[2].setText(custom.name+" · zapisana miejscowość");for(int i=0;i<3;i++)style(places[i],place==i);for(int i=0;i<3;i++)style(tabs[i],tab==i);}
 private void style(Button b,boolean selected){b.setSelected(selected);b.setTextColor(selected?android.graphics.Color.WHITE:NativeUi.ink(this));b.setBackground(NativeUi.roundedStroke(selected?NativeUi.green(this):NativeUi.soft(this),selected?NativeUi.green(this):NativeUi.line(this),16,this));b.setContentDescription(b.getText()+(selected?", wybrano":""));}
 private String stamp(long time){SimpleDateFormat f=new SimpleDateFormat("dd.MM, HH:mm",new Locale("pl","PL"));f.setTimeZone(SunTimes.ZONE);return f.format(new Date(time));}
 private void load(boolean force){
  int generation=++token;int target=place;if(task!=null)task.cancel(true);selectButtons();Forecast cache=WeatherRepository.cached(this,target);forecast=cache;
  if(cache!=null){cache.offline=System.currentTimeMillis()-cache.fetched>30*60000L || !LocalDate.now(WeatherRepository.ZONE).toString().equals(cache.daily().optJSONArray("time").optString(0));render();if(!force && !cache.offline){status.setText("Aktualizacja: "+stamp(cache.fetched));progress.setVisibility(View.GONE);refresh.setEnabled(true);return;}}
  else{content.removeAllViews();LinearLayout card=NativeUi.card(this);card.addView(NativeUi.text(this,"Prognoza dla "+WeatherRepository.place(this,target).name,20,true));card.addView(NativeUi.muted(this,"Za chwilę pokażę temperaturę, opady i wiatr.",14));content.addView(card);}
  status.setText(cache==null?"Pobieram prognozę…":"Odświeżam · zapis z "+stamp(cache.fetched));progress.setVisibility(View.VISIBLE);refresh.setEnabled(false);
  task=executor.submit(()->{Forecast answer=null;try{answer=WeatherRepository.fetch(getApplicationContext(),target);}catch(Exception ignored){}final Forecast result=answer;ui.post(()->{if(destroyed || token!=generation)return;progress.setVisibility(View.GONE);refresh.setEnabled(true);if(result!=null){forecast=result;render();status.setText("Aktualizacja: "+stamp(result.fetched));}else if(forecast!=null){forecast.offline=true;render();status.setText("Brak połączenia. Zapisana prognoza z "+stamp(forecast.fetched)+" może być nieaktualna.");}else{status.setText("Nie udało się pobrać pogody. Sprawdź internet i naciśnij Odśwież.");content.removeAllViews();}});});
 }
 private void render(){selectButtons();if(forecast==null)return;content.removeAllViews();if(tab==0)current();else if(tab==1)hours(null);else days();scroll.post(()->scroll.smoothScrollTo(0,0));}
 private String num(JSONObject j,String key,int i,String unit){return WeatherRepository.num(j,key,i,unit);}
 private void row(LinearLayout card,String label,String value){LinearLayout r=new LinearLayout(this);r.setPadding(0,dp(5),0,dp(5));TextView name=NativeUi.muted(this,label,14);r.addView(name,new LinearLayout.LayoutParams(0,-2,1));TextView v=NativeUi.text(this,value,14,true);v.setGravity(Gravity.END);r.addView(v,new LinearLayout.LayoutParams(0,-2,1));card.addView(r);}
 private LinearLayout heading(String title){LinearLayout c=NativeUi.card(this);c.addView(NativeUi.text(this,title,20,true));NativeUi.addSpacer(c,this,8);return c;}
 private void current(){
  JSONObject c=forecast.current(),daily=forecast.daily();int code=c.optInt("weather_code",-1);boolean day=c.optInt("is_day",1)==1;
  LinearLayout hero=NativeUi.card(this);hero.setBackground(NativeUi.header(this));TextView label=NativeUi.text(this,forecast.location.name,18,true);label.setTextColor(android.graphics.Color.WHITE);hero.addView(label);NativeUi.addSpacer(hero,this,10);
  TextView temperature=NativeUi.text(this,WeatherRepository.symbol(code,day)+"  "+num(c,"temperature_2m",-1,"°C"),38,true);temperature.setTextColor(android.graphics.Color.WHITE);hero.addView(temperature);
  TextView desc=NativeUi.text(this,WeatherRepository.description(code),18,true);desc.setTextColor(android.graphics.Color.WHITE);hero.addView(desc);NativeUi.addSpacer(hero,this,8);TextView feels=NativeUi.text(this,"Odczuwalna "+num(c,"apparent_temperature",-1,"°C")+" · godz. "+WeatherRepository.clock(c.optString("time")),14,false);feels.setTextColor(android.graphics.Color.WHITE);hero.addView(feels);content.addView(hero);
  LinearLayout details=heading("Warunki na teraz");row(details,"Wiatr",num(c,"wind_speed_10m",-1," km/h")+" · "+WeatherRepository.direction(WeatherRepository.value(c,"wind_direction_10m",-1)));row(details,"Porywy",num(c,"wind_gusts_10m",-1," km/h"));row(details,"Wilgotność",num(c,"relative_humidity_2m",-1,"%"));row(details,"Zachmurzenie",num(c,"cloud_cover",-1,"%"));row(details,"Ciśnienie",num(c,"pressure_msl",-1," hPa"));row(details,"Opady w ostatnich 15 min",num(c,"precipitation",-1," mm"));content.addView(details);
  JSONArray dates=daily.optJSONArray("time");String today=LocalDate.now(WeatherRepository.ZONE).toString();int dayIndex=-1;for(int i=0;i<dates.length();i++)if(today.equals(dates.optString(i)))dayIndex=i;
  if(dayIndex>=0){LinearLayout summary=heading("Dzisiaj");dayRows(summary,daily,dayIndex);content.addView(summary);}else{content.addView(NativeUi.muted(this,"Ten zapis nie obejmuje dzisiejszego dnia. Odśwież prognozę.",14));}
 }
 private void dayRows(LinearLayout card,JSONObject d,int i){
  row(card,"Temperatura",num(d,"temperature_2m_min",i,"°")+" do "+num(d,"temperature_2m_max",i,"°C"));row(card,"Odczuwalna",num(d,"apparent_temperature_min",i,"°")+" do "+num(d,"apparent_temperature_max",i,"°C"));row(card,"Szansa opadów",num(d,"precipitation_probability_max",i,"%"));row(card,"Suma opadów",num(d,"precipitation_sum",i," mm"));row(card,"Wiatr do",num(d,"wind_speed_10m_max",i," km/h"));row(card,"Porywy do",num(d,"wind_gusts_10m_max",i," km/h"));row(card,"Kierunek wiatru",WeatherRepository.direction(WeatherRepository.value(d,"wind_direction_10m_dominant",i)));row(card,"Maksymalny UV",num(d,"uv_index_max",i,""));row(card,"Wschód / zachód",WeatherRepository.clock(d.optJSONArray("sunrise").optString(i))+" / "+WeatherRepository.clock(d.optJSONArray("sunset").optString(i)));
 }
 private void hours(String date){
  JSONObject h=forecast.hourly();JSONArray times=h.optJSONArray("time");long now=java.time.ZonedDateTime.now(WeatherRepository.ZONE).truncatedTo(java.time.temporal.ChronoUnit.HOURS).toInstant().toEpochMilli();int count=0;
  LinearLayout intro=heading(date==null?"Najbliższe 24 godziny":WeatherRepository.date(date));intro.addView(NativeUi.muted(this,"Temperatura odczuwalna, opady i wiatr godzina po godzinie.",14));if(date!=null){Button back=NativeUi.button(this,"‹ Wróć do 7 dni",true);back.setOnClickListener(v->{selectedDay=-1;render();});intro.addView(back,new LinearLayout.LayoutParams(-1,-2));}content.addView(intro);
  for(int i=0;i<times.length();i++){String at=times.optString(i);long millis=WeatherRepository.millis(at);if(date==null){if(millis<now || millis>=now+24*3600000L)continue;}else if(!at.startsWith(date))continue;
   int code=WeatherRepository.code(h,"weather_code",i);LinearLayout card=NativeUi.card(this);card.addView(NativeUi.text(this,WeatherRepository.symbol(code,WeatherRepository.value(h,"is_day",i)!=0)+"  "+WeatherRepository.clock(at)+" · "+num(h,"temperature_2m",i,"°C"),20,true));card.addView(NativeUi.muted(this,WeatherRepository.description(code),14));NativeUi.addSpacer(card,this,6);
   row(card,"Odczuwalna",num(h,"apparent_temperature",i,"°C"));row(card,"Opady",num(h,"precipitation_probability",i,"%")+" · "+num(h,"precipitation",i," mm"));row(card,"Wiatr / porywy",num(h,"wind_speed_10m",i,"")+" / "+num(h,"wind_gusts_10m",i," km/h"));row(card,"Kierunek",WeatherRepository.direction(WeatherRepository.value(h,"wind_direction_10m",i)));row(card,"Wilgotność",num(h,"relative_humidity_2m",i,"%"));row(card,"Ciśnienie",num(h,"pressure_msl",i," hPa"));row(card,"Zachmurzenie / UV",num(h,"cloud_cover",i,"%")+" / "+num(h,"uv_index",i,""));row(card,"Widoczność",num(h,"visibility",i," m"));content.addView(card);count++;
  }
  if(count==0)content.addView(NativeUi.muted(this,"Brak godzin w tym zapisie. Odśwież prognozę.",14));
 }
 private void days(){
  JSONObject d=forecast.daily();JSONArray dates=d.optJSONArray("time");if(selectedDay>=0 && selectedDay<dates.length()){hours(dates.optString(selectedDay));return;}
  String today=LocalDate.now(WeatherRepository.ZONE).toString();int count=0;
  for(int i=0;i<dates.length();i++){String date=dates.optString(i);if(date.compareTo(today)<0)continue;final int index=i;int code=WeatherRepository.code(d,"weather_code",i);LinearLayout card=heading(WeatherRepository.date(date));card.addView(NativeUi.text(this,WeatherRepository.symbol(code,true)+"  "+WeatherRepository.description(code),17,true));NativeUi.addSpacer(card,this,8);dayRows(card,d,i);NativeUi.addSpacer(card,this,8);Button hourly=NativeUi.button(this,"Zobacz godziny",true);hourly.setOnClickListener(v->{selectedDay=index;render();});card.addView(hourly,new LinearLayout.LayoutParams(-1,-2));content.addView(card);count++;}
  if(count==0)content.addView(NativeUi.muted(this,"Zapisana prognoza już wygasła. Naciśnij Odśwież.",14));
 }
 private void searchCity(){
  String name=city.getText().toString().trim();if(name.length()<2 || name.length()>80){city.setError("Wpisz nazwę, od 2 do 80 znaków.");return;}
  android.view.inputmethod.InputMethodManager keyboard=(android.view.inputmethod.InputMethodManager)getSystemService(INPUT_METHOD_SERVICE);if(keyboard!=null)keyboard.hideSoftInputFromWindow(city.getWindowToken(),0);city.clearFocus();
  int id=++lookupToken;if(lookup!=null)lookup.cancel(true);findCity.setEnabled(false);cityStatus.setText("Szukam: "+name+"…");
  lookup=executor.submit(()->{List<WeatherRepository.Place> result=null;try{result=WeatherRepository.find(name);}catch(Exception ignored){}final List<WeatherRepository.Place> found=result;ui.post(()->{if(destroyed || lookupToken!=id)return;findCity.setEnabled(true);if(found==null){cityStatus.setText("Nie udało się wyszukać miejscowości. Sprawdź internet i spróbuj ponownie.");return;}if(found.isEmpty()){cityStatus.setText("Nie znalazłem takiej miejscowości. Spróbuj pełnej nazwy lub pobliskiego miasta.");return;}String[] labels=new String[found.size()];for(int i=0;i<labels.length;i++)labels[i]=found.get(i).name+"\n"+found.get(i).region;cityStatus.setText("Wybierz miejscowość z listy.");new android.app.AlertDialog.Builder(this).setTitle("Która miejscowość?").setItems(labels,(dialog,index)->choose(found.get(index))).setNegativeButton("Anuluj",null).show();});});
 }
 private void choose(WeatherRepository.Place point){try{WeatherRepository.saveCustom(this,point);place=2;selectedDay=-1;getSharedPreferences("weather_ui",0).edit().putInt("place",2).apply();cityStatus.setText(point.name+" · "+point.region);city.setText(point.name);load(false);}catch(Exception e){cityStatus.setText("Nie udało się zapisać miejsca. Spróbuj ponownie.");}}
 @Override protected void onSaveInstanceState(Bundle b){b.putInt("place",place);b.putInt("tab",tab);b.putInt("day",selectedDay);super.onSaveInstanceState(b);}
 @Override protected void onDestroy(){destroyed=true;token++;lookupToken++;if(lookup!=null)lookup.cancel(true);if(task!=null)task.cancel(true);executor.shutdownNow();ui.removeCallbacksAndMessages(null);super.onDestroy();}
}
