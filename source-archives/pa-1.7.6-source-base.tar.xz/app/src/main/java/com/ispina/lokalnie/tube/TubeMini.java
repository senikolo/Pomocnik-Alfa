package com.ispina.lokalnie.tube;
import android.app.Activity;import android.content.*;import android.view.*;import android.widget.*;import androidx.media3.ui.PlayerView;import com.ispina.lokalnie.*;
/** Activity-owned surface; the service owns the player. Never stores an Activity statically. */
@androidx.annotation.OptIn(markerClass=androidx.media3.common.util.UnstableApi.class)
public final class TubeMini {
 private final Activity a;private LinearLayout box;private PlayerView view;
 public TubeMini(Activity a){this.a=a;}
 public void show(){hide();TubeService s=TubeService.active;if(s==null||s.current==null||a instanceof TubeActivity)return;
 FrameLayout decor=a.findViewById(android.R.id.content);box=new LinearLayout(a);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(8,8,8,8);box.setBackground(NativeUi.roundedStroke(NativeUi.cardColor(a),NativeUi.line(a),18,a));box.setElevation(12);
 TextView title=NativeUi.text(a,s.current.title,13,true);title.setMaxLines(1);box.addView(title);
 view=new PlayerView(a);view.setUseController(false);view.setPlayer(s.player);box.addView(view,new LinearLayout.LayoutParams(-1,NativeUi.dp(a,110)));
 LinearLayout buttons=new LinearLayout(a);add(buttons,"Ⅱ / ▶",()->{if(s.player.isPlaying())s.player.pause();else s.player.play();});add(buttons,"Otwórz",()->a.startActivity(new Intent(a,TubeActivity.class).putExtra("player",true)));add(buttons,"Następny",()->{if(s.player.hasNextMediaItem()){s.player.seekToNextMediaItem();s.player.play();}});add(buttons,"×",()->{s.close();hide();});box.addView(buttons);
 FrameLayout.LayoutParams lp=new FrameLayout.LayoutParams(NativeUi.dp(a,320),-2,Gravity.BOTTOM|Gravity.END);lp.setMargins(8,8,8,8);decor.addView(box,lp);
 }
 private void add(LinearLayout l,String text,Runnable r){Button b=NativeUi.button(a,text,true);b.setTextSize(11);b.setPadding(0,0,0,0);b.setMinWidth(0);b.setMinimumWidth(0);b.setOnClickListener(v->r.run());l.addView(b,new LinearLayout.LayoutParams(0,-2,1));}
 public void hide(){if(view!=null)view.setPlayer(null);view=null;if(box!=null&&box.getParent() instanceof ViewGroup)((ViewGroup)box.getParent()).removeView(box);box=null;}
}
