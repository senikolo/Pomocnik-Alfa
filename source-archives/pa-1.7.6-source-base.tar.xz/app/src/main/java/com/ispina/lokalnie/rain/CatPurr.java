package com.ispina.lokalnie.rain;

/** Soft procedural purring with a breathing rhythm, low harmonics and no loop seams. */
final class CatPurr {
    private static final double RATE=22050,TAU=2*Math.PI;
    private double phase,throat,breath;
    double sample(double white,long tick){
        double seconds=tick/RATE;
        double breathing=seconds*TAU/3.8+.07*Math.sin(seconds*.31);
        double inhale=Math.sin(breathing);
        double envelope=.32+.68*Math.pow(Math.abs(inhale),.55);
        // Slight changes in pitch and texture distinguish inhaling and exhaling.
        double frequency=27.5+1.8*inhale+.35*Math.sin(seconds*1.7);
        phase=(phase+TAU*frequency/RATE)%TAU;
        throat=.92*throat+.08*white;breath=.98*breath+.02*white;
        double pulse=Math.pow(Math.max(0,Math.sin(phase)),3);
        double harmonics=.075*Math.sin(phase)+.055*Math.sin(phase*2+.25)
                +.032*Math.sin(phase*3+.4)+.017*Math.sin(phase*5);
        double vibration=throat*(.06+.42*pulse);
        return (harmonics+vibration)*envelope+breath*.025;
    }
}
