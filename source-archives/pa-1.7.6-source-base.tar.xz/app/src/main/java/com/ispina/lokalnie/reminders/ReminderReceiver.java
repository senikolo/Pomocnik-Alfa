package com.ispina.lokalnie.reminders;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import com.ispina.lokalnie.MainActivity;

import org.json.JSONObject;

public class ReminderReceiver extends BroadcastReceiver {
    public static final String CHANNEL="pomocnik_reminders_v2";
    @Override public void onReceive(Context c,Intent i){
        String action=i.getAction();String payload=i.getStringExtra("payload");
        if("DONE".equals(action)){notification(c).cancel(i.getIntExtra("nid",0));return;}
        try{
            JSONObject o=new JSONObject(payload==null?"{}":payload);String id=o.optString("id","rem");int nid=Math.abs(id.hashCode());
            if("SNOOZE".equals(action)){notification(c).cancel(nid);ReminderScheduler.snooze(c,o);return;}
            ensureChannel(c);
            PendingIntent open=PendingIntent.getActivity(c,nid,new Intent(c,MainActivity.class).putExtra("screen","day").addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent done=PendingIntent.getBroadcast(c,nid+1,new Intent(c,ReminderReceiver.class).setAction("DONE").putExtra("nid",nid),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            PendingIntent snooze=PendingIntent.getBroadcast(c,nid+2,new Intent(c,ReminderReceiver.class).setAction("SNOOZE").putExtra("payload",o.toString()),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
            android.app.Notification.Builder b=Build.VERSION.SDK_INT>=26?new android.app.Notification.Builder(c,CHANNEL):new android.app.Notification.Builder(c);
            b.setSmallIcon(android.R.drawable.ic_lock_idle_alarm).setContentTitle(o.optString("title","Przypomnienie")).setContentText(o.optString("body",""))
                    .setStyle(new android.app.Notification.BigTextStyle().bigText(o.optString("body","")))
                    .setDefaults(android.app.Notification.DEFAULT_ALL).setAutoCancel(true).setContentIntent(open).setPriority(android.app.Notification.PRIORITY_HIGH)
                    .addAction(new android.app.Notification.Action.Builder(0,"Wykonane",done).build())
                    .addAction(new android.app.Notification.Action.Builder(0,"Za 10 min",snooze).build());
            notification(c).notify(nid,b.build());
            if(!"SNOOZE_FIRE".equals(action))ReminderScheduler.onFired(c,o);
        }catch(Exception ignored){}
    }
    public static void ensureChannel(Context c){if(Build.VERSION.SDK_INT>=26){NotificationChannel ch=new NotificationChannel(CHANNEL,"Przypomnienia Pomocnika Alfa",NotificationManager.IMPORTANCE_HIGH);ch.setDescription("Bilety, subskrypcje i inne przypomnienia");notification(c).createNotificationChannel(ch);}}
    private static NotificationManager notification(Context c){return (NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);}
}
