package com.ispina.lokalnie;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Gravity;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.ispina.lokalnie.reminders.ReminderScheduler;

import org.json.JSONObject;

import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

public class SubscriptionsActivity extends ThemedActivity {
    private LinearLayout list;
    private TextView total;

    @Override protected void onCreate(Bundle b){super.onCreate(b);build();}

    private void build(){
        LinearLayout root=new LinearLayout(this);root.setOrientation(LinearLayout.VERTICAL);root.setPadding(NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,13),NativeUi.dp(this,16));root.setBackgroundColor(NativeUi.bg(this));
        LinearLayout head=new LinearLayout(this);head.setGravity(Gravity.CENTER_VERTICAL);
        Button back=NativeUi.button(this,"‹",true);back.setOnClickListener(v->finish());head.addView(back,new LinearLayout.LayoutParams(NativeUi.dp(this,48),NativeUi.dp(this,46)));
        TextView t=NativeUi.text(this,"Subskrypcje",23,true);t.setPadding(NativeUi.dp(this,12),0,0,0);head.addView(t,new LinearLayout.LayoutParams(0,-2,1));
        Button add=NativeUi.button(this,"Dodaj",false);add.setOnClickListener(v->{if(ensureNotificationPermission())showAdd();});head.addView(add,new LinearLayout.LayoutParams(NativeUi.dp(this,86),NativeUi.dp(this,46)));root.addView(head);
        total=NativeUi.text(this,"0,00 zł / mies.",18,true);LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-1,-2);tp.setMargins(0,NativeUi.dp(this,12),0,NativeUi.dp(this,10));root.addView(total,tp);
        TextView hint=NativeUi.muted(this,"Miesięczne koszty uwzględniają abonamenty miesięczne oraz 1/12 ceny abonamentów rocznych.",11);root.addView(hint);
        NativeUi.addSpacer(root,this,8);
        ScrollView sc=new ScrollView(this);list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);sc.addView(list);root.addView(sc,new LinearLayout.LayoutParams(-1,0,1));setContentView(root);refresh();
    }

    private boolean ensureNotificationPermission(){
        if(android.os.Build.VERSION.SDK_INT>=33 && checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)!=android.content.pm.PackageManager.PERMISSION_GRANTED){
            requestPermissions(new String[]{android.Manifest.permission.POST_NOTIFICATIONS},503);
            Toast.makeText(this,"Zezwól na powiadomienia, a potem wybierz Dodaj ponownie.",Toast.LENGTH_LONG).show();
            return false;
        }
        return true;
    }

    private void refresh(){
        list.removeAllViews();SharedPreferences p=getSharedPreferences("native_subscriptions",0);List<JSONObject> a=new ArrayList<>();double monthlySum=0;long now=System.currentTimeMillis();
        for(String key:p.getAll().keySet()){
            try{
                JSONObject o=new JSONObject(p.getString(key,"{}"));
                boolean legacy=!o.has("cycle");
                if(legacy)o.put("cycle","monthly");
                boolean changed=rollRenewalForward(o,now) || legacy;
                if(changed)p.edit().putString(key,o.toString()).apply();
                if(legacy){
                    int d=o.optInt("days",2);Calendar notify=Calendar.getInstance();notify.setTimeInMillis(o.optLong("renewal",0));notify.add(Calendar.DAY_OF_MONTH,-d);
                    if(notify.getTimeInMillis()>now)ReminderScheduler.saveAndSchedule(this,"notify_"+o.optString("id",key),"Subskrypcja: "+o.optString("name","Subskrypcja"),"Odnowienie za "+d+(d==1?" dzień":" dni")+". Jeśli chcesz zrezygnować, zrób to teraz.",notify.getTimeInMillis(),"monthly");
                }
                a.add(o);
                String cycle=o.optString("cycle","monthly");double price=o.optDouble("price",0);
                if("monthly".equals(cycle))monthlySum+=price;else if("yearly".equals(cycle))monthlySum+=price/12.0;
            }catch(Exception ignored){}
        }
        a.sort(Comparator.comparingLong(o->o.optLong("renewal",Long.MAX_VALUE)));
        NumberFormat nf=NumberFormat.getCurrencyInstance(new Locale("pl","PL"));total.setText(nf.format(monthlySum)+" / mies.");
        if(a.isEmpty()){list.addView(NativeUi.muted(this,"Brak zapisanych subskrypcji.",13));MainActivity.updateDashboardState(this);return;}
        SimpleDateFormat f=new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault());
        for(JSONObject o:a){
            LinearLayout c=NativeUi.card(this);LinearLayout row=new LinearLayout(this);row.setGravity(Gravity.CENTER_VERTICAL);LinearLayout tx=new LinearLayout(this);tx.setOrientation(LinearLayout.VERTICAL);
            tx.addView(NativeUi.text(this,o.optString("name","Subskrypcja"),16,true));
            String cycle=o.optString("cycle","monthly");String cycleLabel="monthly".equals(cycle)?"co miesiąc":"yearly".equals(cycle)?"co rok":"jednorazowo";
            tx.addView(NativeUi.muted(this,nf.format(o.optDouble("price",0))+" • "+cycleLabel+" • odnowienie "+f.format(o.optLong("renewal",0))+" • przypomnienie "+o.optInt("days",2)+" dni wcześniej",11));
            row.addView(tx,new LinearLayout.LayoutParams(0,-2,1));Button del=NativeUi.button(this,"Usuń",true);String id=o.optString("id");
            del.setOnClickListener(v->{p.edit().remove(id).apply();ReminderScheduler.cancel(this,"notify_"+id);refresh();});row.addView(del,new LinearLayout.LayoutParams(NativeUi.dp(this,76),NativeUi.dp(this,44)));c.addView(row);list.addView(c);
        }
        MainActivity.updateDashboardState(this);
    }

    private boolean rollRenewalForward(JSONObject o,long now){
        String cycle=o.optString("cycle","monthly");if("once".equals(cycle))return false;long renewal=o.optLong("renewal",0);if(renewal<=0||renewal>now)return false;
        Calendar c=Calendar.getInstance();c.setTimeInMillis(renewal);boolean changed=false;int guard=0;
        while(c.getTimeInMillis()<=now && guard++<240){if("yearly".equals(cycle))c.add(Calendar.YEAR,1);else c.add(Calendar.MONTH,1);changed=true;}
        if(changed)try{o.put("renewal",c.getTimeInMillis());}catch(Exception ignored){}return changed;
    }

    private void showAdd(){
        LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(NativeUi.dp(this,18),0,NativeUi.dp(this,18),0);
        EditText name=new EditText(this);name.setHint("Nazwa, np. Netflix");
        EditText price=new EditText(this);price.setHint("Cena, np. 29.99");price.setInputType(android.text.InputType.TYPE_CLASS_NUMBER|android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL);
        Spinner cycle=new Spinner(this);String[] cycles={"Co miesiąc","Co rok","Jednorazowo"};cycle.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,cycles));
        Calendar renewal=Calendar.getInstance();renewal.add(Calendar.DAY_OF_MONTH,30);renewal.set(Calendar.HOUR_OF_DAY,9);renewal.set(Calendar.MINUTE,0);renewal.set(Calendar.SECOND,0);renewal.set(Calendar.MILLISECOND,0);
        Button date=NativeUi.button(this,"Odnowienie: "+fmt(renewal),true);
        String[] ds={"1 dzień wcześniej","2 dni wcześniej","3 dni wcześniej","7 dni wcześniej"};int[] days={1,2,3,7};Spinner before=new Spinner(this);before.setAdapter(new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,ds));before.setSelection(1);
        date.setOnClickListener(v->new DatePickerDialog(this,(x,y,m,d)->{renewal.set(y,m,d,9,0,0);date.setText("Odnowienie: "+fmt(renewal));},renewal.get(Calendar.YEAR),renewal.get(Calendar.MONTH),renewal.get(Calendar.DAY_OF_MONTH)).show());
        box.addView(name);box.addView(price);NativeUi.addSpacer(box,this,8);box.addView(cycle);NativeUi.addSpacer(box,this,8);box.addView(date);NativeUi.addSpacer(box,this,8);box.addView(before);
        AlertDialog dlg=new AlertDialog.Builder(this).setTitle("Nowa subskrypcja").setView(box).setNegativeButton("Anuluj",null).setPositiveButton("Zapisz",null).create();
        dlg.setOnShowListener(x->dlg.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener(v->{
            String n=name.getText().toString().trim();if(n.isEmpty()){name.setError("Podaj nazwę");return;}double pr;try{pr=Double.parseDouble(price.getText().toString().replace(',','.'));if(pr<0)throw new Exception();}catch(Exception e){price.setError("Podaj poprawną cenę");return;}
            int d=days[before.getSelectedItemPosition()];Calendar notify=(Calendar)renewal.clone();notify.add(Calendar.DAY_OF_MONTH,-d);if(notify.getTimeInMillis()<=System.currentTimeMillis()){Toast.makeText(this,"Termin przypomnienia wypada w przeszłości.",Toast.LENGTH_LONG).show();return;}
            String id="sub_"+System.currentTimeMillis();String cycleCode=cycle.getSelectedItemPosition()==1?"yearly":cycle.getSelectedItemPosition()==2?"once":"monthly";
            try{
                JSONObject o=new JSONObject();o.put("id",id);o.put("name",n);o.put("price",pr);o.put("renewal",renewal.getTimeInMillis());o.put("days",d);o.put("cycle",cycleCode);
                getSharedPreferences("native_subscriptions",0).edit().putString(id,o.toString()).apply();
                String reminderRepeat="monthly".equals(cycleCode)?"monthly":"yearly".equals(cycleCode)?"yearly":"once";
                boolean ok=ReminderScheduler.saveAndSchedule(this,"notify_"+id,"Subskrypcja: "+n,"Odnowienie za "+d+(d==1?" dzień":" dni")+". Jeśli chcesz zrezygnować, zrób to teraz.",notify.getTimeInMillis(),reminderRepeat);
                if(!ok){getSharedPreferences("native_subscriptions",0).edit().remove(id).apply();Toast.makeText(this,"Nie udało się zaplanować przypomnienia.",Toast.LENGTH_LONG).show();return;}
                dlg.dismiss();refresh();
            }catch(Exception e){Toast.makeText(this,"Nie udało się zapisać subskrypcji.",Toast.LENGTH_SHORT).show();}
        }));dlg.show();
    }

    private String fmt(Calendar c){return new SimpleDateFormat("dd.MM.yyyy",Locale.getDefault()).format(c.getTime());}
}
