package com.ispina.lokalnie.deals;
import android.content.Context;
import androidx.work.*;
import org.json.JSONArray;
import java.util.*;
import java.util.concurrent.TimeUnit;
public final class DealAlerts {
 public static List<String> list(Context c){List<String> a=new ArrayList<>();try{JSONArray j=new JSONArray(c.getSharedPreferences("deal_alerts",0).getString("products","[]"));for(int i=0;i<j.length();i++)a.add(j.getString(i));}catch(Exception ignored){}return a;}
 public static boolean add(Context c,String query){String q=DealsRepository.clean(query);if(q.length()<2 || q.length()>80 || DealsParser.normalize(q).isEmpty())return false;List<String>a=list(c);for(String x:a)if(DealsRepository.key(x).equals(DealsRepository.key(q)))return true;if(a.size()>=10)return false;a.add(q);save(c,a);schedule(c);check(c);return true;}
 public static void remove(Context c,String query){List<String>a=list(c);a.removeIf(x->DealsRepository.key(x).equals(DealsRepository.key(query)));save(c,a);c.getSharedPreferences("deal_alerts",0).edit().remove("seen:"+DealsRepository.key(query)).remove("checked:"+DealsRepository.key(query)).remove("status:"+DealsRepository.key(query)).apply();androidx.core.app.NotificationManagerCompat.from(c).cancel(notificationId(query));if(a.isEmpty()){WorkManager.getInstance(c).cancelUniqueWork("promotion-watch");WorkManager.getInstance(c).cancelUniqueWork("promotion-now");}}
 public static int notificationId(String query){return 0x60000000|(DealsRepository.key(query).hashCode()&0x0fffffff);}
 private static void save(Context c,List<String>a){c.getSharedPreferences("deal_alerts",0).edit().putString("products",new JSONArray(a).toString()).apply();}
 public static void schedule(Context c){if(list(c).isEmpty())return;Constraints constraints=new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build();PeriodicWorkRequest work=new PeriodicWorkRequest.Builder(DealAlertWorker.class,12,TimeUnit.HOURS).setConstraints(constraints).build();WorkManager.getInstance(c).enqueueUniquePeriodicWork("promotion-watch",ExistingPeriodicWorkPolicy.KEEP,work);}
 public static void check(Context c){if(list(c).isEmpty())return;WorkManager.getInstance(c).enqueueUniqueWork("promotion-now",ExistingWorkPolicy.KEEP,new OneTimeWorkRequest.Builder(DealAlertWorker.class).setConstraints(new Constraints.Builder().setRequiredNetworkType(NetworkType.CONNECTED).build()).build());}
}
